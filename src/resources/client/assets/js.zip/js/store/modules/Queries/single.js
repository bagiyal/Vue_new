import built_remark from "../../../mixins/builtremark";
import todaydate from '../../../mixins/todaydate'
import addupdatemeta from '../../../mixins/addupdatemeta'
import built_interaction from '../../../mixins/builtinteraction'

function initialState() {
    return {
        item: {
            id: null,
            driver_pickup_date_time: null,
            booking_id: null,
            budget: null,
            places:[],
            traveler_name: null,
            bill_pay: null,
            no_of_adults: 1,
            no_of_children: 0,
            note: null,
            status: null,
            phone: null,
            email: null,
            email_second: null,
            traveller_id: null,
            generated_itinerary: null,
            itinerary_places:null,
            agency_id: null,
            agent_id: null,
            meal_day: null,
            meals_supplement: {'bf':true,'l':false,'d':false},
            messageidd: null,
            package_category: null,
            pickup_address: null,
            pickup_location: null,
            query_feel: null,
            remarks: [],
            score: null,
            score_new: null,
            total_room: 1,
            total_tour_days: null,
            tour_cost: [{'cost':'','type':''}],
            tour_cost_tax: null,
            tour_id: null,
            tour_name: null,
            tour_location: null,
            tour_location_obj:{},
            itinerary_places_obj:{},

            hotel_test:null,
            created_by: null,
            created_by_team: null,
        },
        createdid:null,
        hotel_only:[],
        usersAll: [],
        teamsAll: [],
        tourAll:[],
        cityAll: [],
        places:{ 'places_city_id':{},'cites':[]},
        hotels:{},
        cityid:null,
        meta:{
            meta_infant:0,
            meta_extra_bed:0,
            meta_transport:null,
            meta_source:null,
            meta_flightprice:null,
            meta_flight:null,
            meta_welcome_mail:null,
            meta_incl_ex:null,
            meta_closuer:null,
            meta_exp_cost:[],
            meta_exp_costflight:[],
            markup1:{'percent':true,'value':''},
            markup2:{'percent':true,'value':''},
            sellingprice1:null,
            sellingprice2:null,
            meta_executive_name:document.querySelector("meta[name='user-name']").getAttribute('content'),
            meta_executive_no:document.querySelector("meta[name='user-phone']").getAttribute('content'),
            interactions:{},
            lost:{"title":"","details":""},
            by_lead:false,
            last_quote_no:0,

        },
        lead_data:null,
        lead_meta:null,
        clone_data:null,
        clone_meta:null,
        clonenew:null,
        meta_data:null,
        loading: false,
        placedata:{'title':'',
            'description':'',
            'contact_no':'',
            'categories':'custom',
            'place_longitude':'',
            'place_latitude':'',
            'featured_image':'',
            'city_id':'',
            'city':'',
            ' created_by':null,
            ' created_by_team':null,
        },
        addplacemodal:null,
        tourdata:{'titel':'','locations':'','total_tour_days':''}
    }
}

const getters = {
    item: state => state.item,
    loading: state => state.loading,
    usersAll: state => state.usersAll,
    teamsAll: state => state.teamsAll,
    tourAll: state => state.tourAll,
    places: state => state.places,
    cityid: state => state.cityid,
    hotels: state => state.hotels,
    cityAll: state => state.cityAll,
    createdid: state => state.createdid,

    // interactions: state => state.interactions,
    meta: state => state.meta,
    meta_data: state => state.meta_data,
    placedata: state => state.placedata,
    addplacemodal: state => state.addplacemodal,
    tourdata: state => state.tourdata,
    lead_data: state => state.lead_data,
    lead_meta: state => state.lead_meta,
    clone_data: state => state.clone_data,
    clone_meta: state => state.clone_meta,
    clonenew: state => state.clonenew,


}

const actions = {
    closeplace({ commit }, value) {
        commit('addplacemodal', value)
    },

    addPlace({ commit, state, dispatch }){

        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();

            for (let fieldName in state.placedata) {


                let fieldValue = state.placedata[fieldName];
                if (fieldName == 'city') {

                    // params.set('city', fieldValue);
                    // console.log(fieldValue);
                    // var obj=[];
                    // for(var key in fieldValue){
                    //     obj.push(fieldValue[key]['id']);
                    // }
                    // // alert(obj);
                    // params.set('city_id', JSON.stringify(obj));
                    //
                    // if (typeof fieldValue !== 'object') {
                    //     params.set(fieldName, fieldValue);
                    // } else {
                    //     if (fieldValue && typeof fieldValue[0] !== 'object') {
                    //         params.set(fieldName, fieldValue);
                    //     } else {
                    //         for (let index in fieldValue) {
                    //             params.set(fieldName + '[' + index + ']', fieldValue[index]);
                    //         }
                    //     }
                    // }

                }
                if (fieldName == 'city_id') {
                    var city_idd=fieldValue;
                    params.set('city[0]', fieldValue);
                    params.set('city_id', '[' + fieldValue + ']');
                }

                else if(fieldName != 'city_id' && fieldName != 'city' ){
                    if (typeof fieldValue !== 'object') {
                        params.set(fieldName, fieldValue);
                    } else {
                        if (fieldValue && typeof fieldValue[0] !== 'object') {
                            params.set(fieldName, fieldValue);
                        } else {
                            for (let index in fieldValue) {
                                params.set(fieldName + '[' + index + ']', fieldValue[index]);
                            }
                        }
                    }
                }

                if (_.isEmpty(state.placedata.created_by)) {
                    params.set('created_by_id', '')
                } else {
                    params.set('created_by_id', state.placedata.created_by.id)
                }
                if (_.isEmpty(state.placedata.created_by_team)) {
                    params.set('created_by_team_id', '')
                } else {
                    params.set('created_by_team_id', state.placedata.created_by_team.id)
                }

            }

            // if (_.isEmpty(state.placedata.city)) {
            //     params.delete('city')
            // } else {
            //     for (let index in state.placedata.city) {
            //         params.set('city['+index+']', state.placedata.city[index].id)
            //     }
            // }

            axios.post('/api/v1/places', params)
                .then(response => {
                    // commit('resetState')
                    // dispatch(fetchplace(city_idd));
                    commit('addplacemodal', city_idd)
                    resolve()

                })
                .catch(error => {
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })



    },
    //addnewtour
    addnewtour({ commit, state, dispatch },value) {
        // commit('setLoading', true)
        // dispatch('Alert/resetState', null, { root: true })
        console.log("tour data")
        console.log(value)
        console.log(state.tourdata)


        return new Promise((resolve, reject) => {
            let params = new FormData();

            for (let fieldName in value) {
                let fieldValue = value[fieldName];
                if (typeof fieldValue !== 'object') {
                    params.set(fieldName, fieldValue);
                } else {
                    if (fieldValue && typeof fieldValue[0] !== 'object') {
                        params.set(fieldName, fieldValue);
                    } else {
                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            // if (_.isEmpty(state.item.created_by)) {
            //     params.set('created_by_id', '')
            // } else {
            //     params.set('created_by_id', state.item.created_by.id)
            // }
            // if (_.isEmpty(state.item.created_by_team)) {
            //     params.set('created_by_team_id', '')
            // } else {
            //     params.set('created_by_team_id', state.item.created_by_team.id)
            // }
            params.set('created_by_id', '')
            axios.post('/api/v1/tours', params)
                .then(response => {
                    commit('resetState')
                    resolve()
                })
                .catch(error => {
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },




    storeData({ commit, state, dispatch }) {
        commit('setLoading', true)
        // dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();
            state.meta.meta_exp_cost=JSON.stringify(state.meta.meta_exp_cost);
            state.meta.meta_exp_costflight=JSON.stringify(state.meta.meta_exp_costflight);
            state.meta.markup1=JSON.stringify(state.meta.markup1);
            state.meta.markup2=JSON.stringify(state.meta.markup2);
            state.meta.interactions=JSON.stringify(state.meta.interactions);
            state.meta.lost=JSON.stringify(state.meta.lost);

            // if(typeof (state.lead_data)!=="undefined" && state.lead_data!==null ) {
            //     state.meta.by_lead = state.lead_data.id;
            // }
            params.set('meta', JSON.stringify(state.meta));
            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {
                    params.set(fieldName, fieldValue);
                }
                else {

                    if (fieldValue && typeof fieldValue[0] !== 'object') {

                        if(fieldName=='itinerary_places'){
                            //   console.log("itinerary_places");
                            let newobj={};
                            console.log(fieldValue);
                            console.log(state.places.cites)

                            state.places.cites.forEach( (dataObj) => {
                                console.log(dataObj['id']);
                                newobj[dataObj['id']]=fieldValue[dataObj['id']];
                                // dataObj.forEach( function(element) {
                                //     console.log(element);
                                // });
                                // for(let city in dataObj){
                                //     console.log(city);
                                //     newobj[city['id']]=fieldValue[city['id']];
                                // }
                            });

                            console.log(newobj);
                            //   throw new Error("my error message");
                            params.set(fieldName, JSON.stringify(newobj));

                        }

                        else  if(fieldName=='meals_supplement'){

                            params.set(fieldName, JSON.stringify(fieldValue));


                        }

                        else {
                            params.set(fieldName, fieldValue);
                        }

                    }
                    else  if(fieldName=='remarks'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                    else if(fieldName=='tour_location'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                    else  if(fieldName=='tour_cost'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }



                    else {

                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (_.isEmpty(state.item.created_by)) {
                params.set('created_by_id', '')
            } else {
                params.set('created_by_id', state.item.created_by.id)
            }
            if (_.isEmpty(state.item.created_by_team)) {
                params.set('created_by_team_id', '')
            } else {
                params.set('created_by_team_id', state.item.created_by_team.id)
            }

            axios.post('/api/v1/queries', params)
                .then(response => {
// this.setcreatedid(response.data.data.id)
                    commit('setcreatedid', response.data.data.id)

                    console.log("createdid");
                    console.log(state.createdid);
                    // state.createdid=response.data.data.id;
                    // commit('resetState')
                    console.log("Save Query")
                    console.log(response.data.data.id)

                    let params = new FormData();
                    params.set('_method', 'PUT');

                    if(typeof (state.lead_data)!=="undefined" && state.lead_data!==null ){
                        if(state.lead_data.lead_status==1){
                            //change status of lead
                            // console.log("lead_data.lead_status")
                            // params.set("lead_status", 2);
                            // params.set('meta', JSON.stringify({"meta_query_gen":  JSON.stringify([response.data.data.id])}));
                            // axios.post('/api/v1/leads/' + state.lead_data.id, params)
                            //     .then(response => {
                            //         console.log("lead_datasucc"+response)
                            //         // commit('setItem', response.data.data)
                            //         // resolve()
                            //     });
                            console.log("lead_data.lead_status")
                            params.set("lead_status", 2);
                          params.set('meta', JSON.stringify({}));
                            axios.post('/api/v1/leads/' + state.lead_data.id, params)
                                .then(response => {
                                    console.log("lead_datasucc"+response)
                                    // commit('setItem', response.data.data)
                                    // resolve()
                                });


                            let metaq=state.lead_meta.meta_query_gen;
                            console.log(metaq)
                            if(!_.isEmpty(metaq)){
                                metaq.push(response.data.data.id);
                                addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify(metaq))
                            }
                            else {

                                addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify([response.data.data.id]))
                            }

                        }
                        else {
                            console.log("meta_query_gen")
                            // params.set('meta', JSON.stringify({"meta_query_gen":  JSON.stringify([response.data.data.id])}));
                            // axios.post('/api/v1/leads/' + state.lead_data.id, params)
                            //     .then(response => {
                            //         console.log("lead_datasucc2"+response)
                            //         // commit('setItem', response.data.data)
                            //         // resolve()
                            //     });
                            console.log(state.lead_meta.meta_query_gen)
                            let metaq=state.lead_meta.meta_query_gen;
                            if(!_.isEmpty(metaq)){
                                metaq.push(response.data.data.id);
                                console.log(JSON.stringify(metaq))
                                console.log(JSON.stringify([response.data.data.id]))
                                addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify(metaq))
                                // addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify([response.data.data.id]))

                            }
                            else {

                                addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify([response.data.data.id]))
                            }
                            // addupdatemeta(state.lead_data.id,'lead','meta_query_gen',JSON.stringify([response.data.data.id]))

                        }

                    }

                    // console.log(state.clone_data)
                    if(typeof (state.clone_data)!=="undefined" && state.clone_data!==null ){
console.log("in clone interaction")
                    let value=    built_interaction("Clone to other query","Click Action","Done",response.data.data.booking_id)

                        let metaq=JSON.parse(state.clone_meta.interactions);
                        console.log(metaq)
                        if(metaq.hasOwnProperty(todaydate()) ){
                            metaq[todaydate()].push(value)
                        }
                        else {
                            metaq[todaydate()] =[value]
                        }

                        console.log(metaq)
                        console.log(state.clone_data.id)
                            addupdatemeta(state.clone_data.id,'query','interactions',JSON.stringify(metaq))



                    }
                    //save generated id of query in lead meta

                    resolve()
                })
                .catch(error => {
                    state.meta.meta_exp_cost=JSON.parse(state.meta.meta_exp_cost);
                    state.meta.meta_exp_costflight=JSON.parse(state.meta.meta_exp_costflight);
                    state.meta.markup1=JSON.parse(state.meta.markup1);
                    state.meta.markup2=JSON.parse(state.meta.markup2);
                    state.meta.interactions=JSON.parse(state.meta.interactions);
                    // state.meta.interactions=JSON.parse(state.meta.interactions);
                    state.meta.lost=JSON.parse(state.meta.lost);
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    updateData({ commit, state, dispatch }) {
        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();


            params.set('_method', 'PUT')

            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {

                    params.set(fieldName, fieldValue);
                }
                else {

                    if (fieldValue && typeof fieldValue[0] !== 'object') {

                        if(fieldName=='itinerary_places'){
                            //   console.log("itinerary_places");
                            let newobj={};
                            console.log(fieldValue);
                            console.log(state.places.cites)

                            state.places.cites.forEach( (dataObj) => {
                                console.log(dataObj['id']);
                                newobj[dataObj['id']]=fieldValue[dataObj['id']];
                                // dataObj.forEach( function(element) {
                                //     console.log(element);
                                // });
                                // for(let city in dataObj){
                                //     console.log(city);
                                //     newobj[city['id']]=fieldValue[city['id']];
                                // }
                            });

                            console.log(newobj);
                            //   throw new Error("my error message");
                            params.set(fieldName, JSON.stringify(newobj));

                        }

                        else  if(fieldName=='meals_supplement'){

                            params.set(fieldName, JSON.stringify(fieldValue));

                        }
                        else {
                            params.set(fieldName, fieldValue);
                        }

                    }
                    else  if(fieldName=='remarks'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                    else if(fieldName=='tour_location'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                    else  if(fieldName=='tour_cost'){

                        params.set(fieldName, JSON.stringify(fieldValue));

                    }



                    else {

                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (_.isEmpty(state.item.created_by)) {
                params.set('created_by_id', '')
            } else {
                params.set('created_by_id', state.item.created_by.id)
            }
            if (_.isEmpty(state.item.created_by_team)) {
                params.set('created_by_team_id', '')
            } else {
                params.set('created_by_team_id', state.item.created_by_team.id)
            }

            state.meta.meta_exp_cost=JSON.stringify(state.meta.meta_exp_cost);
            state.meta.meta_exp_costflight=JSON.stringify(state.meta.meta_exp_costflight);
            state.meta.markup1=JSON.stringify(state.meta.markup1);
            state.meta.markup2=JSON.stringify(state.meta.markup2);
            state.meta.interactions=JSON.stringify(state.meta.interactions);
            state.meta.lost=JSON.stringify(state.meta.lost);
            params.set('meta', JSON.stringify(state.meta));

            axios.post('/api/v1/queries/' + state.item.id, params)
                .then(response => {
                    // commit('setItem', response.data.data)
                    resolve()
                    state.meta.meta_exp_cost=JSON.parse(state.meta.meta_exp_cost);
                    state.meta.meta_exp_costflight=JSON.parse(state.meta.meta_exp_costflight);
                    state.meta.markup1=JSON.parse(state.meta.markup1);
                    state.meta.markup2=JSON.parse(state.meta.markup2);
                    state.meta.interactions=JSON.parse(state.meta.interactions);
                    state.meta.lost=JSON.parse(state.meta.lost);
                })
                .catch(error => {
                    state.meta.meta_exp_cost=JSON.parse(state.meta.meta_exp_cost);
                    state.meta.meta_exp_costflight=JSON.parse(state.meta.meta_exp_costflight);
                    state.meta.markup1=JSON.parse(state.meta.markup1);
                    state.meta.markup2=JSON.parse(state.meta.markup2);


                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    fetchData({ commit, dispatch }, id) {
        axios.get('/api/v1/queries/' + id,{
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                console.log("response");
                console.log(response);
                commit('setItem', response.data.data)
                // commit('setTour_location', response.data.data.tour_location)
            })

        dispatch('fetchUsersAll')
        dispatch('fetchTeamsAll')
        dispatch('fetchTourAll')
    },
    fetchCityAll({ commit }) {
        axios.get('/api/v1/cities')
            .then(response => {
                commit('setCityAll', response.data.data)
            })
    },
    fetchTourAll({ commit }) {
        axios.get('/api/v1/tours_id_title')
            .then(response => {
                commit('setTourAll', response.data.data)
            })
    },
    fetchUsersAll({ commit }) {
        axios.get('/api/v1/users')
            .then(response => {
                commit('setUsersAll', response.data.data)
            })
    },
    fetchTeamsAll({ commit }) {
        axios.get('/api/v1/teams')
            .then(response => {
                commit('setTeamsAll', response.data.data)
            })
    },


    setclonedata({ commit }, value) {
        commit('setclonedata', value)
    },
    setclonedatameta({ commit }, value) {
        commit('setclonedatameta', value)
    },

    setDriver_pickup_date_time({ commit }, value) {
        commit('setDriver_pickup_date_time', value)
    },
    fetchplace({commit},id){
        console.log("fetchplace");
        commit('setcityid', id)
        axios.get('/api/v1/city/ofcity/'+id)
            .then(response => {
                commit('setplace', {data:response.data.data, id:id})
            })
        // axios.get('/api/v1/places/ofcity/'+id)
        //     .then(response => {
        //         commit('setplace', response.data.data)
        //     })
    },
    fetchhotel({commit},id){
        console.log("fetchhotel");
        // commit('sethotel', id)
        axios.get('/api/v1/city/hotels/'+id)
            .then(response => {
                console.log(response);
                if(!_.isEmpty(response.data)){
                    commit('sethotel', {hotel:response.data.data, location_id:id})
                }

                //      commit('sethotel', {data:response.data.data, id:id})
            })
        // axios.get('/api/v1/places/ofcity/'+id)
        //     .then(response => {
        //         commit('setplace', response.data.data)
        //     })
    },
    setBooking_id({ commit }, value) {
        // console.log(value);
        commit('setBooking_id', value)
    },
    setBudget({ commit }, value) {
        commit('setBudget', value)
    },



    // setplaces({ commit }, value) {
    //     commit('setplaces', value)
    // },

    setTraveler_name({ commit }, value) {
        commit('setTraveler_name', value)
    },
    setBill_pay({ commit }, value) {
        commit('setBill_pay', value)
    },
    setNo_of_adults({ commit }, value) {
        commit('setNo_of_adults', value)
    },
    setNo_of_children({ commit }, value) {
        commit('setNo_of_children', value)
    },
    setmeta_infant({ commit }, value) {
        commit('setmeta_infant', value)
    },
    setmeta_extra_bed({ commit }, value) {
        commit('setmeta_extra_bed', value)
    },

    setmeta_transport({ commit }, value) {
        commit('setmeta_transport', value)
    },
    setmeta_source({ commit }, value) {
        commit('setmeta_source', value)
    },
    setmeta_flightprice({ commit }, value) {
        commit('setmeta_flightprice', value)
    },
    setmeta_flight({ commit }, value) {
        commit('setmeta_flight', value)
    },
    setmeta_welcome_mail({ commit }, value) {
        commit('setmeta_welcome_mail', value)
    },
    setmeta_incl_ex({ commit }, value) {
        commit('setmeta_incl_ex', value)
    },
    setmeta_closuer({ commit }, value) {
        commit('setmeta_closuer', value)
    },
    setmeta_exp_cost({ commit }, value) {
        commit('setmeta_exp_cost', value)
    },
    setmeta_exp_costflight({ commit }, value) {
        commit('setmeta_exp_costflight', value)
    },
    setmarkup1({ commit }, value) {
        commit('setmarkup1', value)
    },
    setmarkup2({ commit }, value) {
        commit('setmarkup2', value)
    },
    setsellingprice1({ commit }, value) {
        commit('setsellingprice1', value)
    },
    setsellingprice2({ commit }, value) {
        commit('setsellingprice2', value)
    },

    setmeta_interactions({ commit }, value) {
        commit('setmeta_interactions', value)
    },
    setmeta_interactionsfull({ commit }, value) {
        commit('setmeta_interactionsfull', value)
    },
    setmeta_lost({ commit }, value) {
        commit('setmeta_lost', value)
    },
    setby_lead({ commit }, value) {
        commit('setby_lead', value)
    },
    setlast_quote_no({ commit }, value) {
        commit('setlast_quote_no', value)
    },

    setlead_data({ commit }, value) {
        commit('setlead_data', value)
    },
    setlead_meta({ commit }, value) {
        commit('setlead_meta', value)
    },
    setclone_data({ commit }, value) {
        commit('setclone_data', value)
    },
    setclone_meta({ commit }, value) {
        commit('setclone_meta', value)
    },
    setclonenew({ commit }, value) {
        commit('setclonenew', value)
    },


    setmeta_executive_name({ commit }, value) {
        commit('setmeta_executive_name', value)
    },
    setmeta_executive_no({ commit }, value) {
        commit('setmeta_executive_no', value)
    },








    setNote({ commit }, value) {
        commit('setNote', value)
    },
    setStatus({ commit }, value) {
        commit('setStatus', value)
    },
    setPhone({ commit }, value) {
        commit('setPhone', value)
    },
    setEmail({ commit }, value) {
        commit('setEmail', value)
    },
    setEmail_second({ commit }, value) {
        commit('setEmail_second', value)
    },
    setTraveller_id({ commit }, value) {
        commit('setTraveller_id', value)
    },
    setGenerated_itinerary({ commit }, value) {
        commit('setGenerated_itinerary', value)
    },
    setItinerary_places({ commit }, value) {
        commit('setItinerary_places', value)
    },
    setAgency_id({ commit }, value) {
        commit('setAgency_id', value)
    },
    setAgent_id({ commit }, value) {
        commit('setAgent_id', value)
    },
    setMeal_day({ commit }, value) {
        commit('setMeal_day', value)
    },
    setMeals_supplement({ commit }, value) {
        commit('setMeals_supplement', value)
    },
    setMessageidd({ commit }, value) {
        commit('setMessageidd', value)
    },
    setPackage_category({ commit }, value) {
        commit('setPackage_category', value)
    },
    setPickup_address({ commit }, value) {
        commit('setPickup_address', value)
    },
    setPickup_location({ commit }, value) {
        commit('setPickup_location', value)
    },
    setQuery_feel({ commit }, value) {
        commit('setQuery_feel', value)
    },
    setRemark({ commit }, value) {
        commit('setRemark', value)
    },
    setRemarkedit({ commit }, value) {
        commit('setRemarkedit', value)
    },
    setRemarklead({ commit }, value) {
        commit('setRemarklead', value)
    },

    setScore({ commit }, value) {
        commit('setScore', value)
    },
    setScore_new({ commit }, value) {
        commit('setScore_new', value)
    },
    setTotal_room({ commit }, value) {
        commit('setTotal_room', value)
    },
    setTotal_tour_days({ commit }, value) {
        commit('setTotal_tour_days', value)
    },
    setTour_cost({ commit }, value) {
        commit('setTour_cost', value)
    },
    setTour_cost_tax({ commit }, value) {
        commit('setTour_cost_tax', value)
    },
    setTour_id({ commit }, value) {
        commit('setTour_id', value)
    },
    setTour_name({ commit }, value) {
        commit('setTour_name', value)
    },
    setTour_location({ commit }, value) {
        commit('setTour_location', value)
    },
    setTour_location_obj({ commit }, value) {
        commit('setTour_location_obj', value)
    },
    setIinerary_places_obj({ commit }, value) {
        commit('setIinerary_places_obj', value)
    },

    sethotel_only({ commit }, value) {
        commit('sethotel_only',value)
    },
    setcreatedid({ commit }, value) {
        commit('setcreatedid',value)
    },

    setCreated_by({ commit }, value) {
        commit('setCreated_by', value)
    },
    setCreated_by_team({ commit }, value) {
        commit('setCreated_by_team', value)
    },
    resetState({ commit }) {
        commit('resetState')
    }
}

const mutations = {
    setItem(state, item) {

        console.log("tour_location");
        // console.log(JSON.parse(item.tour_location));
        //  state.item = item
        // console.log(item);
        state.item = item
        console.log(item.itinerary_places);
        state.item.itinerary_places=JSON.parse(item.itinerary_places);

        console.log(state.item.itinerary_places);
        state.item.tour_location=JSON.parse(item.tour_location);


        state.item.meals_supplement=JSON.parse(item.meals_supplement);
        state.item.tour_cost=JSON.parse(item.tour_cost);
        state.item.remarks=JSON.parse(item.remarks);
        console.log("tour_location after");
        console.log(state.item.tour_location);

        state.meta_data = item.get_meta;

        console.log(state.meta_data);

        state.meta_data.forEach(function(e){

            if(e.meta_key=='meta_infant'){

                state.meta.meta_infant=e.meta_value;
            }

            if(e.meta_key=='meta_extra_bed'){

                state.meta.meta_extra_bed=e.meta_value;
            }
            if(e.meta_key=='meta_transport'){

                state.meta.meta_transport=e.meta_value;
            }
            if(e.meta_key=='meta_source'){


                state.meta.meta_source=e.meta_value;
            }
            if(e.meta_key=='meta_flightprice'){

                state.meta.meta_flightprice=e.meta_value;
            }
            if(e.meta_key=='meta_flight'){

                state.meta.meta_flight=e.meta_value;
            }
            if(e.meta_key=='meta_welcome_mail'){

                state.meta.meta_welcome_mail=e.meta_value;
            }
            if(e.meta_key=='meta_incl_ex'){

                state.meta.meta_incl_ex=e.meta_value;
            }
            if(e.meta_key=='meta_closuer'){

                state.meta.meta_closuer=e.meta_value;
            }
            if(e.meta_key=='meta_exp_cost'){

                state.meta.meta_exp_cost=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='meta_exp_costflight'){

                state.meta.meta_exp_costflight=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='markup1'){

                state.meta.markup1=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='markup2'){

                state.meta.markup2=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='sellingprice1'){

                state.meta.sellingprice1=e.meta_value;
            }
            if(e.meta_key=='sellingprice2'){

                state.meta.sellingprice2=e.meta_value;
            }
            if(e.meta_key=='interactions'){

                state.meta.interactions=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='lost'){

                state.meta.lost=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='by_lead'){

                state.meta.by_lead=e.meta_value;
            }
            if(e.meta_key=='last_quote_no'){

                state.meta.last_quote_no=e.meta_value;
            }


            if(e.meta_key=='meta_executive_name'){

                state.meta.meta_executive_name=e.meta_value;
            }
            if(e.meta_key=='meta_executive_no'){

                state.meta.meta_executive_no=e.meta_value;
            }

        });
    },


    setclonedata(state, value) {

        state.item=value;
        console.log("query cloning")
        console.log(state.item)
        // console.log(value)
    },
    setclonedatameta(state, value) {

        state.meta=value;

    },

    setDriver_pickup_date_time(state, value) {
        state.item.driver_pickup_date_time = value;

        // console.log(moment(moment(value).format("YYYY-MM-DD")).add(5,'days').format("DD MMM YYYY"))
        var date_ori=value;
        if(state.item.tour_location){
            for(var i=0;i < state.item.tour_location.length;i++ ){

                state.item.tour_location[i]['date_from']=moment(moment(date_ori).format("YYYY-MM-DD")).add(0,'days').format("DD MMM YYYY");
                state.item.tour_location[i]['daynights']=parseInt(state.item.tour_location[i]['days'])+1;
                // if(i==0){
                //     var firstday=parseInt(state.item.tour_location[i]['days']) - 1;
                //     state.item.tour_location[i]['date_to']=moment(moment(state.item.tour_location[i]['date_from']).format("YYYY-MM-DD")).add(firstday,'days').format("DD MMM YYYY");
                //     date_ori=state.item.tour_location[i]['date_to'] ;
                // }
                // // else if(i==parseInt(state.item.tour_location.length)-1){
                // //     var lastday=parseInt(state.item.tour_location[i]['days']) + 1;
                // //     state.item.tour_location[i]['date_to']=moment(moment(state.item.tour_location[i]['date_from']).format("YYYY-MM-DD")).add(state.item.tour_location[i]['days'],'days').format("DD MMM YYYY");
                // //     date_ori=state.item.tour_location[i]['date_to'] ;
                // //
                // // }
                // else {
                state.item.tour_location[i]['date_to']=moment(moment(state.item.tour_location[i]['date_from']).format("YYYY-MM-DD")).add(state.item.tour_location[i]['days'],'days').format("DD MMM YYYY");
                date_ori=state.item.tour_location[i]['date_to'] ;
                // }

            }

        }

        // state.item.tour_location
    },
    setBooking_id(state, value) {
        state.item.booking_id = value
    },

//     setplaces(state, value) {
//     state.item.places.push(value)
// },
    setBudget(state, value) {
        state.item.budget = value
    },
    setTraveler_name(state, value) {
        state.item.traveler_name = value
    },
    setBill_pay(state, value) {
        state.item.bill_pay = value
    },
    setNo_of_adults(state, value) {
        state.item.no_of_adults = value
    },
    setNo_of_children(state, value) {
        state.item.no_of_children = value
    },

    addplacemodal(state, value) {
        state.addplacemodal = value
    },
    tourdata(state, value) {
        state.tourdata = value
    },

    setmeta_infant(state, value) {
        state.meta.meta_infant = value
    },
    setmeta_extra_bed(state, value) {
        state.meta.meta_extra_bed = value
    },


    setmeta_transport(state, value) {
        state.meta.meta_transport = value
    },
    setmeta_source(state, value) {
        state.meta.meta_source = value
    },
    setmeta_flightprice(state, value) {
        state.meta.meta_flightprice = value
    },
    setmeta_flight(state, value) {
        state.meta.meta_flight = value
    },
    setmeta_welcome_mail(state, value) {
        state.meta.meta_welcome_mail = value
    },
    setmeta_incl_ex(state, value) {
        state.meta.meta_incl_ex = value
    },
    setmeta_closuer(state, value) {
        state.meta.meta_closuer = value
    },
    setmeta_exp_cost(state, value) {
        state.meta.meta_exp_cost = value
    },

    setmeta_exp_costflight(state, value) {
        state.meta.meta_exp_costflight = value
    },
    setmarkup1(state, value) {
        state.meta.markup1 = value
    },
    setmarkup2(state, value) {
        state.meta.markup2 = value
    },
    setsellingprice1(state, value) {
        state.meta.sellingprice1 = value
    },
    setsellingprice2(state, value) {
        state.meta.sellingprice2 = value
    },

    setmeta_interactions(state, value) {

        if(state.meta.interactions.hasOwnProperty(todaydate()) ){
            state.meta.interactions[todaydate()].push(value)
        }
        else {
            state.meta.interactions[todaydate()] =[value]
        }

    },
    setmeta_interactionsfull(state, value) {
console.log('setmeta_interactionsfull');
if(!_.isEmpty(value)){
    value.forEach( (dataObj) => {
        console.log(dataObj.time)
        const today = new Date(dataObj.time*1000);
        const date1 = today.getDate()+'-'+(today.getMonth()+1)+'-'+today.getFullYear();

        var datetag=  date1;
        console.log(datetag);
        if(state.meta.interactions.hasOwnProperty(datetag) ){
            console.log('in1');
            var i=0;
            var flag="nan";
            state.meta.interactions[datetag].forEach( (intObj) => {

                console.log('in2');
                console.log(intObj.time);
                console.log(dataObj.time);
                if(intObj.time===dataObj.time){
                    console.log('found');

                    flag="found";
                }


                i++;
            });
            if(flag!=='found'){
                console.log('in3');
                console.log(dataObj);
                if(typeof dataObj.title !=="undefined"){
// alert("up");
                    state.meta.interactions[datetag].push(dataObj);
                }else {
                    // alert("down");
                    state.meta.interactions[datetag].push({"title":"Remark","status":"Done","type":"remark","remark":dataObj.remark,"agent":document.querySelector("meta[name='user-name']").getAttribute('content'),"time":dataObj.time})

                }

                   }

        }
        else {
            console.log('in4');
            if (typeof dataObj.title != "undefined") {
                if(typeof state.meta.interactions[datetag]!= "undefined"){
                    state.meta.interactions[datetag].push(dataObj);
                }
             else {
                    state.meta.interactions[datetag] = [dataObj];
                }
            } else {
                state.meta.interactions[datetag] = [{
                    "title": "Remark",
                    "status": "Done",
                    "type": "remark",
                    "remark": dataObj.remark,
                    "agent": document.querySelector("meta[name='user-name']").getAttribute('content'),
                    "time": dataObj.time
                }]
            }
        }

    });
}




    },
    setmeta_lost(state, value) {
        state.meta.lost = value
    },
    setby_lead(state, value) {
        state.meta.by_lead = value
    },
    setlast_quote_no(state, value) {
        state.meta.last_quote_no = value
    },

    setlead_data(state, value) {
        state.lead_data = value
    },
    setlead_meta(state, value) {
        state.lead_meta = value
    },
    setclone_data(state, value) {
        state.clone_data = value
    },
    setclone_meta(state, value) {
        state.clone_meta = value
    },
    setclonenew(state, value) {
        state.clonenew = value
    },

    setmeta_executive_name(state, value) {
        state.meta.meta_executive_name = value
    },
    setmeta_executive_no(state, value) {
        state.meta.meta_executive_no = value
    },



    setNote(state, value) {
        state.item.note = value
    },
    setStatus(state, value) {
        state.item.status = value
    },
    setPhone(state, value) {
        state.item.phone = value
    },
    setEmail(state, value) {
        state.item.email = value
    },

    setEmail_second(state, value) {
        state.item.email_second = value
    },
    setTraveller_id(state, value) {
        state.item.traveller_id = value
    },
    setGenerated_itinerary(state, value) {
        state.item.generated_itinerary = value
    },
    setItinerary_places(state, value) {



        if(state.item.itinerary_places!=null){
            // var    e_array=Object.entries(JSON.parse(state.item.itinerary_places))
            //
            // alert("not null");

            if( state.item.itinerary_places.hasOwnProperty(value)){
                // alert("up");
                //   console.log(this.objj);
                if(this.objj[locationid].hasOwnProperty(day)){

                }
            }
            // e_array.push(value)
            // state.item.itinerary_places=JSON.stringify(e_array)
            //   console.log(state.item.itinerary_places);
            state.item.itinerary_places=Object.assign(state.item.itinerary_places, value);

        }
        else {
            // alert("null");
//console.log(value);
            state.item.itinerary_places=value
            //  console.log(state.item.itinerary_places);
        }


    },
    setAgency_id(state, value) {
        state.item.agency_id = value
    },
    setAgent_id(state, value) {
        state.item.agent_id = value
    },
    setMeal_day(state, value) {
        state.item.meal_day = value
    },
    setMeals_supplement(state, value) {
        state.item.meals_supplement = value
    },
    setMessageidd(state, value) {
        state.item.messageidd = value
    },
    setPackage_category(state, value) {
        state.item.package_category = value
    },
    setPickup_address(state, value) {
        state.item.pickup_address = value
    },
    setPickup_location(state, value) {
        state.item.pickup_location = value
    },
    setQuery_feel(state, value) {
        state.item.query_feel = value
    },
    setRemarkedit(state, value) {

        // remark: [{"remark":"","agent":"","time":""}],
        if(_.isEmpty(state.item.remarks)){
            var rem= _.cloneDeep(value)
            state.item.remarks = [built_remark(rem)];
        }
        else {
            var rem= _.cloneDeep(value)
            var len= state.item.remarks.length
            state.item.remarks[len]=built_remark(rem)
        }


    },
    setRemark(state, value) {
        // remark: [{"remark":"","agent":"","time":""}],
        var len= state.item.remarks.length
        state.item.remarks[len]=built_remark(value)

    },
    setRemarklead(state, value) {

        state.item.remarks=value

    },


    setScore(state, value) {
        state.item.score = value
    },
    setScore_new(state, value) {
        state.item.score_new = value
    },
    setTotal_room(state, value) {
        state.item.total_room = value
    },
    setTotal_tour_days(state, value) {
        state.item.total_tour_days = value
    },
    setTour_cost(state, value) {
        state.item.tour_cost = value
    },
    setTour_cost_tax(state, value) {
        state.item.tour_cost_tax = value
    },
    setTour_id(state, value) {
        state.item.tour_id = value
    },
    setTour_name(state, value) {
        state.item.tour_name = value
    },
    setTour_location(state, value) {
        state.item.tour_location = value
    },
    setTour_location_obj(state, value) {
        state.item.tour_location_obj = value
    },
    setIinerary_places_obj(state, value) {
        state.item.itinerary_places_obj = value
    },


    sethotel_only(state, value) {
        state.hotel_only = value
    },
    setcreatedid(state, value) {
        state.createdid = value
    },

    setCreated_by(state, value) {
        state.item.created_by = value
    },
    setCreated_by_team(state, value) {
        state.item.created_by_team = value
    },
    setUsersAll(state, value) {
        state.usersAll = value
    },
    setTeamsAll(state, value) {
        state.teamsAll = value
    },
    setcityid(state, value){
        state.cityid = value
    },
    sethotel(state, value){
        //   state.hotels =Object.assign( state.hotels,value)

        if(_.isEmpty(state.hotels)){
            state.hotels=Object.assign({},{[value.location_id] : value.hotel})
        }
        else {
            state.hotels=Object.assign(state.hotels,{[value.location_id] : value.hotel})
            state.hotels=Object.assign({},state.hotels)
        }

    },

    setplace(state, value){
        console.log(value.data)
// var places_city_id={};
//         state.places.cites.forEach((val) => {
//             var gg=val.id;
//             if(gg.split('-')[0]==state.cityid){
//                 places_city_id.push(value)
//             }
//
//
//         });
        if(_.isEmpty(state.places.places_city_id)){
            state.places.places_city_id=Object.assign({},{[value.id] : value.data})
        }
        else {
            state.places.places_city_id=Object.assign(state.places.places_city_id,{[value.id] : value.data})
            state.places.places_city_id=Object.assign({},state.places.places_city_id)
        }

        //  state.places.places_city_id.push(value.data)
    },
    setLoading(state, loading) {
        state.loading = loading
    },
    setTourAll(state, loading) {


        state.tourAll = loading
    },
    resetState(state) {
        state = Object.assign(state, initialState())
    },
    setCityAll(state, value) {
        state.cityAll = value
    },



}

export default {
    namespaced: true,
    state: initialState,
    getters,
    actions,
    mutations
}
