function initialState() {
    return {
        item: {
            id: null,
            name: null,
            email: null,
            password: null,
            role: [],
            approved: false,
            team: null,
            account_manager: null,
            agree: null,
            banner_color: null,
            address: null,
            city: null,
            state: null,
            country: null,
            phone: null,
            postcode: null,
            company: null,
            device: null,
            locale: null,
            login: null,
            login_date_time: null,
            login_status: null,
            logo: null,
            mycred_default: null,
            mycred_default_total: null,
            mycred_epp_mycred: null,
            owners_email: null,
        },
        rolesAll: [],
        teamsAll: [],
        citiesAll: [],
        statesAll: [],
        countriesAll: [],
        agencyAll:[],

        loading: false,
        meta:{
            // meta_color:{'agency':'','agent':''},
            meta_bio_metric_mail:null,
            meta_bio_metric_sms:null,
            meta_cloure_note_i:null,
            meta_cloure_note_q:null,
            meta_doc_not_rec_mail:null,
            meta_doc_not_rec_sms:null,
            meta_doc_tags:[],
            meta_incex_note_i:null,
            meta_incex_note_q:null,
            meta_interview_mail:null,
            meta_interview_sms:null,
            meta_notification_history:null,
            meta_paid_bal_total:null,
            meta_price_mode_user:null,
            meta_registered_thru:null,
            meta_score:null,
            meta_sms_i:null,
            meta_supplier:null,
            meta_token_id:null,
            meta_welcome_group:null,
            meta_welcome_note_i:null,
            meta_welcome_note_q:null,
            meta_subscription:false,
            meta_licence: {"type":"Point","exp_date":'',"start_date":''
                ,"query":"10"
                ,"itinerary":"10"
                ,"group":"10"
                ,"broadcast_to_all":"10"
                ,"broadcast_to_live":"10"
                ,"direct":"10"
                ,"exhibitor":"10"
                ,"nomination":"10"


            },


        },
        meta_data:null,
    }
}

const getters = {
    item: state => state.item,
    loading: state => state.loading,
    rolesAll: state => state.rolesAll,
    teamsAll: state => state.teamsAll,
    citiesAll: state => state.citiesAll,
    statesAll: state => state.statesAll,
    countriesAll: state => state.countriesAll,
    agencyAll: state => state.agencyAll,
    meta: state => state.meta,
}

const actions = {
    storeData({ commit, state, dispatch }) {
        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();


            state.meta.meta_licence=JSON.stringify(state.meta.meta_licence)
            state.meta.meta_doc_tags=JSON.stringify(state.meta.meta_doc_tags)
            params.set('meta', JSON.stringify(state.meta));
            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {
                    // console.log(fieldName);
                    // console.log(fieldName);
                    // console.log(1);
                    params.set(fieldName, fieldValue);
                } else {
                    // console.log(fieldName);
                    // console.log(2);
                    if(fieldName=='company'){
                        // console.log(fieldName);
                        // console.log(4);
                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                else if (fieldValue && typeof fieldValue[0] !== 'object') {
                        // console.log(fieldName);
                        // console.log(3);
                        params.set(fieldName, fieldValue);
                    }


                    else {
                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (_.isEmpty(state.item.role)) {
                params.delete('role')
            } else {
                for (let index in state.item.role) {
                    params.set('role['+index+']', state.item.role[index].id)
                }
            }
            params.set('approved', state.item.approved ? 1 : 0)
            if (_.isEmpty(state.item.team)) {
                params.set('team_id', '')
            } else {
                params.set('team_id', state.item.team.id)
            }
            if (_.isEmpty(state.item.city)) {
                params.set('city_id', '')
            } else {
                params.set('city_id', state.item.city.id)
            }
            if (_.isEmpty(state.item.state)) {
                params.set('state_id', '')
            } else {
                params.set('state_id', state.item.state.id)
            }
            if (_.isEmpty(state.item.country)) {
                params.set('country_id', '')
            } else {
                params.set('country_id', state.item.country.id)
            }
            if (state.item.logo === null) {
                params.delete('logo');
            }

            axios.post('/api/v1/users', params)
                .then(response => {
                    commit('resetState')
                    resolve()
                })
                .catch(error => {
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    updateData({ commit, state, dispatch }) {
        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();
            params.set('_method', 'PUT')
            state.meta.meta_licence=JSON.stringify(state.meta.meta_licence)
            state.meta.meta_doc_tags=JSON.stringify(state.meta.meta_doc_tags)
            params.set('meta', JSON.stringify(state.meta));
            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {
                    // console.log(fieldName);
                    // console.log(1);
                    params.set(fieldName, fieldValue);
                } else {
                    // console.log(fieldName);
                    // console.log(2);
                    if(fieldName=='company'){
                        // console.log(fieldName);
                        // console.log(4);
                        params.set(fieldName, JSON.stringify(fieldValue));

                    }
                    else if (fieldValue && typeof fieldValue[0] !== 'object') {
                        // console.log(fieldName);
                        // console.log(3);
                        params.set(fieldName, fieldValue);
                    }


                    else {
                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (_.isEmpty(state.item.role)) {
                params.delete('role')
            } else {
                for (let index in state.item.role) {
                    params.set('role['+index+']', state.item.role[index].id)
                }
            }
            params.set('approved', state.item.approved ? 1 : 0)
            if (_.isEmpty(state.item.team)) {
                params.set('team_id', '')
            } else {
                params.set('team_id', state.item.team.id)
            }
            if (_.isEmpty(state.item.city)) {
                params.set('city_id', '')
            } else {
                params.set('city_id', state.item.city.id)
            }
            if (_.isEmpty(state.item.state)) {
                params.set('state_id', '')
            } else {
                params.set('state_id', state.item.state.id)
            }
            if (_.isEmpty(state.item.country)) {
                params.set('country_id', '')
            } else {
                params.set('country_id', state.item.country.id)
            }
            if (state.item.logo === null) {
                params.delete('logo');
            }

            axios.post('/api/v1/users/' + state.item.id, params)
                .then(response => {
                    // commit('setItem', response.data.data)
                    resolve()
                })
                .catch(error => {
                    state.meta.meta_licence=JSON.parse(state.meta.meta_licence)
                    state.meta.meta_doc_tags=JSON.parse(state.meta.meta_doc_tags)
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    fetchData({ commit, dispatch }, id) {
        axios.get('/api/v1/users/' + id)
            .then(response => {
                commit('setItem', response.data.data)
            })

        dispatch('fetchRolesAll')
    dispatch('fetchTeamsAll')
    dispatch('fetchCitiesAll')
    dispatch('fetchStatesAll')
    dispatch('fetchCountriesAll')
        dispatch('fetchAgencyAll')

    },
    fetchRolesAll({ commit }) {
        axios.get('/api/v1/roles')
            .then(response => {
                commit('setRolesAll', response.data.data)
            })
    },
    fetchTeamsAll({ commit }) {
        axios.get('/api/v1/teams')
            .then(response => {
                commit('setTeamsAll', response.data.data)
            })
    },
    fetchCitiesAll({ commit }) {
        axios.get('/api/v1/cities')
            .then(response => {
                commit('setCitiesAll', response.data.data)
            })
    },
    fetchStatesAll({ commit }) {
        axios.get('/api/v1/states')
            .then(response => {
                commit('setStatesAll', response.data.data)
            })
    },
    fetchCountriesAll({ commit }) {
        axios.get('/api/v1/countries')
            .then(response => {
                commit('setCountriesAll', response.data.data)
            })
    },
    fetchAgencyAll({ commit }) {
        axios.get('/api/v1/agency')
            .then(response => {
                commit('setAgencyAll', response.data.data)
            })
    },


    setName({ commit }, value) {
        commit('setName', value)
    },
    setEmail({ commit }, value) {
        commit('setEmail', value)
    },
    setPassword({ commit }, value) {
        commit('setPassword', value)
    },
    setRole({ commit }, value) {
        commit('setRole', value)
    },
    setApproved({ commit }, value) {
        commit('setApproved', value)
    },
    setTeam({ commit }, value) {
        commit('setTeam', value)
    },
    setAccount_manager({ commit }, value) {
        commit('setAccount_manager', value)
    },
    setAgree({ commit }, value) {
        commit('setAgree', value)
    },
    setBanner_color({ commit }, value) {
        commit('setBanner_color', value)
    },
    setAddress({ commit }, value) {
        commit('setAddress', value)
    },
    setCity({ commit }, value) {
        commit('setCity', value)
    },
    setState({ commit }, value) {
        commit('setState', value)
    },
    setCountry({ commit }, value) {
        commit('setCountry', value)
    },
    setPhone({ commit }, value) {
        commit('setPhone', value)
    },
    setPostcode({ commit }, value) {
        commit('setPostcode', value)
    },
    setCompany({ commit }, value) {
        commit('setCompany', value)
    },
    setDevice({ commit }, value) {
        commit('setDevice', value)
    },
    setLocale({ commit }, value) {
        commit('setLocale', value)
    },
    setLogin({ commit }, value) {
        commit('setLogin', value)
    },
    setLogin_date_time({ commit }, value) {
        commit('setLogin_date_time', value)
    },
    setLogin_status({ commit }, value) {
        commit('setLogin_status', value)
    },
    setLogo({ commit }, value) {
        commit('setLogo', value)
    },

    setMycred_default({ commit }, value) {
        commit('setMycred_default', value)
    },
    setMycred_default_total({ commit }, value) {
        commit('setMycred_default_total', value)
    },
    setMycred_epp_mycred({ commit }, value) {
        commit('setMycred_epp_mycred', value)
    },
    setOwners_email({ commit }, value) {
        commit('setOwners_email', value)
    },

    //meta


        setmeta_bio_metric_mail({ commit }, value) {
    commit('setmeta_bio_metric_mail', value)
},
    setmeta_bio_metric_sms({ commit }, value) {
        commit('setmeta_bio_metric_sms', value)
    },
setmeta_cloure_note_i({ commit }, value) {
    commit('setmeta_cloure_note_i', value)
},
    setmeta_cloure_note_q({ commit }, value) {
        commit('setmeta_cloure_note_q', value)
    },
setmeta_doc_not_rec_mail({ commit }, value) {
    commit('setmeta_doc_not_rec_mail', value)
},
    setmeta_doc_not_rec_sms({ commit }, value) {
        commit('setmeta_doc_not_rec_sms', value)
    },
setmeta_incex_note_i({ commit }, value) {
    commit('setmeta_incex_note_i', value)
},
    setmeta_incex_note_q({ commit }, value) {
        commit('setmeta_incex_note_q', value)
    },
setmeta_interview_mail({ commit }, value) {
    commit('setmeta_interview_mail', value)
},
    setmeta_interview_sms({ commit }, value) {
        commit('setmeta_interview_sms', value)
    },
setmeta_price_mode_user({ commit }, value) {
    commit('setmeta_price_mode_user', value)
},
    setmeta_registered_thru({ commit }, value) {
        commit('setmeta_registered_thru', value)
    },
setmeta_score({ commit }, value) {
    commit('setmeta_score', value)
},
    setmeta_sms_i({ commit }, value) {
        commit('setmeta_sms_i', value)
    },
setmeta_welcome_group({ commit }, value) {
    commit('setmeta_welcome_group', value)
},
    setmeta_welcome_note_i({ commit }, value) {
        commit('setmeta_welcome_note_i', value)
    },
setmeta_welcome_note_q({ commit }, value) {
    commit('setmeta_welcome_note_q', value)
},
    setmeta_subscription({ commit }, value) {
        commit('setmeta_subscription', value)
    },
    setmeta_licence({ commit }, value) {
        commit('setmeta_licence', value)
    },



    resetState({ commit }) {
        commit('resetState')
    }
}

const mutations = {
    setItem(state, item) {
        state.item = item
        console.log(item);
        state.meta_data = item.get_meta;
        if(item.company){
        state.item.company = JSON.parse(item.company);}
        // state.meta_data.meta_doc_tags = JSON.parse(item.get_meta.meta_doc_tags);
        // console.log(state.meta_data);




        state.meta_data.forEach(function(e){

            // if(e.meta_key=='meta_color'){
            //
            //     state.meta.meta_color=e.meta_value;
            // }
            if(e.meta_key=='meta_doc_tags'){
            // console.log(e.meta_value);
                state.meta.meta_doc_tags=JSON.parse(e.meta_value);
            }
            if(e.meta_key=='meta_bio_metric_mail'){

                state.meta.meta_bio_metric_mail=e.meta_value;
            }
            if(e.meta_key=='meta_bio_metric_sms'){


                state.meta.meta_bio_metric_sms=e.meta_value;
            }
            if(e.meta_key=='meta_cloure_note_i'){

                state.meta.meta_cloure_note_i=e.meta_value;
            }
            if(e.meta_key=='meta_cloure_note_q'){

                state.meta.meta_cloure_note_q=e.meta_value;
            }
            if(e.meta_key=='meta_doc_not_rec_mail'){

                state.meta.meta_doc_not_rec_mail=e.meta_value;
            }
            if(e.meta_key=='meta_doc_not_rec_sms'){

                state.meta.meta_doc_not_rec_sms=e.meta_value;
            }
            if(e.meta_key=='meta_incex_note_i'){

                state.meta.meta_incex_note_i=e.meta_value;
            }
            if(e.meta_key=='meta_incex_note_q'){

                state.meta.meta_incex_note_q=e.meta_value;
            }
            if(e.meta_key=='meta_interview_mail'){

                state.meta.meta_interview_mail=e.meta_value;
            }
            if(e.meta_key=='meta_interview_sms'){

                state.meta.meta_interview_sms=e.meta_value;
            }
            if(e.meta_key=='meta_notification_history'){

                state.meta.meta_notification_history=e.meta_value;
            }
            if(e.meta_key=='meta_paid_bal_total'){

                state.meta.meta_paid_bal_total=e.meta_value;
            }
            if(e.meta_key=='meta_price_mode_user'){

                state.meta.meta_price_mode_user=e.meta_value;
            }
            if(e.meta_key=='meta_registered_thru'){

                state.meta.meta_registered_thru=e.meta_value;
            }
            if(e.meta_key=='meta_score'){

                state.meta.meta_score=e.meta_value;
            }
            if(e.meta_key=='meta_sms_i'){

                state.meta.meta_sms_i=e.meta_value;
            }
            if(e.meta_key=='meta_supplier'){

                state.meta.meta_supplier=e.meta_value;
            }
            if(e.meta_key=='meta_token_id'){

                state.meta.meta_token_id=e.meta_value;
            }
            if(e.meta_key=='meta_welcome_group'){

                state.meta.meta_welcome_group=e.meta_value;
            }
            if(e.meta_key=='meta_welcome_note_i'){

                state.meta.meta_welcome_note_i=e.meta_value;
            }
            if(e.meta_key=='meta_welcome_note_q'){

                state.meta.meta_welcome_note_q=e.meta_value;
            }
            if(e.meta_key=='meta_subscription'){

                state.meta.meta_subscription=parseInt(e.meta_value);
            }
            if(e.meta_key=='meta_licence'){

                state.meta.meta_licence=JSON.parse(e.meta_value);
            }

        });
    },

    setName(state, value) {
        state.item.name = value
    },
    setEmail(state, value) {
        state.item.email = value
    },
    setPassword(state, value) {
        state.item.password = value
    },
    setRole(state, value) {
        state.item.role = value
    },
    setApproved(state, value) {
        state.item.approved = value
    },
    setTeam(state, value) {
        state.item.team = value
    },
    setAccount_manager(state, value) {
        state.item.account_manager = value
    },
    setAgree(state, value) {
        state.item.agree = value
    },
    setBanner_color(state, value) {
        state.item.banner_color = value
    },
    setAddress(state, value) {
        state.item.address = value
    },
    setCity(state, value) {
        state.item.city = value
    },
    setState(state, value) {
        state.item.state = value
    },
    setCountry(state, value) {
        state.item.country = value
    },
    setPhone(state, value) {
        state.item.phone = value
    },
    setPostcode(state, value) {
        state.item.postcode = value
    },
    setCompany(state, value) {
        state.item.company = value
    },
    setDevice(state, value) {
        state.item.device = value
    },
    setLocale(state, value) {
        state.item.locale = value
    },
    setLogin(state, value) {
        state.item.login = value
    },
    setLogin_date_time(state, value) {
        state.item.login_date_time = value
    },
    setLogin_status(state, value) {
        state.item.login_status = value
    },
    setLogo(state, value) {
        state.item.logo = value
    },
    setMycred_default(state, value) {
        state.item.mycred_default = value
    },
    setMycred_default_total(state, value) {
        state.item.mycred_default_total = value
    },
    setMycred_epp_mycred(state, value) {
        state.item.mycred_epp_mycred = value
    },
    setOwners_email(state, value) {
        state.item.owners_email = value
    },
    setRolesAll(state, value) {
        state.rolesAll = value
    },
    setTeamsAll(state, value) {
        state.teamsAll = value
    },
    setCitiesAll(state, value) {
        state.citiesAll = value
    },
    setStatesAll(state, value) {
        state.statesAll = value
    },
    setCountriesAll(state, value) {
        state.countriesAll = value
    },
    setAgencyAll(state, value) {
        state.agencyAll = value
    },

    //meta
    setmeta_bio_metric_mail(state, value) {
        state.meta.meta_bio_metric_mail = value
    },
    setmeta_bio_metric_sms(state, value) {
        state.meta.meta_bio_metric_sms = value
    },
    setmeta_cloure_note_i(state, value) {
        state.meta.meta_cloure_note_i = value
    },
    setmeta_cloure_note_q(state, value) {
        state.meta.meta_cloure_note_q = value
    },
    setmeta_doc_not_rec_mail(state, value) {
        state.meta.meta_doc_not_rec_mail = value
    },
    setmeta_doc_not_rec_sms(state, value) {
        state.meta.meta_doc_not_rec_sms = value
    },
    setmeta_incex_note_i(state, value) {
        state.meta.meta_incex_note_i = value
    },
    setmeta_incex_note_q(state, value) {
        state.meta.meta_incex_note_q = value
    },
    setmeta_interview_mail(state, value) {
        state.meta.meta_interview_mail = value
    },



    setmeta_interview_sms(state, value) {
        state.meta.meta_interview_sms = value
    },
    setmeta_price_mode_user(state, value) {
        state.meta.meta_price_mode_user = value
    },
    setmeta_registered_thru(state, value) {
        state.meta.meta_registered_thru = value
    },
    setmeta_score(state, value) {
        state.meta.meta_score = value
    },
    setmeta_sms_i(state, value) {
        state.meta.meta_sms_i = value
    },
    setmeta_welcome_group(state, value) {
        state.meta.meta_welcome_group = value
    },
    setmeta_welcome_note_i(state, value) {
        state.meta.meta_welcome_note_i = value
    },
    setmeta_welcome_note_q(state, value) {
        state.meta.meta_welcome_note_q = value
    },
    setmeta_subscription(state, value) {
        state.meta.meta_subscription = value
    },
    setmeta_licence(state, value) {
        state.meta.meta_licence = value
    },


    setLoading(state, loading) {
        state.loading = loading
    },
    resetState(state) {
        state = Object.assign(state, initialState())
    }
}

export default {
    namespaced: true,
    state: initialState,
    getters,
    actions,
    mutations
}
