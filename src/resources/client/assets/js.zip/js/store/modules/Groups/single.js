function initialState() {
    return {
        item: {
            id: null,
            booking_id: null,
            full_name: null,
            email: null,
            phone: null,
            activated: null,
            no_of_adults: null,
            no_of_children: null,
            agency_id: null,
            agent_id: null,
            meal_day: null,
            bill_pay: null,
            driver_pick_up_time: null,
            driver_pick_up_time_updated: null,
            drop_address: null,
            handler_name: null,
            handler_no: null,
            meals_supplement: null,
            package_category: null,
            pickup_address: null,
            pickup_location: null,
            total_price: null,
            tour_cost: null,
            selected_car: null,
            status: null,
            supplier_id: null,
            total_room: null,
            total_tour_days: null,
            traveller_id: null,
            tour_id: null,
            itinerary_places: null,
            itinerary_places_time: null,
            group: null,
            group_name: null,
            group_id: null,
            group_logo: null,
            group_place: null,
            members: null,
            tour_cost_tax: null,
            tour_handler: null,
            tour_name: null,
            tour_location: null,
            created_by: null,
            created_by_team: null,
        },
        usersAll: [],
        teamsAll: [],
        
        loading: false,
    }
}

const getters = {
    item: state => state.item,
    loading: state => state.loading,
    usersAll: state => state.usersAll,
    teamsAll: state => state.teamsAll,
    
}

const actions = {
    storeData({ commit, state, dispatch }) {
        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();

            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {
                    params.set(fieldName, fieldValue);
                } else {
                    if (fieldValue && typeof fieldValue[0] !== 'object') {
                        params.set(fieldName, fieldValue);
                    } else {
                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (state.item.group_logo === null) {
                params.delete('group_logo');
            }
            if (_.isEmpty(state.item.created_by)) {
                params.set('created_by_id', '')
            } else {
                params.set('created_by_id', state.item.created_by.id)
            }
            if (_.isEmpty(state.item.created_by_team)) {
                params.set('created_by_team_id', '')
            } else {
                params.set('created_by_team_id', state.item.created_by_team.id)
            }

            axios.post('/api/v1/groups', params)
                .then(response => {
                    commit('resetState')
                    resolve()
                })
                .catch(error => {
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    updateData({ commit, state, dispatch }) {
        commit('setLoading', true)
        dispatch('Alert/resetState', null, { root: true })

        return new Promise((resolve, reject) => {
            let params = new FormData();
            params.set('_method', 'PUT')

            for (let fieldName in state.item) {
                let fieldValue = state.item[fieldName];
                if (typeof fieldValue !== 'object') {
                    params.set(fieldName, fieldValue);
                } else {
                    if (fieldValue && typeof fieldValue[0] !== 'object') {
                        params.set(fieldName, fieldValue);
                    } else {
                        for (let index in fieldValue) {
                            params.set(fieldName + '[' + index + ']', fieldValue[index]);
                        }
                    }
                }
            }

            if (state.item.group_logo === null) {
                params.delete('group_logo');
            }
            if (_.isEmpty(state.item.created_by)) {
                params.set('created_by_id', '')
            } else {
                params.set('created_by_id', state.item.created_by.id)
            }
            if (_.isEmpty(state.item.created_by_team)) {
                params.set('created_by_team_id', '')
            } else {
                params.set('created_by_team_id', state.item.created_by_team.id)
            }

            axios.post('/api/v1/groups/' + state.item.id, params)
                .then(response => {
                    commit('setItem', response.data.data)
                    resolve()
                })
                .catch(error => {
                    let message = error.response.data.message || error.message
                    let errors  = error.response.data.errors

                    dispatch(
                        'Alert/setAlert',
                        { message: message, errors: errors, color: 'danger' },
                        { root: true })

                    reject(error)
                })
                .finally(() => {
                    commit('setLoading', false)
                })
        })
    },
    fetchData({ commit, dispatch }, id) {
        axios.get('/api/v1/groups/' + id)
            .then(response => {
                commit('setItem', response.data.data)
            })

        dispatch('fetchUsersAll')
    dispatch('fetchTeamsAll')
    },
    fetchUsersAll({ commit }) {
        axios.get('/api/v1/users')
            .then(response => {
                commit('setUsersAll', response.data.data)
            })
    },
    fetchTeamsAll({ commit }) {
        axios.get('/api/v1/teams')
            .then(response => {
                commit('setTeamsAll', response.data.data)
            })
    },
    setBooking_id({ commit }, value) {
        commit('setBooking_id', value)
    },
    setFull_name({ commit }, value) {
        commit('setFull_name', value)
    },
    setEmail({ commit }, value) {
        commit('setEmail', value)
    },
    setPhone({ commit }, value) {
        commit('setPhone', value)
    },
    setActivated({ commit }, value) {
        commit('setActivated', value)
    },
    setNo_of_adults({ commit }, value) {
        commit('setNo_of_adults', value)
    },
    setNo_of_children({ commit }, value) {
        commit('setNo_of_children', value)
    },
    setAgency_id({ commit }, value) {
        commit('setAgency_id', value)
    },
    setAgent_id({ commit }, value) {
        commit('setAgent_id', value)
    },
    setMeal_day({ commit }, value) {
        commit('setMeal_day', value)
    },
    setBill_pay({ commit }, value) {
        commit('setBill_pay', value)
    },
    setDriver_pick_up_time({ commit }, value) {
        commit('setDriver_pick_up_time', value)
    },
    setDriver_pick_up_time_updated({ commit }, value) {
        commit('setDriver_pick_up_time_updated', value)
    },
    setDrop_address({ commit }, value) {
        commit('setDrop_address', value)
    },
    setHandler_name({ commit }, value) {
        commit('setHandler_name', value)
    },
    setHandler_no({ commit }, value) {
        commit('setHandler_no', value)
    },
    setMeals_supplement({ commit }, value) {
        commit('setMeals_supplement', value)
    },
    setPackage_category({ commit }, value) {
        commit('setPackage_category', value)
    },
    setPickup_address({ commit }, value) {
        commit('setPickup_address', value)
    },
    setPickup_location({ commit }, value) {
        commit('setPickup_location', value)
    },
    setTotal_price({ commit }, value) {
        commit('setTotal_price', value)
    },
    setTour_cost({ commit }, value) {
        commit('setTour_cost', value)
    },
    setSelected_car({ commit }, value) {
        commit('setSelected_car', value)
    },
    setStatus({ commit }, value) {
        commit('setStatus', value)
    },
    setSupplier_id({ commit }, value) {
        commit('setSupplier_id', value)
    },
    setTotal_room({ commit }, value) {
        commit('setTotal_room', value)
    },
    setTotal_tour_days({ commit }, value) {
        commit('setTotal_tour_days', value)
    },
    setTraveller_id({ commit }, value) {
        commit('setTraveller_id', value)
    },
    setTour_id({ commit }, value) {
        commit('setTour_id', value)
    },
    setItinerary_places({ commit }, value) {
        commit('setItinerary_places', value)
    },
    setItinerary_places_time({ commit }, value) {
        commit('setItinerary_places_time', value)
    },
    setGroup({ commit }, value) {
        commit('setGroup', value)
    },
    setGroup_name({ commit }, value) {
        commit('setGroup_name', value)
    },
    setGroup_id({ commit }, value) {
        commit('setGroup_id', value)
    },
    setGroup_logo({ commit }, value) {
        commit('setGroup_logo', value)
    },
    
    setGroup_place({ commit }, value) {
        commit('setGroup_place', value)
    },
    setMembers({ commit }, value) {
        commit('setMembers', value)
    },
    setTour_cost_tax({ commit }, value) {
        commit('setTour_cost_tax', value)
    },
    setTour_handler({ commit }, value) {
        commit('setTour_handler', value)
    },
    setTour_name({ commit }, value) {
        commit('setTour_name', value)
    },
    setTour_location({ commit }, value) {
        commit('setTour_location', value)
    },
    setCreated_by({ commit }, value) {
        commit('setCreated_by', value)
    },
    setCreated_by_team({ commit }, value) {
        commit('setCreated_by_team', value)
    },
    resetState({ commit }) {
        commit('resetState')
    }
}

const mutations = {
    setItem(state, item) {
        state.item = item
    },
    setBooking_id(state, value) {
        state.item.booking_id = value
    },
    setFull_name(state, value) {
        state.item.full_name = value
    },
    setEmail(state, value) {
        state.item.email = value
    },
    setPhone(state, value) {
        state.item.phone = value
    },
    setActivated(state, value) {
        state.item.activated = value
    },
    setNo_of_adults(state, value) {
        state.item.no_of_adults = value
    },
    setNo_of_children(state, value) {
        state.item.no_of_children = value
    },
    setAgency_id(state, value) {
        state.item.agency_id = value
    },
    setAgent_id(state, value) {
        state.item.agent_id = value
    },
    setMeal_day(state, value) {
        state.item.meal_day = value
    },
    setBill_pay(state, value) {
        state.item.bill_pay = value
    },
    setDriver_pick_up_time(state, value) {
        state.item.driver_pick_up_time = value
    },
    setDriver_pick_up_time_updated(state, value) {
        state.item.driver_pick_up_time_updated = value
    },
    setDrop_address(state, value) {
        state.item.drop_address = value
    },
    setHandler_name(state, value) {
        state.item.handler_name = value
    },
    setHandler_no(state, value) {
        state.item.handler_no = value
    },
    setMeals_supplement(state, value) {
        state.item.meals_supplement = value
    },
    setPackage_category(state, value) {
        state.item.package_category = value
    },
    setPickup_address(state, value) {
        state.item.pickup_address = value
    },
    setPickup_location(state, value) {
        state.item.pickup_location = value
    },
    setTotal_price(state, value) {
        state.item.total_price = value
    },
    setTour_cost(state, value) {
        state.item.tour_cost = value
    },
    setSelected_car(state, value) {
        state.item.selected_car = value
    },
    setStatus(state, value) {
        state.item.status = value
    },
    setSupplier_id(state, value) {
        state.item.supplier_id = value
    },
    setTotal_room(state, value) {
        state.item.total_room = value
    },
    setTotal_tour_days(state, value) {
        state.item.total_tour_days = value
    },
    setTraveller_id(state, value) {
        state.item.traveller_id = value
    },
    setTour_id(state, value) {
        state.item.tour_id = value
    },
    setItinerary_places(state, value) {
        state.item.itinerary_places = value
    },
    setItinerary_places_time(state, value) {
        state.item.itinerary_places_time = value
    },
    setGroup(state, value) {
        state.item.group = value
    },
    setGroup_name(state, value) {
        state.item.group_name = value
    },
    setGroup_id(state, value) {
        state.item.group_id = value
    },
    setGroup_logo(state, value) {
        state.item.group_logo = value
    },
    setGroup_place(state, value) {
        state.item.group_place = value
    },
    setMembers(state, value) {
        state.item.members = value
    },
    setTour_cost_tax(state, value) {
        state.item.tour_cost_tax = value
    },
    setTour_handler(state, value) {
        state.item.tour_handler = value
    },
    setTour_name(state, value) {
        state.item.tour_name = value
    },
    setTour_location(state, value) {
        state.item.tour_location = value
    },
    setCreated_by(state, value) {
        state.item.created_by = value
    },
    setCreated_by_team(state, value) {
        state.item.created_by_team = value
    },
    setUsersAll(state, value) {
        state.usersAll = value
    },
    setTeamsAll(state, value) {
        state.teamsAll = value
    },
    
    setLoading(state, loading) {
        state.loading = loading
    },
    resetState(state) {
        state = Object.assign(state, initialState())
    }
}

export default {
    namespaced: true,
    state: initialState,
    getters,
    actions,
    mutations
}
