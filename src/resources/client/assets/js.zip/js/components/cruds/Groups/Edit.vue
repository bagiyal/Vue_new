<template>
    <section class="content-wrapper" style="margin-left: 5% !important;min-height: 960px;">
        <section class="content-header">
            <task-maker ></task-maker>
            <h1>Group</h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <form @submit.prevent="submitForm" novalidate>
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Edit</h3>
                            </div>

                            <div class="box-body">
                                <back-buttton></back-buttton>
                            </div>

                            <bootstrap-alert />

                            <div class="box-body">
                                <div class="form-group">
                                    <label for="booking_id">Booking id *</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="booking_id"
                                            placeholder="Enter Booking id *"
                                            :value="item.booking_id"
                                            @input="updateBooking_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="full_name">Full name</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="full_name"
                                            placeholder="Enter Full name"
                                            :value="item.full_name"
                                            @input="updateFull_name"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input
                                            type="email"
                                            class="form-control"
                                            name="email"
                                            placeholder="Enter Email"
                                            :value="item.email"
                                            @input="updateEmail"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="phone"
                                            placeholder="Enter Phone"
                                            :value="item.phone"
                                            @input="updatePhone"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="activated">Activated</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="activated"
                                            placeholder="Enter Activated"
                                            :value="item.activated"
                                            @input="updateActivated"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="no_of_adults">No of adults</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="no_of_adults"
                                            placeholder="Enter No of adults"
                                            :value="item.no_of_adults"
                                            @input="updateNo_of_adults"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="no_of_children">No of children</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="no_of_children"
                                            placeholder="Enter No of children"
                                            :value="item.no_of_children"
                                            @input="updateNo_of_children"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="agency_id">Agency id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="agency_id"
                                            placeholder="Enter Agency id"
                                            :value="item.agency_id"
                                            @input="updateAgency_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="agent_id">Agent id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="agent_id"
                                            placeholder="Enter Agent id"
                                            :value="item.agent_id"
                                            @input="updateAgent_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="meal_day">Meal day</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="meal_day"
                                            placeholder="Enter Meal day"
                                            :value="item.meal_day"
                                            @input="updateMeal_day"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="bill_pay">Bill pay</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="bill_pay"
                                            placeholder="Enter Bill pay"
                                            :value="item.bill_pay"
                                            @input="updateBill_pay"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="driver_pick_up_time">Driver pick up time</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="driver_pick_up_time"
                                            placeholder="Enter Driver pick up time"
                                            :value="item.driver_pick_up_time"
                                            @input="updateDriver_pick_up_time"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="driver_pick_up_time_updated">Driver pick up time updated</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="driver_pick_up_time_updated"
                                            placeholder="Enter Driver pick up time updated"
                                            :value="item.driver_pick_up_time_updated"
                                            @input="updateDriver_pick_up_time_updated"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="drop_address">Drop address</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="drop_address"
                                            placeholder="Enter Drop address"
                                            :value="item.drop_address"
                                            @input="updateDrop_address"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="handler_name">Handler name</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="handler_name"
                                            placeholder="Enter Handler name"
                                            :value="item.handler_name"
                                            @input="updateHandler_name"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="handler_no">Handler no</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="handler_no"
                                            placeholder="Enter Handler no"
                                            :value="item.handler_no"
                                            @input="updateHandler_no"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="meals_supplement">Meals supplement</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="meals_supplement"
                                            placeholder="Enter Meals supplement"
                                            :value="item.meals_supplement"
                                            @input="updateMeals_supplement"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="package_category">Package category</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="package_category"
                                            placeholder="Enter Package category"
                                            :value="item.package_category"
                                            @input="updatePackage_category"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="pickup_address">Pickup address</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="pickup_address"
                                            placeholder="Enter Pickup address"
                                            :value="item.pickup_address"
                                            @input="updatePickup_address"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="pickup_location">Pickup location</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="pickup_location"
                                            placeholder="Enter Pickup location"
                                            :value="item.pickup_location"
                                            @input="updatePickup_location"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="total_price">Total price</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="total_price"
                                            placeholder="Enter Total price"
                                            :value="item.total_price"
                                            @input="updateTotal_price"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_cost">Tour cost</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_cost"
                                            placeholder="Enter Tour cost"
                                            :value="item.tour_cost"
                                            @input="updateTour_cost"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="selected_car">Selected car</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="selected_car"
                                            placeholder="Enter Selected car"
                                            :value="item.selected_car"
                                            @input="updateSelected_car"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="status">Status</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="status"
                                            placeholder="Enter Status"
                                            :value="item.status"
                                            @input="updateStatus"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="supplier_id">Supplier id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="supplier_id"
                                            placeholder="Enter Supplier id"
                                            :value="item.supplier_id"
                                            @input="updateSupplier_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="total_room">Total room</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="total_room"
                                            placeholder="Enter Total room"
                                            :value="item.total_room"
                                            @input="updateTotal_room"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="total_tour_days">Total tour days</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="total_tour_days"
                                            placeholder="Enter Total tour days"
                                            :value="item.total_tour_days"
                                            @input="updateTotal_tour_days"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="traveller_id">Traveller id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="traveller_id"
                                            placeholder="Enter Traveller id"
                                            :value="item.traveller_id"
                                            @input="updateTraveller_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_id">Tour id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_id"
                                            placeholder="Enter Tour id"
                                            :value="item.tour_id"
                                            @input="updateTour_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="itinerary_places">Itinerary places</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="itinerary_places"
                                            placeholder="Enter Itinerary places"
                                            :value="item.itinerary_places"
                                            @input="updateItinerary_places"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="itinerary_places_time">Itinerary places time</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="itinerary_places_time"
                                            placeholder="Enter Itinerary places time"
                                            :value="item.itinerary_places_time"
                                            @input="updateItinerary_places_time"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="group">Group</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="group"
                                            placeholder="Enter Group"
                                            :value="item.group"
                                            @input="updateGroup"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="group_name">Group name</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="group_name"
                                            placeholder="Enter Group name"
                                            :value="item.group_name"
                                            @input="updateGroup_name"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="group_id">Group id</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="group_id"
                                            placeholder="Enter Group id"
                                            :value="item.group_id"
                                            @input="updateGroup_id"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="group_logo">Group logo</label>
                                    <input
                                            type="file"
                                            class="form-control"
                                            @change="updateGroup_logo"
                                    >
                                    <ul v-if="item.group_logo" class="list-unstyled">
                                        <li>
                                            {{ item.group_logo.name || item.group_logo.file_name }}
                                            <button class="btn btn-xs btn-danger"
                                                    type="button"
                                                    @click="removeGroup_logo"
                                            >
                                                Remove file
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                                <div class="form-group">
                                    <label for="group_place">Group place</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="group_place"
                                            placeholder="Enter Group place"
                                            :value="item.group_place"
                                            @input="updateGroup_place"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="members">Members</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="members"
                                            placeholder="Enter Members"
                                            :value="item.members"
                                            @input="updateMembers"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_cost_tax">Tour cost tax</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_cost_tax"
                                            placeholder="Enter Tour cost tax"
                                            :value="item.tour_cost_tax"
                                            @input="updateTour_cost_tax"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_handler">Tour handler</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_handler"
                                            placeholder="Enter Tour handler"
                                            :value="item.tour_handler"
                                            @input="updateTour_handler"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_name">Tour name</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_name"
                                            placeholder="Enter Tour name"
                                            :value="item.tour_name"
                                            @input="updateTour_name"
                                            >
                                </div>
                                <div class="form-group">
                                    <label for="tour_location">Tour location</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="tour_location"
                                            placeholder="Enter Tour location"
                                            :value="item.tour_location"
                                            @input="updateTour_location"
                                            >
                                </div>
                            </div>

                            <div class="box-footer">
                                <vue-button-spinner
                                        class="btn btn-primary btn-sm"
                                        :isLoading="loading"
                                        :disabled="loading"
                                        >
                                    Save
                                </vue-button-spinner>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</template>


<script>
import { mapGetters, mapActions } from 'vuex'

export default {
    data() {
        return {
            // Code...
        }
    },
    computed: {
        ...mapGetters('GroupsSingle', ['item', 'loading']),
    },
    created() {
        this.fetchData(this.$route.params.id)
    },
    destroyed() {
        this.resetState()
    },
    watch: {
        "item.booking_id": function() {
            this.$root.booking_ref_id={'booking_id':this.item.booking_id,'id':this.item.id}
        },
        "$route.params.id": function() {
            this.resetState()
            this.fetchData(this.$route.params.id)
        }
    },
    methods: {
        ...mapActions('GroupsSingle', ['fetchData', 'updateData', 'resetState', 'setBooking_id', 'setFull_name', 'setEmail', 'setPhone', 'setActivated', 'setNo_of_adults', 'setNo_of_children', 'setAgency_id', 'setAgent_id', 'setMeal_day', 'setBill_pay', 'setDriver_pick_up_time', 'setDriver_pick_up_time_updated', 'setDrop_address', 'setHandler_name', 'setHandler_no', 'setMeals_supplement', 'setPackage_category', 'setPickup_address', 'setPickup_location', 'setTotal_price', 'setTour_cost', 'setSelected_car', 'setStatus', 'setSupplier_id', 'setTotal_room', 'setTotal_tour_days', 'setTraveller_id', 'setTour_id', 'setItinerary_places', 'setItinerary_places_time', 'setGroup', 'setGroup_name', 'setGroup_id', 'setGroup_logo', 'setGroup_place', 'setMembers', 'setTour_cost_tax', 'setTour_handler', 'setTour_name', 'setTour_location']),
        updateBooking_id(e) {
            this.setBooking_id(e.target.value)
        },
        updateFull_name(e) {
            this.setFull_name(e.target.value)
        },
        updateEmail(e) {
            this.setEmail(e.target.value)
        },
        updatePhone(e) {
            this.setPhone(e.target.value)
        },
        updateActivated(e) {
            this.setActivated(e.target.value)
        },
        updateNo_of_adults(e) {
            this.setNo_of_adults(e.target.value)
        },
        updateNo_of_children(e) {
            this.setNo_of_children(e.target.value)
        },
        updateAgency_id(e) {
            this.setAgency_id(e.target.value)
        },
        updateAgent_id(e) {
            this.setAgent_id(e.target.value)
        },
        updateMeal_day(e) {
            this.setMeal_day(e.target.value)
        },
        updateBill_pay(e) {
            this.setBill_pay(e.target.value)
        },
        updateDriver_pick_up_time(e) {
            this.setDriver_pick_up_time(e.target.value)
        },
        updateDriver_pick_up_time_updated(e) {
            this.setDriver_pick_up_time_updated(e.target.value)
        },
        updateDrop_address(e) {
            this.setDrop_address(e.target.value)
        },
        updateHandler_name(e) {
            this.setHandler_name(e.target.value)
        },
        updateHandler_no(e) {
            this.setHandler_no(e.target.value)
        },
        updateMeals_supplement(e) {
            this.setMeals_supplement(e.target.value)
        },
        updatePackage_category(e) {
            this.setPackage_category(e.target.value)
        },
        updatePickup_address(e) {
            this.setPickup_address(e.target.value)
        },
        updatePickup_location(e) {
            this.setPickup_location(e.target.value)
        },
        updateTotal_price(e) {
            this.setTotal_price(e.target.value)
        },
        updateTour_cost(e) {
            this.setTour_cost(e.target.value)
        },
        updateSelected_car(e) {
            this.setSelected_car(e.target.value)
        },
        updateStatus(e) {
            this.setStatus(e.target.value)
        },
        updateSupplier_id(e) {
            this.setSupplier_id(e.target.value)
        },
        updateTotal_room(e) {
            this.setTotal_room(e.target.value)
        },
        updateTotal_tour_days(e) {
            this.setTotal_tour_days(e.target.value)
        },
        updateTraveller_id(e) {
            this.setTraveller_id(e.target.value)
        },
        updateTour_id(e) {
            this.setTour_id(e.target.value)
        },
        updateItinerary_places(e) {
            this.setItinerary_places(e.target.value)
        },
        updateItinerary_places_time(e) {
            this.setItinerary_places_time(e.target.value)
        },
        updateGroup(e) {
            this.setGroup(e.target.value)
        },
        updateGroup_name(e) {
            this.setGroup_name(e.target.value)
        },
        updateGroup_id(e) {
            this.setGroup_id(e.target.value)
        },
        removeGroup_logo(e, id) {
            this.$swal({
                title: 'Are you sure?',
                text: "To fully delete the file submit the form.",
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: '#dd4b39',
                focusCancel: true,
                reverseButtons: true
            }).then(result => {
                if (typeof result.dismiss === "undefined") {
                    this.setGroup_logo('');
                }
            })
        },
        updateGroup_logo(e) {
            this.setGroup_logo(e.target.files[0]);
            this.$forceUpdate();
        },
        updateGroup_place(e) {
            this.setGroup_place(e.target.value)
        },
        updateMembers(e) {
            this.setMembers(e.target.value)
        },
        updateTour_cost_tax(e) {
            this.setTour_cost_tax(e.target.value)
        },
        updateTour_handler(e) {
            this.setTour_handler(e.target.value)
        },
        updateTour_name(e) {
            this.setTour_name(e.target.value)
        },
        updateTour_location(e) {
            this.setTour_location(e.target.value)
        },
        submitForm() {
            this.updateData()
                .then(() => {
                    this.$router.push({ name: 'groups.index' })
                    this.$eventHub.$emit('update-success')
                })
                .catch((error) => {
                    console.error(error)
                })
        }
    }
}
</script>


<style scoped>

</style>
