<template>
    <section class="content-wrapper" style="margin-left: 5% !important;min-height: 960px;">
        <section class="content-header" style="margin-left: 10px;">
            <task-maker :mode="'full'"></task-maker>
            <h1>Lead: {{item.lead_id}}</h1>
        </section>
<!--        <vue-html2pdf-->
<!--            :show-layout="false"-->
<!--            :preview-modal="true"-->
<!--            :paginate-elements-by-height="1400"-->
<!--            filename="hee hee"-->
<!--            :pdf-quality="2"-->
<!--            pdf-format="a4"-->
<!--            pdf-orientation="landscape"-->
<!--            pdf-content-width="800px"-->

<!--            @progress="onProgress($event)"-->
<!--            @hasStartedGeneration="hasStartedGeneration()"-->
<!--            @hasGenerated="hasGenerated($event)"-->
<!--            ref="html2Pdf"-->
<!--        >-->
<!--            <section slot="pdf-content">-->
<!--                <h1>hello</h1>-->
<!--            </section>-->
<!--        </vue-html2pdf>-->

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <form @submit.prevent="submitForm" novalidate>
                        <div class="ml-5">
                            <!--                            <div class="box-header with-border">-->
                            <!--                                <h3 class="box-title">Create</h3>-->
                            <!--                            </div>-->

                            <div>
                                <back-buttton></back-buttton>
                            </div>

                            <bootstrap-alert />

                            <div class="ml-5">
                                <div class="container ml-5">
                                    <span class="h1"><img src="./../dashboard_resources/createitinerarydown.png" height="40px"><b>Create Lead</b></span>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Tentative Date</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><i class="fa fa-calendar"></i></span>
                                                    <date-picker
                                                        :value="item.date"
                                                        :config="$root.dpconfigDate"
                                                        name="date"
                                                        placeholder="Enter Date"
                                                        @dp-change="updateDate"
                                                        class="input-field"
                                                    >
                                                    </date-picker></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Traveller Name</span></div>
                                                <div class="col-lg-12"><span style="position: absolute; left: 5.5%; color: grey;"><img src="./../dashboard_resources/name.png"></span><input
                                                    type="text"
                                                    class="form-control"
                                                    name="name"
                                                    placeholder="Enter Name"
                                                    :value="item.name"
                                                    @input="updateName"
                                                ></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Email</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><i class="fa fa-envelope"></i></span><input
                                                    type="email"
                                                    class="form-control"
                                                    name="email"
                                                    placeholder="Enter Email"
                                                    :value="item.email"
                                                    @input="updateEmail"
                                                ></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><label for="lead_id1" class="h2 fw-4 text-muted ml-3">Source Lead</label>
                                                    <span class="img-style"><img src="./../dashboard_resources/leadsource.png" class="hw-2 mt-2"></span>
                                                    <select
                                                        class="form-control lead-select"
                                                        name="lead_id1"
                                                        :value="item.source"
                                                        @input="updateSource"
                                                    ><option value="Adwords">Adwords</option>
                                                        <option selected value="Social Media">Social Media</option>

                                                        <option value="Offline Purchase">Offline Purchase</option>
                                                        <option value="Repeat">Repeat</option>
                                                        <option value="Referred">Referred</option>
                                                        <option value="Website">Website</option>
                                                        <option value="Walk In">Walk In</option>
                                                        <option value="Phone Call">Phone Call</option>
                                                        <option value="Corporate">Corporate</option>
                                                        <option value="Sales Team">Sales Team</option>
                                                        <option value="Others">Others</option>
                                                    </select></div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Sector</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><img src="./../dashboard_resources/loction.png" class="hw-i"></span> <input
                                                    type="text"
                                                    class="form-control"
                                                    name="package_type"
                                                    placeholder="Enter Package type"
                                                    :value="item.package_type"
                                                    @input="updatePackage_type"

                                                ></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Mobile Number</span></div>
                                                <div class="col-lg-12 ml-3">
                                                    <vue-tel-input style="width:80%;border: 1px solid #ced4da;" v-model="item.phone" @input="updatePhone" v-bind="bindProps" class="form-control" name="phone" placeholder="Enter Phone"></vue-tel-input>


                                                    <!--                                                    <input-->
                                                    <!--                                                    type="text"-->
                                                    <!--                                                    class="form-control"-->
                                                    <!--                                                    name="phone"-->
                                                    <!--                                                    placeholder="Enter Phone"-->
                                                    <!--                                                    :value="item.phone"-->
                                                    <!--                                                    @input="updatePhone"-->
                                                    <!--                                                >-->
                                                </div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Traveller</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><img src="./../dashboard_resources/traveller.png" class="hw-2"></span>
                                                    <input readonly class="form-control" data-toggle="modal" data-target="#myModal"  v-model="total_trav" type="text">
                                                    <div class="container">

                                                            <div class="modal" id="myModal">
                                                        <div class="modal-dialog">
                                                            <div class="modal-content">

                                                                <!-- Modal Header -->


                                                                <!-- Modal body -->
                                                                <div class="modal-body">
                                                                    <button type="button" class="close" data-dismiss="modal">&times;</button><br>
                                                                    <div class="container">
                                                                        <div class="row text-center pt-2 pb-2" style="">
                                                                            <div class="col-lg-4">
                                                                                <div class="row">
                                                                                    <div class="col-12">
                                                                                        <p class="h3 fw-4 text-muted">Adults</p>
                                                                                    </div>
                                                                                    <div class="col-12" style="">
                                                                                        <p class="fw-4 text-muted h5">(12+ yrs)</p>
                                                                                    </div>
                                                                                    <div class="col-lg-12" style="">
                                                                                        <vue-numeric-input id="adult" v-model="item.adult_guest"

                                                                                                            :min="1"
                                                                                                            :step="1"></vue-numeric-input>
<!--                                                                                        <input type="number" id="adult" class="form-control" min="1"-->
<!--                                                                                              -->
<!--                                                                                        >-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4">
                                                                                <div class="row">
                                                                                    <div class="col-12">
                                                                                        <p class="h3 fw-4 text-muted">Children</p>
                                                                                    </div>
                                                                                    <div class="col-12" style="">
                                                                                        <p class="h5 fw-4 text-muted">(2-12 yrs)</p>
                                                                                    </div>
                                                                                    <div class="col-12" style="">
                                                                                        <vue-numeric-input id="child" v-model="item.kids_guests"

                                                                                                            :min="0"
                                                                                                            :step="1"></vue-numeric-input>
<!--                                                                                        <input type="number" id="child" min="0" style="width: 50px;height: 25px;border: 1px solid darkgrey;border-radius: 3px;" value="0"  placeholder="0"-->
<!--                                                                                               -->
<!--                                                                                        >-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                            <div class="col-lg-4">
                                                                                <div class="row">
                                                                                    <div class="col-12">
                                                                                        <p class="h3 fw-4 text-muted">Infant</p>
                                                                                    </div>
                                                                                    <div class="col-12" style="">
                                                                                        <p class="h5 fw-4 text-muted">(below 2yrs)</p>
                                                                                    </div>
                                                                                    <div class="col-12" style="">
                                                                                        <vue-numeric-input id="infant" v-model="item.infant_guest"

                                                                                                           :min="0"
                                                                                                           :step="1"></vue-numeric-input>
<!--                                                                                        <input type="number" id="infant" min="0" style="width: 50px;height: 25px;border: 1px solid darkgrey;border-radius: 3px;" placeholder="0"-->
<!--                                                                                               -->
<!--                                                                                        >-->
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>

                                                                <!-- Modal footer -->

                                                            </div>
                                                        </div>
                                                    </div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Remark</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><i class="fa fa-pencil-square-o"></i></span>
                                                    <input type="text" class="form-control"
                                                           name="remark"
                                                           placeholder="Enter Remark"
                                                           v-model="locremark"

                                                    >
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-4"><span class="h3 fw-4 text-muted "><input type="checkbox" v-model="selfass" class="ml-3 check-box1">Self Assign</span></div>
                                    <div class="row">
                                        <div class="col-lg-11 text-center mt-4">
                                            <!--                                            <button class="btn btn-primary text-light"><i class="fa fa-paper-plane" aria-hidden="true"></i>Submit</button>-->


                                            <vue-button-spinner v-if="submit"
                                                                class="btn btn-primary text-light ml-3"
                                                                :isLoading="loading"
                                                                :disabled="loading"

                                            >
                                                <spna class="h2"><i class="fa fa-paper-plane" aria-hidden="true"></i>Submit</spna>
                                            </vue-button-spinner>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</template>


<script>
    $("#sum").click(function () {

        var a_num = $("#adult").val();
        var c_num = $("#child").val();
        var inf_num=$("#infant").val();
        var total = parseInt(a_num) + parseInt(c_num)+ parseInt(inf_num);
        if(c_num==0 && inf_num==0){ total = a_num}
        if(inf_num==0){total= parseInt(a_num)+ parseInt(c_num)}
        $("#sum").val(total);

    });
    function popupfunction() {
        var x = document.getElementById("popup");
        if (x.style.display === "block") {
            x.style.display = "none";
        } else {
            x.style.display = "block";
        }
    }

    import { mapGetters, mapActions } from 'vuex'
    import { VueTelInput } from 'vue-tel-input'
    // import VueHtml2pdf from 'vue-html2pdf'
    export default {
        data() {
            return {
                // Code...
                submit:true,
                locremark:'',
                currentDate:null,
                // total_trav:1,
                pop:false,
                selfass:false,
                bindProps: {
                    mode: "international",
                    defaultCountry: "INR",
                    disabledFetchingCountry: false,
                    disabled: false,
                    disabledFormatting: false,
                    placeholder: "Enter a phone number",
                    required: false,
                    enabledCountryCode: false,
                    enabledFlags: true,
                    preferredCountries: ["AU", "BR"],
                    onlyCountries: [],
                    ignoredCountries: [],
                    autocomplete: "off",
                    name: "telephone",
                    maxLen: 25,
                    wrapperClasses: "",
                    inputClasses: "",
                    validCharactersOnly:true,
                    dropdownOptions: {
                        disabledDialCode: true
                    },
                },
            }
        },
        watch: {

            "selfass": {

                handler(newval, oldVal){

                    if(newval==true){
                        console.log("if");
                        this.item.created_by=1
                        this.item.created_by_id=1
                    }
                    else {
                        console.log("else");
                        this.item.created_by=''
                        this.item.created_by_id=''
                    }


                },
                deep: true


            },

        },


        computed: {
            ...mapGetters('LeadsSingle', ['item', 'loading']),

            total_trav(){

                return parseInt(this.item.adult_guest) + parseInt(this.item.kids_guests) +  parseInt(this.item.infant_guest);

            }
        },
        created() {
            // Code ...
            // this.item.adult_guest=1,
                this.item.source="Social Media",
                this.item.score=3,
                this.item.lead_feel=3,
                this.currentDate = new Date().toJSON().slice(0,10).replace(/-/g,'');
            var agency=JSON.parse(document.querySelector("meta[name='agency-id']").getAttribute('content'));
            this.item.lead_id='LD-'+document.querySelector("meta[name='user-id']").getAttribute('content')+'-'+agency.id+'-'+this.currentDate+'-'+Math.floor((Math.random() * (999-100+1)+100)),
                this.item.lead_status=1


        },
        destroyed() {
            this.resetState()
        },
        methods: {
            ...mapActions('LeadsSingle', ['storeData', 'resetState', 'setLead_id', 'setLead_status', 'setPackage_type', 'setDate', 'setEmail', 'setPhone', 'setName', 'setAdult_guest', 'setScore', 'setKids_guests', 'setAgent_id', 'setAgency_id', 'setScore_new', 'setLead_feel' ,'meta_id','query_id','sl_score','dd_score','source','source_id','source_url','task','task_status','setRemark', 'setSource','setInfant_guest','setTraveller_id']),
            generateReport () {
                this.$refs.html2Pdf.generatePdf()
            },
            updatemeta_id(e) {
                this.setmeta_id(e.target.value)
            },
            updatequery_id(e) {
                this.setquery_id(e.target.value)
            },
            updatesl_score(e) {
                this.setsl_score(e.target.value)
            },
            updatedd_score(e) {
                this.setdd_score(e.target.value)
            },
            updatesource(e) {
                this.setsource(e.target.value)
            },
            updatesource_id(e) {
                this.setsource_id(e.target.value)
            },
            updatesource_url(e) {
                this.setsource_url(e.target.value)
            },
            updatetask(e) {
                this.settask(e.target.value)
            },
            updatetask_status(e) {
                this.settask_status(e.target.value)
            },

            updateLead_id(e) {
                this.setLead_id(e.target.value)
            },
            updateLead_status(e) {
                this.setLead_status(e.target.value)
            },
            updatePackage_type(e) {
                this.setPackage_type(e.target.value)
            },
            updateDate(e) {
                this.setDate(e.target.value)
            },
            updateEmail(e) {
                this.setEmail(e.target.value)
            },
            updatePhone(e) {
                this.setPhone(e.target.value)
            },
            updateName(e) {
                this.setName(e.target.value)
            },

            updateScore(e) {
                this.setScore(e.target.value)
            },

            updateAgent_id(e) {
                this.setAgent_id(e.target.value)
            },
            updateAgency_id(e) {
                this.setAgency_id(e.target.value)
            },
            updateScore_new(e) {
                this.setScore_new(e.target.value)
            },
            updateLead_feel(e) {
                this.setLead_feel(e.target.value)
            },
            updateRemark(e) {

                this.setRemark(e.target.value)
            },
            updateSource(e) {
                this.setSource(e.target.value)
            },
            updateAdult_guest(e) {
                this.setAdult_guest(e.target.value);
                this.total_trav= Number(this.item.adult_guest)+ Number(this.item.kids_guests)+ Number(this.item.infant_guest);
            },
            updateKids_guests(e) {
                this.setKids_guests(e.target.value);
                this.total_trav=  Number(this.item.adult_guest)+  Number(this.item.kids_guests)+  Number(this.item.infant_guest);
            },
            updateInfant_guest(e) {
                this.setInfant_guest(e.target.value);
                this.total_trav=  Number(this.item.adult_guest)+  Number(this.item.kids_guests)+  Number(this.item.infant_guest);
            },
            submitForm() {
                this.submit=false;
                if(this.locremark!==''){
                    this.setRemark(this.locremark);
                }


                var re = /\S+@\S+\.\S+/;
                var  email_v= re.test(this.item.email);
                if(this.item.name && this.item.email && email_v && this.item.phone){
                    var res = this.item.phone.replace(/\(/g, "");
                    res = res.replace(/\)/g, "");
                    res = res.replace(/-/g, "");
                    res = res.replace(/ /g, "");
                    this.setPhone(res);
                    let trav = new FormData();

                    trav.set("name",this.item.name)
                    trav.set("email",this.item.email)
                    trav.set("phone",this.item.phone)
                    trav.set("type","lead")
                    axios.post('/api/v1/travellers', trav)
                        .then(response => {
                            console.log(response)
                            console.log(response.data.status)
                            this.setTraveller_id(response.data.id);
                            if(response.data.status=='error'){
                                this.submit=true;
                                alert(response.data.type);
                                this.setRemark([]);
                            }

                            else {
                                this.storeData()
                                    .then(() => {
                                        this.$router.push({ name: 'leads.index' })
                                        this.$eventHub.$emit('create-success')
                                    })
                                    .catch((error) => {
                                        this.submit=true;
                                        console.error(error)
                                        this.setRemark([]);
                                    })
                            }

                        })
                        .catch(error => {
                            this.submit=true;
                            alert("error");
                        })

                }
                else {
                    this.submit=true;
                    alert("Provide All Contact Details");
                }
            }
        },
        components: {VueTelInput}
    }

</script>


<style scoped>
    input{
        margin-left: 2%; padding-left: 8%; width: 80%;background-color:white !important;
    }
    .dropbtn {

        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
    }
    .changecolor:hover{background-color:white;border-bottom-left-radius: 5px }
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {display:none;
        top:0px;
        right:-70px;
        position: absolute;

        min-width: 50px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }
    .icon {
        color: darkgrey;
        text-align: center;

    }
    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        width: 70px;
    }



    .dropdown:hover .dropdown-content {display: block;}
    .sidebar{
        float: left;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        text-align: left;
        height: 100%;
        width: 20%;
        padding-bottom: 200px;
        /*margin-top: -10px;*/


    }
    .sidebar a{
        text-decoration: none;
        color:black;
        display: grid;
        text-align: left;
        padding: 10px 10px 10px 10px;
        border-collapse: solid black 1px;
    }
    .sidebar a:hover{
        background-color: #2751A4;
        padding-left: 20px;
        color: white;
        display: grid;

    }
    .sidebar li{list-style: none;}
    #align{
        text-align: left;
        margin-left:-40px; margin-right:10px;
    }
    .onhover a{color:grey; font-size: 13px;}
    .onhover a:hover{background-color: #2751A4; border-radius:20px; color: white;}
    .navpad li a{ padding-left: 70px; }
    .quantity::-webkit-inner-spin-button,
    .quantity::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
    .vue-numeric-input {
        position: relative;
        display: inline-block;
        -webkit-box-sizing: border-box;
        box-sizing: border-box;
        width: 70px !important;
    }
</style>
<style>
</style>
