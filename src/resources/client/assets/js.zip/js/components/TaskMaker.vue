<template>
    <div v-if="">
        <div style="border-right: 1px solid white; height: 50px; position: absolute; left: 88%;top: -211%;z-index: 1;"><img @click="showtask?showtask=false:showtask=true" src="../components/cruds/dashboard_resources/addtask.png" style="height: 35px; float: right;margin-right: 105%;">
            <p style="color: white; position: absolute; left: -121.5%; top: 71%; ">Add Task</p>
        </div>


        <div v-if="showtask" style="overflow: auto;overflow-x: hidden; background-color: white; position: absolute; width: 700px; height: 400px; border: 1px solid gainsboro; left: 390px; top: 47px; font-size: 16px; z-index: 3;">
            <button style="padding: 0px 5px 5px 5px;" type="button" class="close" @click="showtask=false">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="row ml-5" style="margin-top: 8%;">
                <div class="col-2">
            Due Date
        </div>
                <div class="col-4" style="margin-left: -5%;">
                    <date-picker
                        class="dateinput"

                        :config="$root.dpconfigDatetime"
                        v-model="task.due_date"
                    >
                    </date-picker>

                </div>
                <div class="col-2 ml-4">
                    <div class="col-2">
                        Notification
                    </div>
                                            <div class="col-4 " style="margin-left: -8%;">
                                                <input id='remind' value="true" type="checkbox" class="ml-5" v-model="task.reminder" style="border-radius:3px;border: 1px solid gainsboro;">
                                            </div>

        </div>
<!--                <div class="row ml-5" style="margin-top: 5%;">-->
<!--                    <div class="col-2">-->
<!--                       -->
<!--                    </div>-->
<!--                    <div class="col-4 " style="margin-left: -8%;">-->
<!--                     -->
<!--                    </div>-->


<!--                </div>-->

                <div v-if="showdropdown" class="col-11" style="margin-left: 0%;">
                    Ref No. (ID | Traveller Name | Tour Name)
                    <v-select  placeholder="Select"
                              name="addlocations"
                              label="booking_id"
                           v-model="task.ref_id"
                              :options="dropdown"
                              class="add_style"
                               max-height="200px"
                    />

                </div>
                <div v-else class="col-11" style="margin-left: 0%;">

                    <v-select  placeholder="Select"
                               name="addlocations"
                               label="booking_id"
                               :value="task.ref_id"

                               :options="dropdown"
                               class="add_style"
                               :disabled="true"

                    />

                </div>
            </div>



            <div class="row ml-5" style="margin-top: 5%;"><div class="col-2">
                Remarks
            </div> <div class="col-10" style="margin-left: -5%;"><textarea id="remark" v-model="task.remark" style="border-radius:3px;resize: none;border: 1px solid gainsboro; width: 513px; height: 102px;overflow: hidden"></textarea></div>
            </div>
            <div class="row" style="margin-top: 5%;">
                <div class="col-6 text-right"><button @click="clear" class="btn btn-danger pl-5 pr-5" style="font-size: 16px">Clear</button></div>
                <div class="col-6"><button @click="submit" class="btn btn-success pl-5 pr-5" style="font-size: 16px">Apply</button></div>


            </div>
        </div>

    </div>
</template>


<script>
import { mapGetters } from 'vuex'
import todaytimestamp from "../mixins/todaytimestamp";

export default {
    data() {
        return {
            showtask:false,

            // Code...
            task:{
                agent_name:'',
                assign_date:'',
                due_date:'',
                ref_id:'',
                reminder:false,
                reminder_time:'',
                remark:'',
                status:0,

            },
dropdown:[],
            checkrole:false,
            showdropdown:false,
        }
    },
    computed: {

    },
    created() {
        if(document.querySelector("meta[name='user-role']").getAttribute('content')=='lms_agent'){
            this.checkrole=true;
        }


    },
    watch:{

        "showtask": function() {
if (this.showtask){
    this.task.ref_id=this.$root.booking_ref_id;
    axios.get('/api/v1/taskrefs/'+document.querySelector("meta[name='user-id']").getAttribute('content'))
        .then(response => {
            console.log(response.data)
            this.dropdown=  response.data;
        })
        .catch(error => {
          alert("Error in fetching task data")
            console.log(error)
        })
if(this.task.ref_id=='' || typeof this.task.ref_id=="undefined" || this.mode=='full' ){

    this.showdropdown=true;
}

}
        },

    },
    methods: {
        clear(){
            this.task.agent_name='',
                this.task.assign_date='',
                this.task.due_date='',
                // this.task.ref_id={},
                this.task.reminder=false,
                this.task.reminder_time='',
                this.task.remark=''
        },
         submit(){

if(this.task.due_date && this.task.remark && this.task.ref_id){
    const config = {
        headers: {
            'content-type': 'multipart/form-data',
        }
    }



    let params = new FormData();
    params.set('due_date', this.task.due_date);
    params.set('ref_id', JSON.stringify(this.task.ref_id));
    params.set('reminder', this.task.reminder);
    params.set('reminder_time', this.task.due_date);
    params.set('remark', this.task.remark);
    params.set('status', 0);
    params.set('assign_date', todaytimestamp());
    params.set('agent_name',  document.querySelector("meta[name='user-name']").getAttribute('content'));
    params.set('agent_id', document.querySelector("meta[name='user-id']").getAttribute('content'));
    params.set('agency_id', document.querySelector("meta[name='agency-id']").getAttribute('content'));

    axios.post('/api/v1/tasks', params,config)
    this.showtask=false
    this.clear();



}else{

    alert("Kindly fill all Details");
}

}






    },
    props:['mode']
}

</script>


<style scoped>

</style>
