<template>
    <div style="margin-left: 25%">

        <span  >
            {{ last }}
        </span>
    </div>
</template>


<script>
export default {
    props: ['row', 'field'],
    data() {
        return {
            meta_data:{

                last_quote_time: ''

            }

        }
    },
    computed:{
        last() {

             let     today = Math.round(+new Date().getTime()/1000);
             let create=Math.round(+new Date(this.row.created_at).getTime()/1000);
             // return create;
                var res = (today) - parseInt(create);

                var diff =res;
                diff /= (60 * 60);
                return Math.abs(Math.round(diff))+'(hrs)';


        }
    },
    watch:{

    },
    created() {
        // this.meta_data.infant=this.row.get_meta.length

    },
    methods: {
        // Code...
    }
}
</script>


<style scoped>

</style>
