<template>
    <div class="btn-group btn-group-xs">
<!--        <router-link-->
<!--                v-if="$can(xprops.permission_prefix + 'view')"-->
<!--                :to="{ name: xprops.route + '.show', params: { id: row.id } }"-->
<!--                class="btn btn-primary"-->
<!--                >-->
<!--            View-->
<!--        </router-link>-->
<!--        this.$router.push({ name: 'queries.clone', params:{'clone_data':this.item ,'clone_meta':this.meta,'itiplace':JSON.stringify(this.item.itinerary_places),'tour_loc':JSON.stringify(this.item.tour_location),'newlead':true }})-->
        <button
            @click="clone"
            type="button"
            class="btn "  style="">
            <i class="fa fa-clone button_style" aria-hidden="true"></i>

        </button>

<!--        <router-link-->

<!--            :to="{ name: 'queries.clone',params:{'clone_data':this.row ,'clone_meta':this.meta,'itiplace':JSON.stringify(this.row.itinerary_places),'tour_loc':JSON.stringify(this.row.tour_location),'newlead':true }}"-->
<!--            class="btn " style="color: #6dcdff">-->

<!--            <i class="fa fa-clone" aria-hidden="true"></i>-->

<!--        </router-link>-->
        <router-link
                v-if="$can(xprops.permission_prefix + 'edit')"
                :to="{ name: xprops.route + '.edit', params: { id: row.id } }"
                class="btn ">
            <i class="fa fa-pencil-square-o button_style" aria-hidden="true"></i>

        </router-link>

        <button
                v-if="$can(xprops.permission_prefix + 'delete')"
                @click="destroyData(row.id)"
                type="button"
                class="btn">
            <i class="fa fa-trash button_style" aria-hidden="true"></i>

        </button>
   </div>
</template>


<script>
export default {
    props: ['row', 'xprops'],
    data() {
        return {
            // Code...
            meta:{},
            meta_data:[]
        }
    },
    created() {

    },
    methods: {
        clone(){
            this.meta_data = this.row.get_meta;
            this.row.itinerary_places=JSON.parse(this.row.itinerary_places);
            this.row.tour_location=JSON.parse(this.row.tour_location);


            this.row.meals_supplement=JSON.parse(this.row.meals_supplement);
            this.row.tour_cost=JSON.parse(this.row.tour_cost);
            this.row.remarks=JSON.parse(this.row.remarks);
            console.log(this.meta_data);

            // this.meta_data.forEach(function(e){
                for(let i=0;i<this.row.get_meta.length;i++){

                if( this.row.get_meta[i].meta_key=='meta_infant'){

                    this.meta.meta_infant=this.row.get_meta[i].meta_value;
                }

                if( this.row.get_meta[i].meta_key=='meta_extra_bed'){

                    this.meta.meta_extra_bed=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_transport'){

                    this.meta.meta_transport=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_source'){


                    this.meta.meta_source=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_flightprice'){

                    this.meta.meta_flightprice=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_flight'){

                    this.meta.meta_flight=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_welcome_mail'){

                    this.meta.meta_welcome_mail=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_incl_ex'){

                    this.meta.meta_incl_ex=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_closuer'){

                    this.meta.meta_closuer=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_exp_cost'){

                    this.meta.meta_exp_cost=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='meta_exp_costflight'){

                    this.meta.meta_exp_costflight=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='markup1'){

                    this.meta.markup1=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='markup2'){

                    this.meta.markup2=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='sellingprice1'){

                    this.meta.sellingprice1=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='sellingprice2'){

                    this.meta.sellingprice2=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='interactions'){

                    this.meta.interactions=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='lost'){

                    this.meta.lost=JSON.parse(this.row.get_meta[i].meta_value);
                }
                if( this.row.get_meta[i].meta_key=='by_lead'){

                    this.meta.by_lead=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='last_quote_no'){

                    this.meta.last_quote_no=this.row.get_meta[i].meta_value;
                }


                if( this.row.get_meta[i].meta_key=='meta_executive_name'){

                    this.meta.meta_executive_name=this.row.get_meta[i].meta_value;
                }
                if( this.row.get_meta[i].meta_key=='meta_executive_no'){

                    this.meta.meta_executive_no=this.row.get_meta[i].meta_value;
                }

            }
            this.$router.push({ name: 'queries.clone', params:{'clone_data':this.row ,'clone_meta':this.meta,'itiplace':JSON.stringify(this.row.itinerary_places),'tour_loc':JSON.stringify(this.row.tour_location),'newlead':true }})

        },
        destroyData(id) {
            this.$swal({
                title: 'Are you sure?',
                text: 'You won\'t be able to revert this!',
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Delete',
                confirmButtonColor: '#dd4b39',
                focusCancel: true,
                reverseButtons: true
            }).then(result => {
                if (result.value) {
                    this.$store.dispatch(
                        this.xprops.module + '/destroyData',
                        id
                    ).then(result => {
                        this.$eventHub.$emit('delete-success')
                    })
                }
            })
        }
    }
}
</script>


<style scoped>

</style>
