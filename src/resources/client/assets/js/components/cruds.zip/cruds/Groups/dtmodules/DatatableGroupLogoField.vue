<template>
    <div v-html="row.group_logo_link"></div>
</template>


<script>
    export default {
        props: ['row'],
    }
</script>
