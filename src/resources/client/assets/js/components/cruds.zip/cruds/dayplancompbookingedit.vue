<template>

    <div id="dayplan">
        <!--{{place}}-->
        <!--<button @click=""> refresh </button>-->
        {{setdayscout()}}
        <div style="margin-left: -88px;margin-top: 20px;">

            <button v-for="(namelock,index3 ) in tour_location" @click="showlocation = namelock.name+index3" :class="[showlocation === namelock.name+index3 ? 'bg-primary' :''] " style="background-color:#EFF5FA;border: 0;border-radius: 15px;font-size: 14px;margin-left: 60px;">{{namelock.name}}</button>
            <!--        class="bg-primary"-->
        </div>


        <div v-for="(location,index ) in tour_location"  v-show="showlocation === location.name+index ">

            <!--{{location}}-->

            <div class="text-center text-dark" style="margin-top: 0px;margin-left: -9%;font-size: 18px    ">{{location.name}}  {{location.date_from}} - {{location.date_to}}</div>
            <div style="margin-bottom: 1%;background-color: white;text-align: center;margin-left: 7%;width: 800px;border-radius: 10px 0px 0px 0px "  >

                <button  v-for="(dayl,index1 ) in parseInt(location.daynights)" @click="showday = dayl+index1" :class="[showday === dayl+index1 ? 'bg-primary' :''] " style="width: 160px;border: 0;border-radius: 15px;font-size: 16px;color:#6a6a6a;">Day {{parseInt(alldaycounter[index])+parseInt(dayl)}}</button>
                <!--            <button style="width: 160px;border: 0;border-radius: 15px;font-size: 14px;background-color: white">Day </button>-->
            </div>
{{objpre()}}
            <div  class="col-xs-12" style="margin-left: -3.5%;" v-for="(day,index2 ) in parseInt(location.daynights)" :key="day" v-show="showday === day+index2">
                <!--            Day {{day}}- -->

                {{preselect(day,defaultt,location.id,place[location.id.split('-')[0]])}}


                <CarouselCard :interval="70000" height="457px" type="card" arrow="always">
                    <CarouselCardItem v-for="(placeinfo, index3) in objj[location.id]['day-'+day]['place']" :key="index3">


                        <div class="card" style="height: 500px ; width: 400px;margin-left:7%" >
                            <div class="card-header">
                                <div class="row" style="margin-bottom: 5%">
                                    <div class="col-6">
                                        <i class="fas fa-calendar-week text-muted" style="font-size:25px;"></i>
                                        <span class="text-primary pl-1" style="font-size: 16px;">Day {{parseInt(alldaycounter[index])+parseInt(day)}}<sup class="text-secondary">{{moment_format(location.date_from,day,index2)}}</sup></span>
                                    </div>
                                    <div class="col-6" style="text-align: right;">
                                        <span class="text-secondary" style="font-size: 16px">Meal Plan</span>
                                        <div class="row" >
                                            <div class="col-2" style="font-size: 10px; margin-left: 40%;">

                                                <img v-if="objj[location.id]['day-'+day]['meal']['bf']" @click="changemeal(location.id,'day-'+day,'bf',false,day,index2)"  height="25px"  src="./dashboard_resources/bfdown.png" alt="task">
                                                <img v-if="!objj[location.id]['day-'+day]['meal']['bf']" @click="changemeal(location.id,'day-'+day,'bf',true,day,index2)"  height="25px"  src="./dashboard_resources/bfup.png" alt="task">
                                                <br><span style="position:absolute;left:45%">BF</span>
                                            </div>
                                            <div class="col-2" style="font-size: 10px;margin-left: -2px;">
                                                <img  v-if="objj[location.id]['day-'+day]['meal']['l']" @click="changemeal(location.id,'day-'+day,'l',false,day,index2)" height="25px"  src="./dashboard_resources/lunchdown.png" alt="task">
                                                <img v-if="!objj[location.id]['day-'+day]['meal']['l']" @click="changemeal(location.id,'day-'+day,'l',true,day,index2)"  height="25px"  src="./dashboard_resources/lunch.png" alt="task">


                                                <br><span style="position:absolute;left:59%">L</span>
                                            </div>
                                            <div class="col-2" style="font-size: 10px;margin-left: 0%;">
                                                <img v-if="objj[location.id]['day-'+day]['meal']['d']" @click="changemeal(location.id,'day-'+day,'d',false,day,index2)"  height="25px"  src="./dashboard_resources/dinnerdown.png" alt="task" >
                                                <img v-if="!objj[location.id]['day-'+day]['meal']['d']" @click="changemeal(location.id,'day-'+day,'d',true,day,index2)" height="25px"  src="./dashboard_resources/dinner.png" alt="task">


                                                <br><span style="position:absolute;left:53%">D</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <span class="text-secondary" style="font-size: 12px"><img height="30px" width="30px" src="./dashboard_resources/setting_Icon.png"> Activity<hr></span>
                                <p class="text-secondary" style="font-size:15px"><b>{{placeinfo['title']}}</b></p>
                                <div class="row">
                                    <div class="col-6 float-left"><img v-bind:src="objj[location.id]['day-'+day]['place'][index3]['featured_image_link']?objj[location.id]['day-'+day]['place'][index3]['featured_image_link']:'./dashboard_resources/slide1.jpg'" height="100px" width="150px"></div>


                                    <div class="col-6 text-secondary text-justify" style="font-size: 10px;margin-left: -30px;">
                                        <!--                                            <img class="mr-1" height="15px" width="15px" src="./dashboard_resources/setting_Icon.png">Mobile:<b>-->
                                        <!--                                            <input type="text" placeholder="0987456321" style="border: 0;width: 65px;font-weight: bolder;"> </b><br>-->
                                        <div  style="text-align: justify;width: 200px;height: 75px;overflow: hidden;border: 0;resize:none" >

                                            <div   v-html="objj[location.id]['day-'+day]['place'][index3]['description']"></div>
                                        </div>
                                        <!--                                            <a href="#">know more+</a>-->
                                    </div>
                                </div>
                                <div class="pl-2">
                                    <span class="text-dark" style="font-size: 15px">Remark</span>
                                    <textarea class="text-secondary text-justify" style="font-size: 10px;width: 360px;height: 70px;resize: none;border: 0;" v-model="objj[location.id]['day-'+day]['place'][index3]['remark']"></textarea>


                                </div>
                                <div class="row">
                                    <div class="col-6">
                                        <span class="text-success float-left text-success">Strat Time:</span><br>
                                        <date-picker
                                            v-model="objj[location.id]['day-'+day]['place'][index3]['from_time']"
                                            :config="$root.dpconfigTime"
                                            name="driver_pickup_date_time"


                                            style="text-align: center;border: solid gainsboro 2px;width: 100px"
                                            class="pl-1 pr-1"
                                        >
                                        </date-picker>



                                    </div>
                                    <div class=" col-6" style="padding-left: 90px">
                                        <span class="text-danger">End Time:</span><br>
                                        <date-picker
                                            v-model="objj[location.id]['day-'+day]['place'][index3]['to_time']"
                                            :config="$root.dpconfigTime"
                                            name="driver_pickup_date_time"


                                            style="text-align: center;border: solid gainsboro 2px;width: 100px"
                                            class="pl-1 pr-1"
                                        >
                                        </date-picker>

                                    </div>
                                </div>
                            </div>

                        </div>



                    </CarouselCardItem>
                </CarouselCard>

                <div style="text-align: center;width: 41%;margin-left: 28.5%">

                    <div class="card-footer text-center" style="background-image: linear-gradient(to bottom,#343434, #1d1d1d, #343434, #4d4c4c, #676665);">
                        <a href="#" @click="editplan= day+index2" class="text-light">Click to Edit</a>
                    </div>
                </div>
                <button @click="changeview" style="outline: currentcolor none 0px !important; box-sizing: border-box; border: 1px solid transparent; background-color: rgb(34, 80, 125); font-size: 14px; font-weight: 400; padding: 6px 12px; min-width: 140px; color: white; width: 100px; border-radius: 4px; top: 90%; left: 79.5%; position: fixed; z-index: 1; display: inline-block; text-align: center; vertical-align: middle; touch-action: manipulation; cursor: pointer; background-image: none; white-space: nowrap; line-height: 1.42857;">Next</button>


                <!-- Modal -->
                <div id="">
                    <div v-if="editplan === day+index2">
                        <transition name="modal">
                            <div class="modal-mask">
                                <div class="modal-wrapper">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <button type="button" class="close" @click="editplan = null">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>

                                            </div>
                                            <div class="modal-body" style="margin-left: -10px;margin-right: 10px;">


                                                <div class="card pt-2 pb-1 pl-3 pr-2" style="width: 100%;position:absolute;top:20px;z-index:6;">
                                                    <div class="row" style="width: 100%;">
                                                        <div class="col-6">
                                                            <i class="far fa-calendar text-muted" style="font-size: 20px"></i>
                                                            <span class="text-primary pl-1" style="font-size: 15px; font-weight: bold;">Day {{day}}</span><span class="text-secondary" style=";margin-left:10px;font-size:15px"> </span>
                                                        </div>
                                                        <!--                                                            <div class="col-6" style="position: relative;">-->
                                                        <!--                                                                <span class="text-secondary" style="font-size: 15px;font-weight: bold;position: absolute;left: 90px;top:7px">Meal Plan</span>-->
                                                        <!--                                                                <div class="row" style="margin-left: 10px;text-align: center;margin-top: -20px">-->
                                                        <!--                                                                    <div class="col-3"></div>-->
                                                        <!--                                                                    <div  class="col-3" style="font-size: 10px;position: absolute;left: 163px;top: 4px;"><img  height="20px" width="20px" src="./dashboard_resources/bfdown.png" alt="task"><br ><span  style="margin-left: 3px;">BF</span></div>-->
                                                        <!--                                                                    <div  class="col-3" style="font-size: 10px;position: absolute;left: 188px;top: 4px;"><img  height="20px" width="20px" src="./dashboard_resources/lunchdown.png" alt="task"><br ><span  style="margin-left: 3px;">LN</span></div>-->
                                                        <!--                                                                    <div  class="col-3" style="font-size: 10px;position: absolute;left: 212px;top: 4px;"><img  height="20px" width="20px" src="./dashboard_resources/dinnerdown.png" alt="task"><br ><span  style="margin-left: 3px;">DN</span></div>-->
                                                        <!--                                                                </div>-->
                                                        <!--                                                            </div>-->
                                                    </div>
                                                    <div class="row" style="width:100%;border-top: dotted grey 3px;margin-left:-8px;margin-top: 12px"></div>
                                                    <div class="row">
                                                        <div class="col-8" style="position: relative;"><span style="color:grey;position: absolute;top:10px;left: 23px"><i class="fa fa-search"></i></span>
                                                            <!--                                                                {{location.id+"&#45;&#45;"+day}}-->
                                                            <v-select v-model="objj[location.id]['day-'+day]['place']"
                                                                      name="addplaceloc"
                                                                      label="title"
                                                                      @input="addtoplaces(day,location.id,editplan)"

                                                                      :value="objj[location.id]['day-'+day]['place']"
                                                                      :options="localplace[location.id][day]"
                                                                      multiple
                                                                      placeholder="ENTER SIGHTSEEING"
                                                                      style="font-size: 14px;padding-left: 40px;width: 328px;margin-top: 10px;border: 1px solid gainsboro;border-radius: 15px;"

                                                            />

                                                        </div>
                                                        <div class="col-4" style="position: relative;">
                                                            <span style="color:green;font-size:14px">
                                                                <i @click="clplace('refresh')" style="margin-top: 16%;margin-left: -5%;" class="fa fa-refresh" aria-hidden="true"></i></span>
                                                            <button  @click="clplace(true),placedata.city_id= placedata.city=[location.id.split('-')[0]]" style="text-align: left; width: 90%; font-size: 11px; background-color: white; border: 1px solid gainsboro; border-radius: 15px; /*! margin-top: 10px; */ /*! margin-left: -9px; */position: absolute;top: 46%;left: 18%;">ADD SIGHTSEEING</button><span  style="/*! font-weight: normal; */ color: grey; position: absolute; top: 47%; left: 82%; font-size: 12px;"><i  class="fa fa-plus"></i></span></div>
                                                    </div>
                                                    <div class="row" style="margin-top: 10px">
                                                        <div class="col-3">


                                                            <span style="font-size: 12px;color:grey;">ALL</span><label class="custom-control overflow-checkbox">
                                                            <input type="radio"  :name="'radioplace'+location.id"  @change="changedisplay('allplace')" class="overflow-control-input" checked>
                                                            <span class="overflow-control-indicator" style="margin-left: 30px;margin-top: -25px"></span>

                                                        </label>
                                                        </div>
                                                        <div class="col-3">

                                                            <span style="font-size: 12px;color:grey;margin-left: -50px">PRIVATE</span><label class="custom-control overflow-checkbox">
                                                            <input type="radio" :name="'radioplace'+location.id" @change="changedisplay('privateplace')" class="overflow-control-input" >
                                                            <span class="overflow-control-indicator" style="margin-left: 0px;margin-top: -25px"></span>

                                                        </label>
                                                        </div>
                                                        <div class="col-3">

                                                            <span style="font-size: 12px;color:grey;margin-left: -80px">TRANSFER</span><label class="custom-control overflow-checkbox">
                                                            <input type="radio" :name="'radioplace'+location.id" @change="changedisplay('transferplace')" class="overflow-control-input" >
                                                            <span class="overflow-control-indicator" style="margin-left: -18px;margin-top: -25px"></span>

                                                        </label>
                                                        </div>
                                                        <!--                                                            <div class="col-3">-->

                                                        <!--                                                                <span style="font-size: 12px;color:grey;margin-left: -100px">MY SELECTION</span><label class="custom-control overflow-checkbox">-->
                                                        <!--                                                                <input type="radio" :name="'radioplace'+location.id" class="overflow-control-input" >-->
                                                        <!--                                                                <span class="overflow-control-indicator" style="margin-left: -14px;margin-top: -25px"></span>-->

                                                        <!--                                                            </label>-->
                                                        <!--                                                            </div>-->

                                                    </div>
                                                    <div class="row">

                                                        <div v-for="(placeinfo, index) in objj[location.id]['day-'+day]['place']">
                                                            <div v-if="placeinfo['categories']=='place'">

                                                                <div  class="col-12"   v-show="allplace">
                                                                    <label class="custom-control overflow-checkbox">
                                                                        <input type="checkbox" disabled checked class="overflow-control-input" >
                                                                        <!--                                                                    <p style="width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">{{placeinfo['title']}}</p>-->
                                                                        <input type="text" disabled :value="placeinfo['title']" style="font-weight: 100;width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">
                                                                        <!--                                                                        <span style="position:relative;">-->
                                                                        <!--                                                                     <img src="./dashboard_resources/info.png" style="position: absolute;width: 20px;height: 20px;left:-83px;top:2px">-->
                                                                        <!--                                                                        </span>-->
                                                                        <!--                                                                        <span style="margin-left: -50px"><img src="./dashboard_resources/drag.png" style="height: 15px;width: 15px;margin-top:-5px">-->
                                                                        <!--                                                                        </span>-->
                                                                        <!--                                                                        <span><img height="25px" width="25px" src="./dashboard_resources/edit.png" style="margin-top:-3px;" alt="task"></span>-->
                                                                        <span class="overflow-control-indicator" style="margin-left: 0px;margin-top: 0px"></span>
                                                                    </label>
                                                                </div>

                                                            </div>
                                                            <div v-if="placeinfo['categories']=='custom'">
                                                                <div  class="col-12"   v-show="privateplace">
                                                                    <label class="custom-control overflow-checkbox">
                                                                        <input type="checkbox" checked class="overflow-control-input" >
                                                                        <!--                                                                    <p style="width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">{{placeinfo['title']}}</p>-->
                                                                        <input type="text" disabled :value="placeinfo['title']" style="font-weight: 100;width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">
                                                                        <!--                                                                       <span style="position:relative;">-->
                                                                        <!--                                                                     <img src="./dashboard_resources/info.png" style="position: absolute;width: 20px;height: 20px;left:-85px;top:0px"></span>-->
                                                                        <!--                                                                       <span style="margin-left: -50px"><img src="./dashboard_resources/drag.png" style="height: 15px;width: 15px;margin-top:-5px"></span>-->
                                                                        <!--                                                                       <span><img height="25px" width="25px" src="./dashboard_resources/edit.png" style="margin-top:-3px;margin-left: 5px" alt="task"></span>-->
                                                                        <span class="overflow-control-indicator" style="margin-left: 0px;margin-top: 0px"></span>
                                                                    </label>
                                                                </div>
                                                            </div>

                                                            <div v-if="placeinfo['categories']=='transfer'">
                                                                <div  class="col-12"   v-show="transferplace">
                                                                    <label class="custom-control overflow-checkbox">
                                                                        <input type="checkbox" checked class="overflow-control-input" >
                                                                        <!--                                                                    <p style="width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">{{placeinfo['title']}}</p>-->
                                                                        <input type="text" disabled :value="placeinfo['title']" style="font-weight: 100;width: 90%;margin-left: 16px;margin-top: 5px;height: 30px;border:0;border:solid gainsboro 2px">
                                                                        <!--                                                                       <span style="position:relative;">-->
                                                                        <!--                                                                     <img src="./dashboard_resources/info.png" style="position: absolute;width: 20px;height: 20px;left:-85px;top:0px"></span>-->
                                                                        <!--                                                                       <span style="margin-left: -50px"><img src="./dashboard_resources/drag.png" style="height: 15px;width: 15px;margin-top:-5px"></span>-->
                                                                        <!--                                                                       <span><img height="25px" width="25px" src="./dashboard_resources/edit.png" style="margin-top:-3px;margin-left: 5px" alt="task"></span>-->
                                                                        <span class="overflow-control-indicator" style="margin-left: 0px;margin-top: 0px"></span>
                                                                    </label>
                                                                </div>
                                                            </div>



                                                        </div>
                                                        <!--                                                            <div class="col-12" style="margin-top: -15px">-->
                                                        <!--                                                                <label class="custom-control overflow-checkbox">-->
                                                        <!--                                                                    <input type="checkbox" class="overflow-control-input" ><input type="text" style="width: 90%;margin-left: 16px;margin-top: 8px;height: 30px;border:0;border:solid gainsboro 2px"><span style="position:relative;"><img src="./dashboard_resources/info.png" style="position: absolute;width: 20px;height: 20px;left:-85px;top:0px"></span><span style=";margin-left: -50px"><img src="./dashboard_resources/drag.png" style="height: 15px;width: 15px;margin-top:-5px"></span> <span><img height="25px" width="25px" src="./dashboard_resources/edit.png" style="margin-top:-3px;margin-left: 5px" alt="task"></span>-->
                                                        <!--                                                                    <span class="overflow-control-indicator" style="margin-left: 0px;margin-top: 4px"></span>-->
                                                        <!--                                                                </label>-->
                                                        <!--                                                            </div>-->

                                                        <div style="margin-top: 2px;width: 421px;margin-left: 46px;padding-left:5px;padding-right: 10px">

                                                            <button  @click="editplan = null" class="btn-primary pl-4 pr-4 mb-2" style="float: right;font-size:10px;border:0;border-radius: 10px">Update</button>

                                                        </div>
                                                    </div>
                                                </div>




                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </transition>
                    </div>


                </div>




                <div style="display: none" v-for="(placeinfo, index) in objj[location.id]['day-'+day]['place']">Place: {{placeinfo['title']}}:

                    <label>From:</label><input type="text" v-model="objj[location.id]['day-'+day]['place'][index]['from_time']" >
                    <label>To:</label><input type="text" v-model="objj[location.id]['day-'+day]['place'][index]['to_time']">
                    <label>Remark:</label><input type="text" v-model="objj[location.id]['day-'+day]['place'][index]['remark']">

                </div>

            </div>


        </div>

        <!-- Add Place Modal -->
        <div >
            <div v-if="addplacemodal===true">
                <transition name="modal">
                    <div class="modal-mask">
                        <div class="modal-wrapper">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <button type="button" class="close" @click="clplace(false)">
                                            <span aria-hidden="true">&times;</span>
                                        </button>

                                    </div>
                                    <div class="modal-body" style="margin-left: -10px;margin-right: 10px;">

                                        <div>
                                            <h2> Add Place/Event Only For This Group </h2>
                                            <div class="col-md-6">Name:</div>
                                            <div class="col-md-6"> Contact no.:</div>
                                            <div class="col-md-6"> <input  style="width: 100%; border: 0.5px solid;"  type="text"
                                                                           class="form-control"
                                                                           name="title"
                                                                           placeholder="Enter Title *"
                                                                           v-model="placedata.title"
                                                                           @input="updateTitle">
                                            </div>
                                            <div class="col-md-6">
                                                <input type="text" style="width:100%;"
                                                       class="form-control"
                                                       name="contact_no"
                                                       placeholder="Enter Contact no"
                                                       v-model="placedata.contact_no"
                                                       @input="updateContact_no">
                                            </div>
                                            <div class="col-md-6">Lat:</div>
                                            <div class="col-md-6"> Long:</div>
                                            <div class="col-md-6"> <input type="text" style="width:100%;"
                                                                          class="form-control"
                                                                          name="place_latitude"
                                                                          placeholder="Enter Place latitude"
                                                                          v-model="placedata.place_latitude"
                                                                          @input="updatePlace_latitude">
                                            </div>
                                            <div class="col-md-6">
                                                <input type="text" style="width:100%;"
                                                       class="form-control"
                                                       name="place_longitude"
                                                       placeholder="Enter Place longitude"
                                                       v-model="placedata.place_longitude"
                                                       @input="updatePlace_longitude">
                                            </div><br>
                                            <div class="col-md-12">
                                                Featured Image:
                                                <input type="file" style="width:100%;"
                                                       class="form-control"

                                                       @change="updateFeatured_image">

                                            </div>

                                            <br><br>
                                            Description: <textarea cols="6" rows="5" style="width: 100%; border: 0.5px solid;" name="description"
                                                                   :id="'description'"
                                                                   v-model="placedata.description"
                                                                   @input="updateDescription"></textarea>

                                            <br><br>
                                            <input type="button"  value="Add" @click="addplacenew" >
                                        </div>



                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </transition>
            </div>


        </div>


    </div>
    <!--@click="remove"-->
</template>


<script>
    import DaysPlaceComponent from '../cruds/daysplaces'
    import moment from 'moment'

    import { CarouselCard, CarouselCardItem } from 'vue-carousel-card'
    import 'vue-carousel-card/styles/index.css'
    import { mapGetters, mapActions } from 'vuex'


    export default{

        data(){
            return{
                tour:[],
                days:[],
                mealday:[],
                objj:{},
                temp:{},
                defaultt:[],
                localplace:{},
                hotelselect:[],
                hotelselect2:[],
                hoteloptions:{},
                non:[],
                non2:[],
                slides:['1','2','3'],
                showlocation:null,
                showday:null,
                editplan:null,
                allplace:true,
                privateplace:true,
                transferplace:false,
                alldaycounter:[]
                // addplacemodal:null,
                // placedata:{'title':'',
                //     'description':'',
                //     'contact_no':'',
                //     'categories':'custom',
                //     'place_longitude':'',
                //     'place_latitude':'',
                //     'featured_image':'',
                //     'city_id':'',
                //     'city[0]':'',
                // }
                // tt:[{"id":1,"title":"ffhjhj"}]
            }

        },
        computed:{
            ...mapGetters('BookingsSingle', ['placedata','addplacemodal'])
        },

        mounted(){


            //<button  v-for="(dayl,index1 ) in parseInt(location.days)" @click="showday = dayl+index1"


            this.defaultt.push({"id":1,
                "title":"Day at Leisure",
                "to_time":"",
                "from_time":"",
                "remark":"",
                "created_by_id":1,
                "categories":"place"

            });


        },
        watch: {
            'hotels': function(newVal, oldVal) {
                console.log("watch");
                console.log('value changed from ' + oldVal + ' to ' + newVal);
                this.hotelset(this.location.id,this.hotels);
            },
            'tour_location': function (n,o) {
                // this.showlocation=this.tour_location[0].name+0;
                this.showday=1;
                var len=n.length;
                for(var t=0;t<len ;t++){
                    //
                    if(t==0){
                        this.alldaycounter[t]=0
                        // this.alldaycounter[t]=parseInt(t) + parseInt(this.tour_location[t]['days'])
                    }
                    // else if(t==1){
                    //     this.alldaycounter[t]=1+parseInt(this.tour_location[t]['daynights'])
                    // }
                    else{
                        this.alldaycounter[t]=parseInt(this.alldaycounter[t-1])+parseInt(this.tour_location[t-1]['days'])
                    }
                    // this.alldaycounter[t]=parseInt(t)+1 + parseInt(this.tour_location[t]['days'])
                }


            },
            'addplacemodal': function (n,o) {
                console.log('addplace'+n);
                if(n!==false &&  n!==true &&  n!='refresh'){
                    // alert("new places fetching");
                    this.fetchplace(n);
                    this.closeplace(false)
                    this.localplace={};
                }
                if(n===false){
                    this.closeplace(false)
                    this.localplace={};
                }
                if(n=='refresh'){
                    // this.closeplace(false)
                    this.localplace={};
                }
// this.addplacemodal=false;



            },
        },
        created(){


        },

        methods: {
            ...mapActions('BookingsSingle', ['addPlace','closeplace','fetchplace']),

            changemeal(location,day,meal,status,day1,index2){
                console.log("changemeal");
                console.log(meal);
                this.temp={};
                this.temp=Object.assign(this.temp,this.objj);


                this.temp[location][day]['meal'][meal]=status;


                this.objj=Object.assign(this.objj,this.temp);
                console.log(this.temp);
                this.showday="";
                this.showday=day1+index2;
            },
            setdayscout(){
                console.log("count set days")
                var len=this.tour_location.length;
                var len2=this.alldaycounter.length;
                if(len!=len2){
                    for(var t=0;t<len ;t++){
                        //
                        if(t==0){
                            this.alldaycounter[t]=0
                            // this.alldaycounter[t]=parseInt(t) + parseInt(this.tour_location[t]['days'])
                        }
                        // else if(t==1){
                        //     this.alldaycounter[t]=1+parseInt(this.tour_location[t]['daynights'])
                        // }
                        else{
                            this.alldaycounter[t]=parseInt(this.alldaycounter[t-1])+parseInt(this.tour_location[t-1]['days'])
                        }
                        // this.alldaycounter[t]=parseInt(t)+1 + parseInt(this.tour_location[t]['days'])
                    }
                }

            },
            addplacenew(){
                this.addPlace()
            },
            clplace(e){
                this.closeplace(e)
            },
            updateTitle(e) {
                // this.setTitle(e.target.value)
            },
            updateDescription(value) {
                // this.setDescription(value)
            },
            updateContact_no(e) {
                // this.setContact_no(e.target.value)
            },
            updateCategories(e) {
                // this.setCategories(e.target.value)
            },
            updateAddress(e) {
                // this.setAddress(e.target.value)
            },
            updatePlace_longitude(e) {
                // this.setPlace_longitude(e.target.value)
            },
            updatePlace_latitude(e) {
                // this.setPlace_latitude(e.target.value)
            },
            updateFeatured_image(e) {
                this.placedata.featured_image=(e.target.files[0]);
                this.$forceUpdate();
            },

            changeview(){
                this.$emit('showtrav');
            },
            changedisplay(item){

                if(item=='allplace'){



                    this.allplace=true;
                    this.privateplace=true;
                    this.transferplace=true;

                }
                if(item=='privateplace'){


                    this.allplace=false;
                    this.privateplace=true;
                    this.transferplace=false;
                }
                if(item=='transferplace'){

                    this.allplace=false;
                    this.privateplace=false;
                    this.transferplace=true;
                }

            },
            moment_format(f,days,index){

//   return   moment('2019-02-28').add(7,'days').format("DD MMM YYYY");
//     if(index==0){
                return   moment(moment(f).format("YYYY-MM-DD")).add(parseInt(days)-1,'days').format("DD MMM YYYY");

                // }
                // else {
                //     return   moment(moment(f).format("YYYY-MM-DD")).add(days,'days').format("DD MMM YYYY");
                //
                // }

            },
            objpre(){

                console.log('objpre1');
              if(_.isEmpty(this.objj)){
                  console.log('objpre2');
                  this.objj= Object.assign(this.objj,this.$props.itiplaces);

              }
                return null;
            },
            preselect(a,b,locationid,place){
                console.log('objpre3');
                console.log(a);
                console.log(b);
                console.log(locationid);
                console.log(place);


                if(typeof a !== 'undefined' && typeof b !== 'undefined' && typeof locationid !== 'undefined' && typeof place !== 'undefined'  ){
                    // alert("day:"+a+"-"+b+"loc"+locationid+"place"+place);


                    if(_.isEmpty(this.localplace)){
                        // alert("test");
                        var pla=_.cloneDeep(place);
                        this.localplace[locationid]={[a]:pla};
                        //var arr=_.clone(place);
                        // this.localplace[locationid][a]=place;
                        console.log("cloned");
                        console.log(this.localplace);
                    }
                    else if(this.localplace.hasOwnProperty(locationid)){

                        if(this.localplace[locationid].hasOwnProperty(a)){


                        }else {

                            var pla=_.cloneDeep(place);
                            // this.localplace[locationid]={[a]:pla};

                            this.temp[locationid]={};

                            this.temp[locationid]={[a]:pla};


                            this.localplace[locationid] = Object.assign(this.localplace[locationid], this.temp[locationid]);
                            this.temp = Object.assign({}, {});


                        }


                    }
                    else {

                        var pla=_.cloneDeep(place);
                        this.localplace[locationid]={[a]:pla};

                    }



                    if(_.isEmpty(this.objj)){
                        // alert("me empty");

                        this.days[a]=[{"id":1,
                            "title":"Day at Leisure",
                            "to_time":"",
                            "from_time":"",
                            "remark":"",
                            "created_by_id":1,
                            "categories":"place"

                        }];
                        this.mealday[a]=JSON.parse(JSON.stringify(this.meal));

                        var day=a;

                        this.temp[locationid]={};

                        this.temp[locationid]['day-'+day]={'place':this.days[day],'meal': JSON.parse(JSON.stringify(this.meal))};
                        this.objj = Object.assign(this.objj, this.temp);
                        this.temp = Object.assign({}, {});

                        // this.$emit('addplace',this.objj)
                    }
                    else if(  this.objj.hasOwnProperty(locationid)){
                        var day=a;
                        // alert("hasOwnProperty");
                        if(this.objj[locationid].hasOwnProperty(['day-'+day])){

                            // alert("day not empty");

                        }
                        else {

                            // alert("day empty");
                            this.days[a]=[{"id":1,
                                "title":"Day at Leisure",
                                "to_time":"",
                                "from_time":"",
                                "remark":"",
                                "created_by_id":1,
                                "categories":"place"

                            }];
                            this.mealday[a]=JSON.parse(JSON.stringify(this.meal));
                            // alert("me not else in");
                            this.temp=Object.assign(this.temp,this.objj);
                            this.temp[locationid]['day-'+day]={'place':this.days[day],'meal':JSON.parse(JSON.stringify(this.meal))};
                            this.objj[locationid] = Object.assign(this.objj[locationid], this.temp[locationid]);
                            this.temp = Object.assign({}, {});

                        }


                    }
                    else {

                        // var day=a;
                        //  alert("no hasOwnProperty");

                        this.days[a]=[{"id":1,
                            "title":"Day at Leisure",
                            "to_time":"",
                            "from_time":"",
                            "remark":"",
                            "created_by_id":1,
                            "categories":"place"

                        }];
                        this.mealday[a]=JSON.parse(JSON.stringify(this.meal));
                        var day=a;

                        this.temp[locationid]={};

                        this.temp[locationid]['day-'+day]={'place':this.days[day],'meal': JSON.parse(JSON.stringify(this.meal))};
                        this.objj = Object.assign(this.objj, this.temp);
                        this.temp = Object.assign({}, {});


                    }
                    this.$emit('addplace',this.objj)


                }
                return null;
            },
            remove(){
                //  alert('hello');
                this.$emit('delete', this.location.id)

            },

            addtoplaces(day,locationid,editplan){

                if( this.objj.hasOwnProperty(locationid)){

                    if(this.objj[locationid].hasOwnProperty('day-'+day)){

                        // this.objj[locationid]['day-'+day].place=_.clone(this.days[day])
                        this.objj[locationid]['day-'+day].meal=_.clone(JSON.parse(JSON.stringify(this.meal)))
                    }
                    else{


                        // Object.assign( this.objj[locationid], {['day-'+day]: {'place':_.clone(this.days[day])}})
                        Object.assign( this.objj[locationid], {['day-'+day]: {'meal':_.clone(JSON.parse(JSON.stringify(this.meal)))}})

                    }


                }
                else {

                    this.temp[locationid]={};

                    //  this.objj[locationid].push([day]);
                    // this.temp[locationid]['day-'+day]={'place':_.clone(this.days[day])};
                    this.temp[locationid]['day-'+day]={'meal':_.clone(JSON.parse(JSON.stringify(this.meal)))};

                    this.objj = Object.assign(this.objj, this.temp);

                }


                this.$emit('addplace',this.objj)

                this.editplan=null;
                this.editplan=editplan;
            }


        },
        components: {CarouselCard, CarouselCardItem

        } ,
        props: ['place','tour_location','datestart','meal','summ','hotel','itiplaces']


    }


</script>

<style scoped>
    .custom-control.material-checkbox .material-control-input {
        display: none;
    }
    .custom-control.material-checkbox .material-control-input:checked ~ .material-control-indicator {
        border-color: var(--color);
        transform: rotateZ(45deg) translate(1px, -5px);
        width: 10px;
        border-top: 0px solid #fff;
        border-left: 0px solid #fff;
    }
    .custom-control.material-checkbox .material-control-indicator {
        display: inline-block;
        position: absolute;
        top: 4px;
        left: 0;
        width: 16px;
        height: 16px;
        border: 2px solid #aaa;
        transition: 0.3s;
    }
    .custom-control.fill-checkbox {
        --color: #26a69a;
    }
    .custom-control.fill-checkbox .fill-control-input {
        display: none;
    }
    .custom-control.fill-checkbox .fill-control-input:checked ~ .fill-control-indicator {
        background-color: var(--color);
        border-color: var(--color);
        background-size: 80%;
    }
    .custom-control.fill-checkbox .fill-control-indicator {
        border-radius: 3px;
        display: inline-block;
        position: absolute;
        top: 2px;
        left: 0;
        width: 10px;
        height: 16px;
        border: 2px solid #aaa;
        transition: 0.3s;
        background: transperent;
        background-size: 0%;
        background-position: center;
        background-repeat: no-repeat;

    }
    .custom-control.overflow-checkbox .overflow-control-input {
        display: none;
    }
    .custom-control.overflow-checkbox .overflow-control-input:checked ~ .overflow-control-indicator::after {
        transform: rotateZ(45deg) scale(1);
        background-color: transparent;
        top: -2px;
        left: 10px;
    }
    .custom-control.overflow-checkbox .overflow-control-input:checked ~ .overflow-control-indicator::before {
        opacity: 1;

    }
    .custom-control.overflow-checkbox .overflow-control-indicator {
        border-radius: 3px;
        display: inline-block;
        position: absolute;
        top: 4px;
        left: 0;
        width: 23px;
        height: 23px;
        border: 3px solid gainsboro;

    }
    .custom-control.overflow-checkbox .overflow-control-indicator::after {
        content: '';
        display: block;
        position: absolute;
        width: 16px;
        height: 16px;
        transition: 0.3s;
        transform: rotateZ(90deg) scale(0);
        width: 10px;
        border:0;
        border-bottom: 4px solid green;
        border-right: 4px solid green;
        border-radius: 3px;
        top: -2px;
        left: 2px;

    }
    .custom-control.overflow-checkbox .overflow-control-indicator::before {
        content: '';

        display: block;
        position: absolute;
        width: 16px;
        height: 16px;
        transition: 0.3s;
        width: 10px;
        border-right: 7px solid #fff;
        border-radius: 3px;
        transform: rotateZ(45deg) scale(1);
        top: -4px;
        left: 5px;
        opacity: 0;
    }

    .modal-mask {
        position: fixed;
        z-index: 9998;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, .5);
        display: table;
        transition: opacity .3s ease;
    }

    .modal-wrapper {
        display: table-cell;
        /*vertical-align: middle;*/
    }
    .activedev{
        display: block !important;
    }
    .hidedev{
        display: none;
    }
    .bg-primary {
        color: white !important;
    }
    input[type="file"] {
        display: block !important;
    }
</style>
