<template>
    <section class="content-wrapper" style="margin-left: 5% !important;min-height: 960px;">
        <section class="content-header">
            <h1>Users</h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <form @submit.prevent="submitForm" novalidate>
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Edit</h3>
                            </div>

                            <div class="box-body">
                                <back-buttton></back-buttton>
                            </div>

                            <bootstrap-alert />

                            <div class="box-body">
                                <div class="form-group">
                                    <label for="name">Name *</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="name"
                                            placeholder="Enter Name *"
                                            :value="item.name"
                                            @input="updateName"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="email">Email *</label>
                                    <input
                                            type="email"
                                            class="form-control"
                                            name="email"
                                            placeholder="Enter Email *"
                                            :value="item.email"
                                            @input="updateEmail"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="password">Password *</label>
                                    <input
                                            type="password"
                                            class="form-control"
                                            name="password"
                                            placeholder="Enter Password *"
                                            @input="updatePassword"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="role">Role *</label>
                                    <v-select
                                            name="role"
                                            label="title"
                                            @input="updateRole"
                                            :value="item.role"
                                            :options="rolesAll"
                                            multiple
                                    />
                                </div>
                                <div class="form-group">
                                    <div class="checkbox">
                                        <label>
                                            <input
                                                    type="checkbox"
                                                    name="approved"
                                                    :value="item.approved"
                                                    :checked="item.approved == true"
                                                    @change="updateApproved"
                                            >
                                            Approved
                                        </label>
                                    </div>
                                </div>
<!--                                <div class="form-group">-->
<!--                                    <label for="team">Team</label>-->
<!--                                    <v-select-->
<!--                                            name="team"-->
<!--                                            label="name"-->
<!--                                            @input="updateTeam"-->
<!--                                            :value="item.team"-->
<!--                                            :options="teamsAll"-->
<!--                                    />-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label for="account_manager">Account manager</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="account_manager"
                                            placeholder="Enter Account manager"
                                            :value="item.account_manager"
                                            @input="updateAccount_manager"
                                    >
                                </div>
<!--                                <div class="form-group">-->
<!--                                    <label for="agree">Agree</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="agree"-->
<!--                                            placeholder="Enter Agree"-->
<!--                                            :value="item.agree"-->
<!--                                            @input="updateAgree"-->
<!--                                    >-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label for="banner_color">Banner color</label>
                                    <color-picker v-model="item.banner_color"></color-picker>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="banner_color"
                                            placeholder="Enter Banner color"
                                            :value="item.banner_color"
                                            @input="updateBanner_color"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="address">Address</label>
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="address"-->
<!--                                            placeholder="Enter Address"-->
<!--                                            :value="item.address"-->
<!--                                            @input="updateAddress"-->
<!--                                    >-->
                                    <vue-ckeditor
                                        :value="item.address"
                                        @input="updateAddress"
                                    />
                                </div>
                                <div class="form-group">
                                    <label for="city">City</label>
                                    <v-select
                                            name="city"
                                            label="title"
                                            @input="updateCity"
                                            :value="item.city"
                                            :options="citiesAll"
                                    />
                                </div>
                                <div class="form-group">
                                    <label for="state">State</label>
                                    <v-select
                                            name="state"
                                            label="title"
                                            @input="updateState"
                                            :value="item.state"
                                            :options="statesAll"
                                    />
                                </div>
                                <div class="form-group">
                                    <label for="country">Country</label>
                                    <v-select
                                            name="country"
                                            label="title"
                                            @input="updateCountry"
                                            :value="item.country"
                                            :options="countriesAll"
                                    />
                                </div>
                                <div class="form-group">
                                    <label for="phone">Phone</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="phone"
                                            placeholder="Enter Phone"
                                            :value="item.phone"
                                            @input="updatePhone"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="postcode">Postcode</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="postcode"
                                            placeholder="Enter Postcode"
                                            :value="item.postcode"
                                            @input="updatePostcode"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="company">Company</label>
                                    <v-select
                                            name="addlocations"
                                            label="name"
                                            @input="updateCompany"
                                            :value="item.company"
                                            :options="agencyAll"

                                    />
                                    <!--                                    <input-->
                                    <!--                                            type="text"-->
                                    <!--                                            class="form-control"-->
                                    <!--                                            name="company"-->
                                    <!--                                            placeholder="Enter Company"-->
                                    <!--                                            :value="item.company"-->
                                    <!--                                            @input="updateCompany"-->
                                    <!--                                            >-->
                                </div>
<!--                                <div class="form-group">-->
<!--                                    <label for="device">Device</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="device"-->
<!--                                            placeholder="Enter Device"-->
<!--                                            :value="item.device"-->
<!--                                            @input="updateDevice"-->
<!--                                    >-->
<!--                                </div>-->
<!--                                <div class="form-group">-->
<!--                                    <label for="locale">Locale</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="locale"-->
<!--                                            placeholder="Enter Locale"-->
<!--                                            :value="item.locale"-->
<!--                                            @input="updateLocale"-->
<!--                                    >-->
<!--                                </div>-->
<!--                                <div class="form-group">-->
<!--                                    <label for="login">Login</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="login"-->
<!--                                            placeholder="Enter Login"-->
<!--                                            :value="item.login"-->
<!--                                            @input="updateLogin"-->
<!--                                    >-->
<!--                                </div>-->
<!--                                <div class="form-group">-->
<!--                                    <label for="login_date_time">Login date time</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="login_date_time"-->
<!--                                            placeholder="Enter Login date time"-->
<!--                                            :value="item.login_date_time"-->
<!--                                            @input="updateLogin_date_time"-->
<!--                                    >-->
<!--                                </div>-->
<!--                                <div class="form-group">-->
<!--                                    <label for="login_status">Login status</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="login_status"-->
<!--                                            placeholder="Enter Login status"-->
<!--                                            :value="item.login_status"-->
<!--                                            @input="updateLogin_status"-->
<!--                                    >-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label for="logo">Logo</label>
                                    <input
                                            type="file"
                                            class="form-control"
                                            @change="updateLogo"
                                    >
                                    <ul v-if="item.logo" class="list-unstyled">
                                        <li>
                                            {{ item.logo.name || item.logo.file_name }}
                                            <button class="btn btn-xs btn-danger"
                                                    type="button"
                                                    @click="removeLogo"
                                            >
                                                Remove file
                                            </button>
                                        </li>
                                    </ul>
                                </div>
                                <div v-if="isagency==='agency'">
                                    <label for="subscription">License Management</label><br>

                                    <label>   Pay as you go</label>
                                    <label class="switch">
                                        <input type="checkbox" v-model="meta.meta_subscription">
                                        <span class="slider round"></span>
                                    </label>
                                    <label>   Subscription</label>


                                    <div v-if="meta.meta_subscription">
                                        <div class="row">
                                            <div  class="col-4" >
                                                Start Date : <date-picker

                                                v-model="meta.meta_licence.start_date"
                                                :config="$root.dpconfigDatetime"

                                            >
                                            </date-picker>
                                            </div>
                                            <div  class="col-4" >
                                                End Date : <date-picker

                                                v-model="meta.meta_licence.exp_date"
                                                :config="$root.dpconfigDatetime"

                                            >
                                            </date-picker>
                                            </div>
                                        </div>

                                    </div>

                                    <div v-else>
                                        <div class="row">
                                            <div  class="col-4" >
                                                <label>  Sending Quotes Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.query"></div>
                                            <div  class="col-4" >  <label>  Single Activation Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.itinerary"></div>
                                            <div  class="col-4" >   <label> Group Activation Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.group"></div>
                                            <div  class="col-4" >  <label>  Broadcast To All Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.broadcast_to_all"></div>
                                            <div  class="col-4" >  <label>  Broadcast To Live Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.broadcast_to_live"></div>
                                            <div  class="col-4" >  <label>  Direct Notification Charges? :</label> <input  class="form-control" type="text" v-model="meta.meta_licence.direct"></div>
                                            <div  class="col-4" >  <label>  Exhibitor Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.exhibitor"></div>
                                            <div  class="col-4" >  <label>  Nomination Charges? :</label> <input class="form-control"  type="text" v-model="meta.meta_licence.nomination"></div>
                                        </div>
                                    </div>



                                </div>
                                <div class="form-group" v-if="!meta.meta_subscription">
                                    <label for="mycred_default_total">Credit Points</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="mycred_default_total"
                                            placeholder="Enter Credit Points"
                                            :value="item.mycred_default_total"
                                            @input="updateMycred_default_total"
                                    >
                                </div>
<!--                                <div class="form-group">-->
<!--                                    <label for="mycred_epp_mycred">Mycred epp mycred</label>-->
<!--                                    <input-->
<!--                                            type="text"-->
<!--                                            class="form-control"-->
<!--                                            name="mycred_epp_mycred"-->
<!--                                            placeholder="Enter Mycred epp mycred"-->
<!--                                            :value="item.mycred_epp_mycred"-->
<!--                                            @input="updateMycred_epp_mycred"-->
<!--                                    >-->
<!--                                </div>-->
                                <div class="form-group">
                                    <label for="owners_email">Owners email</label>
                                    <input
                                            type="text"
                                            class="form-control"
                                            name="owners_email"
                                            placeholder="Enter Owners email"
                                            :value="item.owners_email"
                                            @input="updateOwners_email"
                                    >
                                </div>
                                <!--                                meta-->


                                <div class="form-group">
                                    <label for="meta_bio_metric_sms">Bio Metric Sms</label>

                                    <textarea
                                            type="text"
                                            class="form-control"
                                            name="meta_bio_metric_sms"
                                            placeholder="meta_bio_metric_sms"
                                            :value="meta.meta_bio_metric_sms"
                                            @input="updatemeta_bio_metric_sms"
                                    ></textarea>

                                </div>

                                <div class="form-group">
                                    <label for="meta_doc_not_rec_sms">Documents not received sms</label>

                                    <textarea
                                            type="text"
                                            class="form-control"
                                            name="meta_doc_not_rec_sms"
                                            placeholder="meta_doc_not_rec_sms"
                                            :value="meta.meta_doc_not_rec_sms"
                                            @input="updatemeta_doc_not_rec_sms"
                                    ></textarea>

                                </div>
                                <div class="form-group">
                                    <label for="meta_interview_sms">Interview sms</label>

                                    <textarea
                                            type="text"
                                            class="form-control"
                                            name="meta_interview_sms"
                                            placeholder="meta_interview_sms"
                                            :value="meta.meta_interview_sms"
                                            @input="updatemeta_interview_sms"
                                    ></textarea>

                                </div>

                                <div class="form-group">
                                    <label for="meta_price_mode_user">Price Mode</label>

                                    <input
                                            type="text"
                                            class="form-control"
                                            name="meta_price_mode_user"
                                            placeholder="meta_price_mode_user"
                                            :value="meta.meta_price_mode_user"
                                            @input="updatemeta_price_mode_user"
                                    >

                                </div>

                                <div class="form-group">
                                    <label for="meta_registered_thru">Registered Thru</label>

                                    <input
                                            type="text"
                                            class="form-control"
                                            name="meta_registered_thru"
                                            placeholder="meta_registered_thru"
                                            :value="meta.meta_registered_thru"
                                            @input="updatemeta_registered_thru"
                                    >

                                </div>
                                <div class="form-group">
                                    <label for="meta_score">Score Formula</label>

                                    <input
                                            type="text"
                                            class="form-control"
                                            name="meta_score"
                                            placeholder="meta_score"
                                            :value="meta.meta_score"
                                            @input="updatemeta_score"
                                    >

                                </div>

                                <div class="form-group">
                                    <label for="meta_sms_i">Sms Itinerary</label>

                                    <textarea
                                            type="text"
                                            class="form-control"
                                            name="meta_sms_i"
                                            placeholder="meta_sms_i"
                                            :value="meta.meta_sms_i"
                                            @input="updatemeta_sms_i"
                                    ></textarea>

                                </div>
                                <div class="form-group">
                                    <label for="meta_bio_metric_mail">Bio Metric Mail Format</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_bio_metric_mail"
                                                  @input="updatemeta_bio_metric_mail"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_cloure_note_i">Cloure Note Itinerary</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_cloure_note_i"
                                                  @input="updatemeta_cloure_note_i"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_cloure_note_q">Cloure Note Query</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_cloure_note_q"
                                                  @input="updatemeta_cloure_note_q"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_doc_not_rec_mail">Documents not received mail</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_doc_not_rec_mail"
                                                  @input="updatemeta_doc_not_rec_mail"
                                    />

                                </div>

                                <div class="form-group">
                                    <label for="meta_incex_note_i">Incl/Exclution Itinerary</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_incex_note_i"
                                                  @input="updatemeta_incex_note_i"
                                    />

                                </div>

                                <div class="form-group">
                                    <label for="meta_incex_note_q">Incl/Exclution Query </label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_incex_note_q"
                                                  @input="updatemeta_incex_note_q"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_interview_mail">Interview mail</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_interview_mail"
                                                  @input="updatemeta_interview_mail"
                                    />

                                </div>


                                <div class="form-group">
                                    <label for="meta_welcome_group">Welcome Group Mail</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_welcome_group"
                                                  @input="updatemeta_welcome_group"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_welcome_note_i">Welcome Note Itinerary</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_welcome_note_i"
                                                  @input="updatemeta_welcome_note_i"
                                    />

                                </div>
                                <div class="form-group">
                                    <label for="meta_welcome_note_q">Welcome Note Query</label>

                                    <vue-ckeditor class="card-body" style="border: 0;color:grey;"

                                                  :value="meta.meta_welcome_note_q"
                                                  @input="updatemeta_welcome_note_q"
                                    />

                                </div>

                                <div class="form-group">
                                    <label for="meta_welcome_note_q">Document tags</label>
                                    <tags-input element-id="tags"
                                                v-model="meta.meta_doc_tags"
                                                :existing-tags="[
        { key: 'passport', value: 'Passport' },
        { key: 'visa', value: 'Visa' },
        { key: 'idproof', value: 'ID Proof' },
                                                              ]"
                                                :typeahead="true"></tags-input>
                                </div>

                            </div>

                            <div class="box-footer">
                                <vue-button-spinner
                                        class="btn btn-primary btn-sm"
                                        :isLoading="loading"
                                        :disabled="loading"
                                >
                                    Save
                                </vue-button-spinner>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</template>


<script>
    import { mapGetters, mapActions } from 'vuex'
    import VoerroTagsInput from '@voerro/vue-tagsinput';
    import ColorPicker from 'vue-color-picker-wheel';
    export default {
        components: {"tags-input":  VoerroTagsInput,ColorPicker },
        data() {
            return {
                // Code...
                isagency:false,
            }
        },
        computed: {
            ...mapGetters('UsersSingle', ['item', 'loading', 'rolesAll', 'teamsAll', 'citiesAll', 'statesAll', 'countriesAll','agencyAll','meta'])
        },
        created() {
            this.fetchData(this.$route.params.id)
            if(_.isArray(this.item.role)){
                console.log(this.item.role[0].title)
                this.isagency=this.item.role[0].title;
            }

        },
        destroyed() {
            this.resetState()
        },
        watch: {
            "$route.params.id": function() {
                this.resetState()
                this.fetchData(this.$route.params.id)
            },
            "meta.meta_subscription": function(){
                if(this.meta.meta_subscription){
                    this.meta.meta_licence.type="Subscription"
                    this.item.mycred_default_total=""
                }
                else {
                    this.meta.meta_licence.type="Point"
                    this.meta.meta_licence.exp_date=""
                    this.meta.meta_licence.start_date=""
                }
            },
            "item.role": function(){
                if(_.isArray(this.item.role)){
                    console.log(this.item.role[0].title)
                    this.isagency=this.item.role[0].title;
                }

            }
        },
        methods: {
            ...mapActions('UsersSingle', ['fetchData', 'updateData', 'resetState', 'setName', 'setEmail', 'setPassword', 'setRole', 'setApproved', 'setTeam', 'setAccount_manager', 'setAgree', 'setBanner_color', 'setAddress', 'setCity', 'setState', 'setCountry', 'setPhone', 'setPostcode', 'setCompany', 'setDevice', 'setLocale', 'setLogin', 'setLogin_date_time', 'setLogin_status', 'setLogo', 'setMycred_default', 'setMycred_default_total', 'setMycred_epp_mycred', 'setOwners_email','fetchAgencyAll',
                'setmeta_bio_metric_mail',
                'setmeta_bio_metric_sms',
                'setmeta_cloure_note_i',
                'setmeta_cloure_note_q',
                'setmeta_doc_not_rec_mail',
                'setmeta_doc_not_rec_sms',
                'setmeta_incex_note_i',
                'setmeta_incex_note_q',
                'setmeta_interview_mail',
                'setmeta_interview_sms',
                'setmeta_price_mode_user',
                'setmeta_registered_thru',
                'setmeta_score',
                'setmeta_sms_i',
                'setmeta_welcome_group',
                'setmeta_welcome_note_i',
                'setmeta_welcome_note_q',
            ]),
            updateName(e) {
                this.setName(e.target.value)
            },
            updateEmail(e) {
                this.setEmail(e.target.value)
            },
            updatePassword(e) {
                this.setPassword(e.target.value)
            },
            updateRole(value) {
                this.setRole(value)
            },
            updateApproved(e) {
                this.setApproved(e.target.checked)
            },
            updateTeam(value) {
                this.setTeam(value)
            },
            updateAccount_manager(e) {
                this.setAccount_manager(e.target.value)
            },
            updateAgree(e) {
                this.setAgree(e.target.value)
            },
            updateBanner_color(e) {
                this.setBanner_color(e.target.value)
            },
            updateAddress(e) {
                this.setAddress(e)
            },
            updateCity(value) {
                this.setCity(value)
            },
            updateState(value) {
                this.setState(value)
            },
            updateCountry(value) {
                this.setCountry(value)
            },
            updatePhone(e) {
                this.setPhone(e.target.value)
            },
            updatePostcode(e) {
                this.setPostcode(e.target.value)
            },
            updateCompany(e) {
                this.setCompany(e)
            },
            updateDevice(e) {
                this.setDevice(e.target.value)
            },
            updateLocale(e) {
                this.setLocale(e.target.value)
            },
            updateLogin(e) {
                this.setLogin(e.target.value)
            },
            updateLogin_date_time(e) {
                this.setLogin_date_time(e.target.value)
            },
            updateLogin_status(e) {
                this.setLogin_status(e.target.value)
            },
            removeLogo(e, id) {
                this.$swal({
                    title: 'Are you sure?',
                    text: "To fully delete the file submit the form.",
                    type: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Delete',
                    confirmButtonColor: '#dd4b39',
                    focusCancel: true,
                    reverseButtons: true
                }).then(result => {
                    if (typeof result.dismiss === "undefined") {
                        this.setLogo('');
                    }
                })
            },
            updateLogo(e) {
                this.setLogo(e.target.files[0]);
                this.$forceUpdate();
            },
            updateMycred_default(e) {
                this.setMycred_default(e.target.value)
            },
            updateMycred_default_total(e) {
                this.setMycred_default_total(e.target.value)
            },
            updateMycred_epp_mycred(e) {
                this.setMycred_epp_mycred(e.target.value)
            },
            updateOwners_email(e) {
                this.setOwners_email(e.target.value)
            },
            //meta

            updatemeta_bio_metric_mail(e) {
                this.setmeta_bio_metric_mail(e)
            },
            updatemeta_bio_metric_sms(e) {
                this.setmeta_bio_metric_sms(e.target.value)
            },
            updatemeta_cloure_note_i(e) {
                this.setmeta_cloure_note_i(e)
            },
            updatemeta_cloure_note_q(e) {
                this.setmeta_cloure_note_q(e)
            },
            updatemeta_doc_not_rec_mail(e) {
                this.setmeta_doc_not_rec_mail(e)
            },
            updatemeta_doc_not_rec_sms(e) {
                this.setmeta_doc_not_rec_sms(e.target.value)
            },
            updatemeta_incex_note_i(e) {
                this.setmeta_incex_note_i(e)
            },
            updatemeta_incex_note_q(e) {
                this.setmeta_incex_note_q(e)
            },
            updatemeta_interview_mail(e) {
                this.setmeta_interview_mail(e)
            },
            updatemeta_interview_sms(e) {
                this.setmeta_interview_sms(e.target.value)
            },
            updatemeta_price_mode_user(e) {
                this.setmeta_price_mode_user(e.target.value)
            },
            updatemeta_registered_thru(e) {
                this.setmeta_registered_thru(e.target.value)
            },
            updatemeta_score(e) {
                this.setmeta_score(e.target.value)
            },
            updatemeta_sms_i(e) {
                this.setmeta_sms_i(e.target.value)
            },
            updatemeta_welcome_group(e) {
                this.setmeta_welcome_group(e)
            },
            updatemeta_welcome_note_i(e) {
                this.setmeta_welcome_note_i(e)
            },
            updatemeta_welcome_note_q(e) {
                this.setmeta_welcome_note_q(e)
            },



            submitForm() {
                this.updateData()
                    .then(() => {
                        this.$router.push({ name: 'users.index' })
                        this.$eventHub.$emit('update-success')
                    })
                    .catch((error) => {
                        console.error(error)
                    })
            }
        }
    }
</script>


<style scoped>
    .switch {
        position: relative;
        display: inline-block;
        width: 60px;
        height: 34px;
    }

    .switch input {
        opacity: 0;
        width: 0;
        height: 0;
    }

    .slider {
        position: absolute;
        cursor: pointer;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background-color: #4a9999;
        -webkit-transition: .4s;
        transition: .4s;
    }

    .slider:before {
        position: absolute;
        content: "";
        height: 26px;
        width: 26px;
        left: 4px;
        bottom: 4px;
        background-color: white;
        -webkit-transition: .4s;
        transition: .4s;
    }

    input:checked + .slider {
        background-color: #17507d;
    }

    input:focus + .slider {
        box-shadow: 0 0 1px #2196F3;
    }

    input:checked + .slider:before {
        -webkit-transform: translateX(26px);
        -ms-transform: translateX(26px);
        transform: translateX(26px);
    }

    /* Rounded sliders */
    .slider.round {
        border-radius: 34px;
    }

    .slider.round:before {
        border-radius: 50%;
    }

</style>
