<template>
    <div>
        <form-wizard @on-complete="onCompletehotel" color="rgb(23, 80, 125)" title=""  subtitle="" finish-button-text="Day Plan">
            <tab-content v-for="(loc,index) in location" :id="'hotel' + index" :key="'hotel' + index" :title="loc.name" icon="fa fa-check">
                <div class="text-left ml-n4"><p class="f-1-5 ml-n2"><span class="bg-color p-2 text-white pl-3 pr-4">{{loc.date_from }}- {{loc.date_to }}</span></p></div>
                <fieldset>
                    <div class="fluid-container">

                        <div class="row">
                            <div class="col-5 offset-1">
                                <div class="row">
                                    <div class="col-12 text-right"><span>OPTION</span></div>
                                    <div class="col-12">
                                        <div class="card">
                                            <div class="fluid-container pl-2">
                                                <div id="box"></div><p class="num">1</p>
                                                <div class="row pr-3 pl-2">
                                                    <div class="col-12 text-left text-muted"><span><img src="./dashboard_resources/hotel name_icon.png" class="hw-3"></span>Hotel Name</div>
                                                    <div class="col-12">
                                                        {{callhotel()}}
                                                        <!--                                {{loc.id}}-->
                                                        <!--                                <input type="text" style="width: 95%;margin-left:10px;margin-right: 10px;border:0px;border:solid gainsboro 1px;border-radius: 2px;" value="The Musica by Ziﬀy Homes">-->
                                                        <v-select :taggable="true" :clearable="false" v-model="hotelselect[loc.id]"
                                                                  name="addhotel"
                                                                  label="title"
                                                                  @input="addtohotel(index,loc.id)"
                                                                  :value="non"
                                                                  :options=hoteloptions[loc.id]
                                                                  :create-option="hotel => ({ title: hotel,id:'',check_in_time:'', check_out_time:'', featured_image_link:'',new:'yes' })"
                                                        />
                                                    </div>
                                                </div>
                                                <div class="row mt-5">
                                                    <div class="col text-center">
                                                        <img v-bind:src="hotelselect[loc.id]['featured_image_link']?hotelselect[loc.id]['featured_image_link']:'./dashboard_resources/hotel_default.png'"
                                                             class="hotel-img">
                                                    </div>
                                                </div>
                                                <div class="row mt-5 ml-2 pt-4 pb-4 mr-3" style="border-top: dotted darkgrey 2px;border-bottom: dotted darkgrey 2px">
                                                    <div class="text-right col-3 f-1-8 text-success"><span><i class="fa fa-circle"></i></span></div>
                                                    <div class="col-6 mt-3 sq-dot-line">
                                                    </div>
                                                    <div class="text-left col-3 f-1-8 text-danger"><span><i class="fa fa-circle"></i></span></div>
                                                    <div class="col-6">
                                                        <div class="row">
                                                            <div class="col-12 text-left">
                                                                <span class="text-muted">Check-in</span>
                                                            </div>
                                                            <div class="col-10">
                                                                <date-picker v-if="hotelselect[loc.id]"
                                                                             v-model="local_tour[index]['hotel']['hotel_data']['check_in_time']"
                                                                             :config="$root.dpconfigTime"
                                                                             name="driver_pickup_date_time"
                                                                             class="form-control"
                                                                ></date-picker>
                                                                <span class="check-in-img p-a"><img src="./dashboard_resources/edit.png" class="h-2 w-3"></span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-6">
                                                        <div class="row">
                                                            <div class="col-12 text-">
                                                                <span class="text-muted">Check-out</span>
                                                            </div>
                                                            <div class="col-10 offset-2">
                                                                <date-picker v-if="hotelselect[loc.id]"
                                                                             v-model="local_tour[index]['hotel']['hotel_data']['check_out_time']"
                                                                             :config="$root.dpconfigTime"
                                                                             name="driver_pickup_date_time"
                                                                             class="form-control"
                                                                >
                                                                </date-picker>
                                                                <span class="check-in-img p-a">
                                                                    <img src="./dashboard_resources/edit.png" class="h-2 w-3">
                                                                </span>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>


                                                <!--                                {{hoteloptions}}-->
                                                <!--                                <img src="./dashboard_resources/edit.png" style="left: 290px; position: absolute; top: 58px; color: darkgrey; height: 18px; width: 30px;">-->

                                                <div class="row mt-4 mb-4">
                                                    <div class="col-12 text-center"><p class="text-dark">Room Type</p></div>
                                                    <div class="col-4 offset-4 mt-n3">
                                                        <input v-if="hotelselect[loc.id]" v-model="local_tour[index]['hotel']['roomtype']" class="text-center form-control">
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="col-5"  >
                                <div class="row">
                                    <div class="col-10 offset-1 text-left ">Special Instruction</div>
                                    <div class="col-10 text-left offset-1">
                                <textarea
                                    rows="3"
                                    v-model="local_tour[index]['specinst']"
                                    type="text"
                                    class="form-control">

                                </textarea>
                                    </div>

                                    <div class="col-10 offset-1 text-left mt-5">Meal Plan</div>
                                    <div class="col-10 text-left offset-1">
                                        <select v-model="local_tour[index]['mealplan']" class="form-control">
                                            <option value="MAP">MAP(with BF & D)</option>
                                            <option value="CP">CP(with BF)</option>
                                            <option value="AP">AP(All Meal)</option>
                                            <option value="EP">EP(No Meal)</option>
                                        </select>
                                    </div>

                                    <div class="col-10 offset-1 text-left mt-5">Voucher Number</div>
                                    <div class="col-10 text-left offset-1">

                                    <input type="text" v-model="local_tour[index]['voucher_number'] "   class="form-control">
                                    </div>
                                    <div class="col-10 offset-1 text-left mt-5">Hotel E-Mail</div>
                                    <div class="col-10 text-left offset-1">

                                        <input type="text" v-model="local_tour[index]['hotel_mail'] "   class="form-control">
                                    </div>
                                    <div class="col-10 offset-1 text-left mt-5">Amount Details</div>
                                    <div class="col-10 text-left offset-1">

                                        <input type="text" v-model="local_tour[index]['hotel_amount'] "   class="form-control">
                                    </div>


                                </div>
                            </div>




                        </div>
                    </div>

                </fieldset>
            </tab-content>
        </form-wizard>

    </div>
</template>


<script>
    import DaysPlaceComponent from '../cruds/daysplaces'
    //
    import {FormWizard, TabContent,WizardButton,WizardStep} from 'vue-form-wizard'
    import 'vue-form-wizard/dist/vue-form-wizard.min.css'
    export default{

        data(){
            return{
                tour:[],
                days:[],
                objj:{},
                temp:{},
                defaultt:[],
                localplace:{},
                hotelselect:{},
                hotelselect2:{},
                hoteloptions:{},
                non:[],
                non2:[],
                fs:false,
                fs1:true,
                flag:0,
                local_tour:{},
                hotelli:true,

                // tt:[{"id":1,"title":"ffhjhj"}]
            }

        },

        mounted(){

            this.local_tour=this.tour_location;
            for (var key in this.local_tour) {
                // this.local_tour[key]['hotel'] =this.local_tour[key]['hotel'];
                // this.local_tour[key]['hotel2']=this.local_tour[key]['hotel2'];

                // this.hotelselect[this.local_tour[key]['id']]=this.local_tour[key]['hotel']['hotel_data'];
                Object.assign(this.hotelselect[this.local_tour[key]['id']],this.local_tour[key]['hotel']['hotel_data']);
                // this.hotelselect[this.local_tour[key]['id']]={};
                // Object.assign(this.hotelselect[this.local_tour[key]['id']],{"hello":""});

                // this.hotelselect2[this.local_tour[key]['id']]=this.local_tour[key]['hotel2']['hotel_data'];
                Object.assign(this.hotelselect2[this.local_tour[key]['id']],this.local_tour[key]['hotel2']['hotel_data']);




            }



        },
        watch: {

            tour_location: {

                handler(newval, oldVal){
                    console.log("deepwatch");
                    console.log(newval);
                    this.local_tour=newval;
                    // console.log(this.local_tour);

                    for (var key in newval) {




                        if(this.local_tour[key]['specinst']=='' || typeof (this.local_tour[key]['specinst'])=="undefined"){
                            this.local_tour[key]['specinst'] ='';


                        }
                        if(this.local_tour[key]['mealplan']=='' || typeof (this.local_tour[key]['mealplan'])=="undefined"){
                            this.local_tour[key]['mealplan'] ='';


                        }

                        if(this.local_tour[key]['voucher_number']=='' || typeof (this.local_tour[key]['voucher_number'])=="undefined"){
                            this.local_tour[key]['voucher_number'] ='';


                        }
                        if(this.local_tour[key]['hotel_email']=='' || typeof (this.local_tour[key]['hotel_email'])=="undefined"){
                            this.local_tour[key]['hotel_email'] ='';


                        }
                        if(this.local_tour[key]['hotel_amount']=='' || typeof (this.local_tour[key]['hotel_amount'])=="undefined"){
                            this.local_tour[key]['hotel_amount'] ='';


                        }
                        Object.assign(this.hotelselect[this.local_tour[key]['id']],this.local_tour[key]['hotel']['hotel_data']);


                        Object.assign(this.hotelselect2[this.local_tour[key]['id']],this.local_tour[key]['hotel2']['hotel_data']);

                    }



                },
                deep: true


            },




            'hotels': function(newVal, oldVal) {
                // alert("f");
                console.log("watch");
                console.log('value changed from ' + oldVal + ' to ' + newVal);

                this.callhotel();



            },
            'location': function(newVal, oldVal) {
                // alert("f");
                console.log("watch");
                console.log('value changed from ' + oldVal + ' to ' + newVal);

                this.callhotel();
                this.hotelli='hotelli0';


            }




        },
        created(){


        },

        methods: {
            onCompletehotel(){
                this.$emit('showday')
            },

            changeview(index){

                var id=Number(index)+Number(1);

                $( "#hotel"+id ).show();
                this.hotelli="hotelli"+id;


                for( var i=0 ;i<this.location.length; i++){
                    if(i!==id){

                        $( "#hotel"+i ).hide();

                    }
                }
            },
            changeviewback(index){
                var id=Number(index)-Number(1);

                $( "#hotel"+id ).show();
                this.hotelli="hotelli"+id;

                for( var i=0 ;i<this.location.length; i++){
                    if(i!==id){

                        $( "#hotel"+i ).hide();

                    }
                }

            },
            changelevel(){

                this.$emit('showday');
            },
            run(){

                console.log(this.objj)
            },
            callhotel(){


                // alert("callhotel");
                if(!_.isEmpty(this.location) && !_.isEmpty(this.hotels)){
                    // alert("callhotel");
                    this.location.forEach( (dataObj) => {

                        // [(dataObj.id).split('-')[0]]
                        this.hotelset(dataObj.id,this.hotels[(dataObj.id.split('-')[0])]);
                    });
                    this.flag=1;
                }


            },
            hotelset(locationid,hotels){

                // alert("hotel set");
                console.log(locationid);
                console.log(hotels);


                if(this.hotelselect.hasOwnProperty(locationid)){

                }
                else{
                    // this.hotelselect[locationid]={};
                    Object.assign( this.hotelselect, {[locationid]: {title:''}})

                }
                if(this.hotelselect2.hasOwnProperty(locationid)){

                }
                else{

                    Object.assign( this.hotelselect2, {[locationid]: {title:''}})

                }



                if (!_.isEmpty(hotels) && typeof hotels !== 'undefined') {

                    console.log(hotels);
                    console.log("jjjj2");
                    var hot = _.cloneDeep(hotels);
                    //  this.hoteloptions={[locationid]:hot};
                    console.log(hot);

                    if(this.hoteloptions.hasOwnProperty(locationid)){

                        this.hoteloptions[locationid]=hot
                    }
                    else {
                        // this.hoteloptions[locationid]=hotels;
                        Object.assign( this.hoteloptions, {[locationid]: hot})
                    }



                }


                console.log(this.hoteloptions);
                console.log("iii2");
            },
            preselect(a,b,locationid,place){


                //         console.log(place);
                if(_.isEmpty(this.localplace) && typeof place !== 'undefined'){
                    // alert("test");
                    var pla=_.cloneDeep(place);
                    this.localplace[locationid]={[a]:pla};
                    //var arr=_.clone(place);
                    // this.localplace[locationid][a]=place;
                    console.log("cloned");
                    console.log(this.localplace);
                }
                else if(typeof place !== 'undefined' &&  _.isEmpty(this.localplace[locationid][a])){

                    var pla= _.cloneDeep(place);
                    this.localplace[locationid]={[a]:pla};
                }


                console.log("before me"+this.temp);
                console.log(this.temp);
//alert("me");

                if(_.isEmpty(this.objj)){
                    // alert("me empty");

                    this.days[a]=[{"id":1,
                        "title":"Day at Leisure",
                        "to_time":"",
                        "from_time":"",
                        "remark":""

                    }];
                    var day=a;

                    this.temp[locationid]={};

                    this.temp[locationid]['day-'+day]={'place':this.days[day]};
                    this.objj = Object.assign(this.objj, this.temp);
                    this.temp = Object.assign({}, {});
                    //this.days=[];
                    this.$emit('addplace',this.objj)
                }
                else {

                    var day=a;
//    alert("me empty2 ");
                    //   console.log(this.objj[locationid]);
                    if(_.isEmpty(this.objj[locationid]['day-'+day])){
                        this.days[a]=[{"id":1,
                            "title":"Day at Leisure",
                            "to_time":"",
                            "from_time":"",
                            "remark":""

                        }];
                        // alert("me not else in");
                        this.temp=Object.assign(this.temp,this.objj);
                        this.temp[locationid]['day-'+day]={'place':this.days[day]};
                        this.objj = Object.assign(this.objj, this.temp);
                        this.temp = Object.assign({}, {});
                        // this.days=[];
                        this.$emit('addplace',this.objj)
                    }
                    else {


                    }
                    console.log("else me"+this.temp);
                    console.log(this.temp);
                }

                return null;

            },
            remove(){
                //  alert('hello');
                this.$emit('delete', this.location.id)

            },

            addtohotel(index,location){




                if(this.hotelselect[location].new=='yes'){
                    let params = new FormData();

                        params.set('city_id', location.split('-')[0])
                    params.set('title', this.hotelselect[location].title)
                    params.set('new', 'yes')
                    axios.post('/api/v1/accommodations', params)
                        .then(response => {
                            // alert("yo")
                            // console.log(JSON.stringify(response.data.data));
                            this.hotelselect[location].id=response.data.data.id
                        })

                    this.local_tour[index]["hotel"]['hotel_data']=this.hotelselect[location];
            }
                else {
                    this.local_tour[index]["hotel"]['hotel_data']=this.hotelselect[location];
                }
                // this.$emit('refresh')

            },
            addtohotel2(index,location){



                if(this.hotelselect2[location].new=='yes'){
                    let params = new FormData();

                    params.set('city_id', location.split('-')[0])
                    params.set('title', this.hotelselect2[location].title)
                    params.set('new', 'yes')
                    axios.post('/api/v1/accommodations', params)
                        .then(response => {
                            // alert("yo")
                            // console.log(JSON.stringify(response.data.data));
                            this.hotelselect2[location].id=response.data.data.id
                        })

                    this.local_tour[index]["hotel2"]['hotel_data']=this.hotelselect2[location];
                }
                else {
                    this.local_tour[index]["hotel2"]['hotel_data'] = this.hotelselect2[location];
                }
                // this.$emit('refresh')

            },
            addtoplaces(day,locationid){


                if( this.objj.hasOwnProperty(locationid)){
                    // alert("up");
                    console.log(this.objj);
                    if(this.objj[locationid].hasOwnProperty('day-'+day)){

                        this.objj[locationid]['day-'+day].place=_.clone(this.days[day])


                        console.log(this.objj);
                    }
                    else{
                        // alert("in else");

                        Object.assign( this.objj[locationid], {['day-'+day]: {'place':_.clone(this.days[day])}})

                    }



                }
                else {

                    this.temp[locationid]={};

                    //  this.objj[locationid].push([day]);
                    this.temp[locationid]['day-'+day]={'place':_.clone(this.days[day])};


                    this.objj = Object.assign(this.objj, this.temp);

                    console.log(this.objj)


                }

                this.$emit('addplace',this.objj)
            }


        },
        components: {FormWizard,
            TabContent ,WizardButton,WizardStep},

        props: ['location','hotels','tour_location','day']

    }


</script>

<style scoped>
    #hotel_msform{
        width: 100px;
        margin: 50px auto;
        text-align: center;
        position: relative;
    }
    #hotel_msform fieldset {
        font-size: 16px;
        border: 0 none;
        border-radius: 3px;
        /*box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);*/
        padding: 20px 30px;
        /*box-sizing: border-box;*/
        width: 80%;
        margin: 0 10%;
        /*stacking fieldsets above each other*/
        position: absolute;
    }
    #hotel_msform fieldset:not(:first-of-type) {
        display: none;
    }
    #hotel_msform .action-button {
        width: 100px;
        background: #27AE60;
        font-weight: bold;
        color: white;
        border: 0 none;
        border-radius: 5px;
        cursor: pointer;
        padding: 10px 5px;
        margin: 10px 5px;
    }
    #hotel_progressbar {
        margin-bottom: 30px;
        overflow: hidden;
        /*CSS counters to number the steps*/
        counter-reset: step;
    }
    #hotel_progressbar li {
        list-style-type: block;
        color: white;
        text-transform: uppercase;
        font-size: 9px;
        width: 20.0%;
        float: left;
        position: relative;
    }
    #hotel_progressbar li:before {
        content: counter(step);
        counter-increment: step;
        width: 20px;
        line-height: 20px;
        display: block;
        font-size: 10px;
        color: #333;
        background: white;
        border-radius: 3px;
        margin: 0 auto 5px auto;
    }
    #hotel_progressbar li:after {
        content: '';
        width: 100%;
        height: 2px;
        background: white;
        position: absolute;
        left: -50%;
        top: 9px;
        color:black;
        z-index: -1; /*put it behind the numbers*/
    }
    #hotel_progressbar li:first-child:after {
        /*connector not needed before the first step*/
        content: none;
    }
    #hotel_progressbar li.active:before, #progressbar li.active:after {
        background: #27AE60;
        color: white;
    }
    #box {

        border-style: solid;
        border-width: 0 50px 50px 0;
        border-color: transparent #007bff transparent transparent;
    }
    #box2 {
        border-style: solid;
        border-width: 0 50px 50px 0;
        border-color: transparent #007bff transparent transparent;
    }

    .activedev{
        display: block !important;
    }
    .hidedev{
        display: none;
    }
</style>
<style>
    .wizard-card-footer.clearfix {
        top: 500px;
        position: fixed;
    }
    .vue-form-wizard.md .wizard-icon-circle {

        width: 30px;
        height: 30px;
        font-size: 14px;
        margin-top: 20px;

    }
    .bg-color{background-color: #1E51A4;
        border-radius: 0px 15px 15px 0px;}
</style>
