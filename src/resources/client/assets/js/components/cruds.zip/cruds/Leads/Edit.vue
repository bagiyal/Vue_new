<template>
    <section class="content-wrapper">
        <section class="content-header ml-5">
            <task-maker></task-maker>
            <h1>Lead: {{item.lead_id}}</h1>
        </section>

        <section class="content ml-5">
            <div class="row">
                <div class="col-xs-12">
                    <form @submit.prevent="submitForm" novalidate>
                        <div class="ml-5">
                            <!--                            <div class="box-header with-border">-->
                            <!--                                <h3 class="box-title">Edit</h3>-->
                            <!--                            </div>-->

                            <div class="box-body">
                                <back-buttton></back-buttton>
                            </div>

                            <bootstrap-alert />

                            <div class="ml-5">

                                <div class="container ml-5">
                                    <span class="h1"><img src="./../dashboard_resources/createitinerarydown.png" class="hw-4"><b>Edit Lead</b></span>

                                    <div v-if="item.lead_status==1" class="btn-group float-right">
                                        <button @click="marklost" class="btn btn-dark btn-lg pl-5 pr-5 ml-3 mr-5">Mark As Lost</button>
                                    </div>
                                    <div v-if="item.lead_status==3" class="btn-group float-right">
                                        <button disabled class="btn btn-dark btn-lg pl-5 pr-5 ml-3 mr-5">Lead Lost</button>
                                    </div>
                                    <div v-if="item.lead_status==1 || item.lead_status==2"  class="float-right">  <router-link
                                        :to="{ name: 'queries.create',params:{'lead_data':item ,'lead_meta':meta } }"

                                        class="btn btn-success btn-lg"
                                    >
                                        <i class="fa fa-plus"></i> Generate Query
                                    </router-link></div>

                                    <div class="row mt-5">
                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Tentative Date</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><i class="fa fa-calendar"></i></span>
                                                    <date-picker
                                                        :value="item.date"
                                                        :config="$root.dpconfigDate"
                                                        name="date"
                                                        placeholder="Enter Date"
                                                        @dp-change="updateDate"
                                                        class="input-field"
                                                    >
                                                    </date-picker></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Traveller Name</span></div>
                                                <div class="col-lg-12" ><span class="icon-style"><i class="fas fa-user"></i></span><input
                                                    type="text"
                                                    class="form-control"
                                                    name="name"
                                                    placeholder="Enter Name"
                                                    :value="item.name"
                                                    @input="updateName"
                                                    disabled
                                                ></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Email</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><i class="fa fa-envelope"></i></span><input
                                                    type="email"
                                                    class="form-control"
                                                    name="email"
                                                    placeholder="Enter Email"
                                                    :value="item.email"
                                                    @input="updateEmail"

                                                ></div>
                                            </div>
                                            <div class="row mt-5">

                                                <div class="col-lg-12"><label for="lead_id1" class="h2 fw-4 text-muted ml-3">Source Lead</label>
                                                    <span class="img-style"><img src="./../dashboard_resources/leadsource.png" class="hw-2 mt-2"></span>
                                                    <select
                                                        class="form-control lead-select"
                                                        name="lead_id1"
                                                        :value="item.source"
                                                        @input="updateSource"
                                                    ><option value="Adwords">Adwords</option>
                                                        <option selected value="Social Media">Social Media</option>

                                                        <option value="Offline Purchase">Offline Purchase</option>
                                                        <option value="Repeat">Repeat</option>
                                                        <option value="Referred">Referred</option>
                                                        <option value="Website">Website</option>
                                                        <option value="Walk In">Walk In</option>
                                                        <option value="Phone Call">Phone Call</option>
                                                        <option value="Corporate">Corporate</option>
                                                        <option value="Sales Team">Sales Team</option>
                                                        <option value="Others">Others</option>
                                                    </select></div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6">
                                            <div class="row">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Sector</span></div>
                                                <div class="col-lg-12" ><span class="icon-style"><img src="./../dashboard_resources/loction.png" class="hw-i"></span> <input
                                                    type="text"
                                                    class="form-control"
                                                    name="package_type"
                                                    placeholder="Enter Package type"
                                                    :value="item.package_type"
                                                    @input="updatePackage_type"

                                                ></div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Mobile Number</span></div>
                                                <div class="col-lg-12" ><span class="icon-style"><img src="./../dashboard_resources/contact.png" class="hw-i"></span>

                                                    <!--                                                    <vue-tel-input style="width: 122%;border:0;height: 83%" v-model="item.phone" @input="updatePhone" v-bind="bindProps" class="form-control" name="phone" placeholder="Enter Phone"></vue-tel-input>-->


                                                    <input
                                                        type="text"
                                                        class="form-control"
                                                        name="phone"
                                                        placeholder="Enter Phone"
                                                        :value="item.phone"
                                                        @input="updatePhone"

                                                    >

                                                </div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Traveller</span></div>
                                                <div class="col-lg-12"><span class="icon-style"><img src="./../dashboard_resources/traveller.png" class="hw-2"></span>
                                                    <input readonly class="form-control quantity" @click="pop == true?pop=false:pop=true" id="sum" :value="total_trav" type="text"  >
                                                    <div class="container">

                                                        <div class="modal" id="myModal">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">

                                                                    <!-- Modal Header -->


                                                                    <!-- Modal body -->
                                                                    <div class="modal-body">
                                                                        <button type="button" class="close" data-dismiss="modal">&times;</button><br>
                                                                        <div class="container">
                                                                            <div class="row text-center pt-2 pb-2" style="">
                                                                                <div class="col-lg-4">
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                            <p class="h3 fw-4 text-muted">Adults</p>
                                                                                        </div>
                                                                                        <div class="col-12" style="">
                                                                                            <p class="fw-4 text-muted h5">(12+ yrs)</p>
                                                                                        </div>
                                                                                        <div class="col-lg-12" style="">
                                                                                            <vue-numeric-input id="adult" v-model="item.adult_guest"

                                                                                                               :min="1"
                                                                                                               :step="1"></vue-numeric-input>
                                                                                            <!--                                                                                        <input type="number" id="adult" class="form-control" min="1"-->
                                                                                            <!--                                                                                              -->
                                                                                            <!--                                                                                        >-->
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-lg-4">
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                            <p class="h3 fw-4 text-muted">Children</p>
                                                                                        </div>
                                                                                        <div class="col-12" style="">
                                                                                            <p class="h5 fw-4 text-muted">(2-12 yrs)</p>
                                                                                        </div>
                                                                                        <div class="col-12" style="">
                                                                                            <vue-numeric-input id="child" v-model="item.kids_guests"

                                                                                                               :min="0"
                                                                                                               :step="1"></vue-numeric-input>
                                                                                            <!--                                                                                        <input type="number" id="child" min="0" style="width: 50px;height: 25px;border: 1px solid darkgrey;border-radius: 3px;" value="0"  placeholder="0"-->
                                                                                            <!--                                                                                               -->
                                                                                            <!--                                                                                        >-->
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="col-lg-4">
                                                                                    <div class="row">
                                                                                        <div class="col-12">
                                                                                            <p class="h3 fw-4 text-muted">Infant</p>
                                                                                        </div>
                                                                                        <div class="col-12" style="">
                                                                                            <p class="h5 fw-4 text-muted">(below 2yrs)</p>
                                                                                        </div>
                                                                                        <div class="col-12" style="">
                                                                                            <vue-numeric-input id="infant" v-model="item.infant_guest"

                                                                                                               :min="0"
                                                                                                               :step="1"></vue-numeric-input>
                                                                                            <!--                                                                                        <input type="number" id="infant" min="0" style="width: 50px;height: 25px;border: 1px solid darkgrey;border-radius: 3px;" placeholder="0"-->
                                                                                            <!--                                                                                               -->
                                                                                            <!--                                                                                        >-->
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>

                                                                    <!-- Modal footer -->

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mt-5">
                                                <div class="col-lg-12"><span class="h2 fw-4 text-muted ml-3">Past Interactions</span></div>
                                                <div class="col-lg-9 div-dec" v-for="(rem,index) in item.remark " v-if="index==(item.remark.length)-1">
                                                    <!--                                                   {{rem,index}}-->
                                                    <div class="row">
                                                        <div class="col-lg-5">
                                                            <p class="spe-border pl-1 text-danger mt-1" ><i class="far fa-clock pr-1"></i>{{ rem['time'] | moment}}</p>
                                                            <p class="border-left-3 ml-2">{{rem['remark'].substring(0,40)+".."}}</p>
                                                        </div>
                                                        <div class="col-lg-7 text-right"><img data-toggle="modal" data-target="#Modal" src="./../dashboard_resources/dropdown.png" class="hw-2"></div>
                                                    </div>
                                                </div>

                                            </div>
                                            <div class="container">

                                                <div class="modal" id="Modal">
                                                    <div class="modal-dialog">
                                                        <div class="modal-content">

                                                            <!-- Modal Header -->


                                                            <!-- Modal body -->
                                                            <div class="modal-body">
                                                                <button type="button" class="close" data-dismiss="modal">&times;</button><br>
                                                                <div class="container">
                                                                    <div v-for="rem in item.remark " class="h3 fw-5">
                                                                        <span class="text-success"><i class="far fa-clock mr-2 text-success"></i>{{ rem['time'] | moment}}
                                                                        |    Agent: {{rem['agent']}}</span>
                                                                        <p class="border-left-3 ml-3 mt-1 pl-1">{{rem['remark']}}</p>
                                                                    </div>
                                                                </div>
                                                            </div>

                                                            <!-- Modal footer -->

                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <!--                                            <div :class="[remarkk ? 'activedev' : 'hidedev' ]" class="col-12" style="position: relative;">-->
                                            <!--                                                <div style="overflow-x: hidden;background-color: white;position: absolute;width: 600px;height: 250px;border: solid gainsboro 1px;border-radius: 10px;left: -220px;top: -60px;font-size: 16px;z-index: 1">-->
                                            <!--                                                    <div v-for="rem in item.remark " style="width: 570px;color:forestgreen;margin-left: 20px;margin-top: 20px">-->
                                            <!--                                                        -->
                                            <!--                                                        <i class="far fa-clock" style="margin-right: 10px"></i>{{ rem['time'] | moment}}-->
                                            <!--                                                        <span style="">|    Agent: {{rem['agent']}}</span>-->
                                            <!--                                                        <p style="text-align:justify-all;width: 580px;height: 40px;border-left:solid black 3px;margin-left: 6px;padding-left: 5px;font-size: 12px;color:black;margin-top: 5px ">{{rem['remark']}}</p>-->
                                            <!--                                                    </div>-->
                                            <!--                                                    <div style="width: 570px;color:red;margin-left: 20px;margin-top:-10px"><i class="far fa-clock" style="margin-right: 10px"></i>05-09-2019 / 02:15 pm <span style="margin-left: 205px">Due Date : 10-09-2019</span>-->
                                            <!--                                                        <p style="text-align:justify-all;width: 580px;height: 40px;border-left:solid black 3px;margin-left: 6px;padding-left: 5px;font-size: 12px;color:black;margin-top: 5px ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>-->
                                            <!--                                                    </div>-->
                                            <!--                                                    <div style="width: 570px;color:dodgerblue;margin-left: 20px;margin-top:-10px"><i class="far fa-clock" style="margin-right: 10px"></i>05-09-2019 / 02:15 pm <span style="margin-left: 295px">On Going</span>-->
                                            <!--                                                        <p style="text-align:justify-all;width: 580px;height: 40px;border-left:solid black 3px;margin-left: 6px;padding-left: 5px;font-size: 12px;color:black;margin-top: 5px ">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,</p>-->
                                            <!--                                                    </div>-->
                                            <!--                                                </div>-->
                                            <!--                                            </div>-->

                                            <div class="row pt-2">
                                                <div class="col-lg-12"><span style="margin-left: 5px;color:grey;font-size:20px;margin-left: 10px">Remark</span></div>
                                                <div class="col-lg-8" style="margin-left: 6px;position: relative"><span style="position: absolute; left: 7%; color: grey; top: 10%; font-size: 18px;"><i class="fa fa-pencil-square-o"></i></span>
                                                    <input type="text" class="form-control"
                                                           name="remark"
                                                           placeholder="Enter Remark"
                                                           v-model="newremark"

                                                           style="width:106%"
                                                    >
                                                </div>
                                                <div class="col-lg-2">

                                                    <input type="button" value="Add" @click="updateRemark(newremark)" class="vue-btn btn btn-primary text-light" style="font-size: 18px; /*! margin-left: -8%; */">

                                                    <!--                                                        <i aria-hidden="true" class="fa fa-paper-plane"></i>-->



                                                </div>
                                            </div>
                                        </div>
                                    </div><br>
                                    <input v-if="!item.agent_id" type="checkbox" v-model="selfass" style="margin-left: -38.5%"><span v-if="!item.agent_id" style="color:grey;font-weight: bold;margin-left: -38.5%">Self Assign</span>
                                    <div class="row">
                                        <div class="col-lg-12 text-center">
                                            <!--                                            <button class="btn btn-primary text-light"><i class="fa fa-paper-plane" aria-hidden="true"></i>Submit</button>-->


                                            <vue-button-spinner
                                                class="btn btn-primary text-light"
                                                :isLoading="loading"
                                                :disabled="loading"
                                                style="font-size: 18px;margin-left:-8%"
                                            >
                                                <i class="fa fa-paper-plane" aria-hidden="true"></i>Submit
                                            </vue-button-spinner>
                                        </div>
                                    </div>
                                </div>

                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="lead_id">Lead id *</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="lead_id"-->
                                <!--                                            placeholder="Enter Lead id *"-->
                                <!--                                            :value="item.lead_id"-->
                                <!--                                            @input="updateLead_id"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="lead_status">Lead status</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="lead_status"-->
                                <!--                                            placeholder="Enter Lead status"-->
                                <!--                                            :value="item.lead_status"-->
                                <!--                                            @input="updateLead_status"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="package_type">Package type</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="package_type"-->
                                <!--                                            placeholder="Enter Package type"-->
                                <!--                                            :value="item.package_type"-->
                                <!--                                            @input="updatePackage_type"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="date">Date</label>-->
                                <!--                                    <date-picker-->
                                <!--                                            :value="item.date"-->
                                <!--                                            :config="$root.dpconfigDate"-->
                                <!--                                            name="date"-->
                                <!--                                            placeholder="Enter Date"-->
                                <!--                                            @dp-change="updateDate"-->
                                <!--                                            >-->
                                <!--                                    </date-picker>-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="email">Email</label>-->
                                <!--                                    <input-->
                                <!--                                            type="email"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="email"-->
                                <!--                                            placeholder="Enter Email"-->
                                <!--                                            :value="item.email"-->
                                <!--                                            @input="updateEmail"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="phone">Phone</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="phone"-->
                                <!--                                            placeholder="Enter Phone"-->
                                <!--                                            :value="item.phone"-->
                                <!--                                            @input="updatePhone"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="name">Name</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="name"-->
                                <!--                                            placeholder="Enter Name"-->
                                <!--                                            :value="item.name"-->
                                <!--                                            @input="updateName"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="adult_guest">Adult guest</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="adult_guest"-->
                                <!--                                            placeholder="Enter Adult guest"-->
                                <!--                                            :value="item.adult_guest"-->
                                <!--                                            @input="updateAdult_guest"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="score">Score</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="score"-->
                                <!--                                            placeholder="Enter Score"-->
                                <!--                                            :value="item.score"-->
                                <!--                                            @input="updateScore"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="kids_guests">Kids guests</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="kids_guests"-->
                                <!--                                            placeholder="Enter Kids guests"-->
                                <!--                                            :value="item.kids_guests"-->
                                <!--                                            @input="updateKids_guests"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="agent_id">Agent id</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="agent_id"-->
                                <!--                                            placeholder="Enter Agent id"-->
                                <!--                                            :value="item.agent_id"-->
                                <!--                                            @input="updateAgent_id"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="agency_id">Agency id</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="agency_id"-->
                                <!--                                            placeholder="Enter Agency id"-->
                                <!--                                            :value="item.agency_id"-->
                                <!--                                            @input="updateAgency_id"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="score_new">Score new</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="score_new"-->
                                <!--                                            placeholder="Enter Score new"-->
                                <!--                                            :value="item.score_new"-->
                                <!--                                            @input="updateScore_new"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="lead_feel">Lead feel</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="lead_feel"-->
                                <!--                                            placeholder="Enter Lead feel"-->
                                <!--                                            :value="item.lead_feel"-->
                                <!--                                            @input="updateLead_feel"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="remark">Remark</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="remark"-->
                                <!--                                            placeholder="Enter Remark"-->
                                <!--                                            :value="item.remark"-->
                                <!--                                            @input="updateRemark"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="source">Source</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="source"-->
                                <!--                                            placeholder="Enter Source"-->
                                <!--                                            :value="item.source"-->
                                <!--                                            @input="updateSource"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                                <!--                                <div class="form-group">-->
                                <!--                                    <label for="infant_guest">Infant guest</label>-->
                                <!--                                    <input-->
                                <!--                                            type="text"-->
                                <!--                                            class="form-control"-->
                                <!--                                            name="infant_guest"-->
                                <!--                                            placeholder="Enter Infant guest"-->
                                <!--                                            :value="item.infant_guest"-->
                                <!--                                            @input="updateInfant_guest"-->
                                <!--                                            >-->
                                <!--                                </div>-->
                            </div>

                            <!--                            <div class="box-footer">-->
                            <!--                                <vue-button-spinner-->
                            <!--                                        class="btn btn-primary btn-sm"-->
                            <!--                                        :isLoading="loading"-->
                            <!--                                        :disabled="loading"-->
                            <!--                                        >-->
                            <!--                                    Save-->
                            <!--                                </vue-button-spinner>-->
                            <!--                            </div>-->
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</template>


<script>
    // import moment from 'moment'
    // import VueMoment from 'vue-moment'
    import moment from 'moment-timezone'
    $("#sum").click(function () {

        var a_num = $("#adult").val();
        var c_num = $("#child").val();
        var inf_num=$("#infant").val();
        var total = parseInt(a_num) + parseInt(c_num)+ parseInt(inf_num);
        if(c_num==0 && inf_num==0){ total = a_num}
        if(inf_num==0){total= parseInt(a_num)+ parseInt(c_num)}
        $("#sum").val(total);

    });
    function popupfunction() {
        var x = document.getElementById("popup");
        if (x.style.display === "block") {
            x.style.display = "none";
        } else {
            x.style.display = "block";
        }
    }
    import { mapGetters, mapActions } from 'vuex'
    import { VueTelInput } from 'vue-tel-input'
    export default {
        data() {
            return {
                // Code...
                selfass:false,
                submit:true,
                currentDate:null,
                total_trav:1,
                pop:false,
                remarkk: false,
                newremark:'',
                bindProps: {
                    mode: "international",
                    defaultCountry: "INR",
                    disabledFetchingCountry: false,
                    disabled: false,
                    disabledFormatting: false,
                    placeholder: "Enter a phone number",
                    required: false,
                    enabledCountryCode: false,
                    enabledFlags: true,
                    preferredCountries: ["AU", "BR"],
                    onlyCountries: [],
                    ignoredCountries: [],
                    autocomplete: "off",
                    name: "telephone",
                    maxLen: 25,
                    wrapperClasses: "",
                    inputClasses: "",
                    dropdownOptions: {
                        disabledDialCode: true
                    },
                },
            }
        },

        filters: {
            moment: function (value) {
                if (value) {
                    return moment.unix(value).format("MM-DD-YYYY / h:mm a")
                }
            }
        },
        computed: {
            ...mapGetters('LeadsSingle', ['item','meta', 'loading']),
        },
        created() {
            this.fetchData(this.$route.params.id)



        },

        destroyed() {
            this.resetState()
        },
        watch: {
            "item.lead_id": function() {
                this.$root.booking_ref_id={'booking_id':this.item.lead_id,'id':this.item.id}
            },
            "$route.params.id": function() {
                this.resetState()
                this.fetchData(this.$route.params.id)
            },
            "item.adult_guest": function() {
                this.total_trav=  Number(this.item.adult_guest)+  Number(this.item.kids_guests)+  Number(this.item.infant_guest);

            },
            "selfass": {

                handler(newval, oldVal){

                    if(newval==true){
                        console.log("if");
                        this.item.created_by=1
                        this.item.created_by_id=1

                    }
                    else {
                        console.log("else");
                        this.item.created_by=''
                        this.item.created_by_id=''
                    }


                },
                deep: true


            },
        },
        methods: {
            ...mapActions('LeadsSingle', ['fetchData', 'updateData', 'resetState', 'setLead_id', 'setLead_status', 'setPackage_type', 'setDate', 'setEmail', 'setPhone', 'setName', 'setAdult_guest', 'setScore', 'setKids_guests', 'setAgent_id', 'setAgency_id', 'setScore_new', 'setLead_feel', 'setRemark', 'setSource', 'setInfant_guest','setRemarkedit']),
            marklost(){
                this.setLead_status(3);
                this.updateData()


            },
            updateLead_id(e) {
                this.setLead_id(e.target.value)
            },
            updateLead_status(e) {
                this.setLead_status(e.target.value)
            },
            updatePackage_type(e) {
                this.setPackage_type(e.target.value)
            },
            updateDate(e) {
                this.setDate(e.target.value)
            },
            updateEmail(e) {
                this.setEmail(e.target.value)
            },
            updatePhone(e) {
                this.setPhone(e.target.value)
            },
            updateName(e) {
                this.setName(e.target.value)
            },

            updateScore(e) {
                this.setScore(e.target.value)
            },

            updateAgent_id(e) {
                this.setAgent_id(e.target.value)
            },
            updateAgency_id(e) {
                this.setAgency_id(e.target.value)
            },
            updateScore_new(e) {
                this.setScore_new(e.target.value)
            },
            updateLead_feel(e) {
                this.setLead_feel(e.target.value)
            },
            updateRemark(e) {
                if(this.newremark!=''){
                    var any= _.cloneDeep(this.newremark);
                    this.setRemark(any)
                    this.newremark=''
                }
            },
            updateSource(e) {
                this.setSource(e.target.value)
            },
            updateAdult_guest(e) {
                this.setAdult_guest(e.target.value);
                this.total_trav= Number(this.item.adult_guest)+ Number(this.item.kids_guests)+ Number(this.item.infant_guest);
            },
            updateKids_guests(e) {
                this.setKids_guests(e.target.value);
                this.total_trav=  Number(this.item.adult_guest)+  Number(this.item.kids_guests)+  Number(this.item.infant_guest);
            },
            updateInfant_guest(e) {
                this.setInfant_guest(e.target.value);
                this.total_trav=  Number(this.item.adult_guest)+  Number(this.item.kids_guests)+  Number(this.item.infant_guest);
            },
            submitForm() {
                this.submit=false;
                let trav = new FormData();
                this.item.agent_id=document.querySelector("meta[name='user-id']").getAttribute('content');
                trav.set("name",this.item.name)
                trav.set("email",this.item.email)
                trav.set("phone",this.item.phone)
                trav.set("type","lead")
                axios.post('/api/v1/travellers', trav)
                    .then(response => {
                        console.log(response)
                        console.log(response.data.status)

                        if(response.data.status=='error'){
                            this.submit=true;
                            alert(response.data.type);
                        }

                        else {

                            this.updateData()
                                .then(() => {
                                    this.$router.push({ name: 'leads.index' })
                                    this.$eventHub.$emit('update-success')
                                })
                                .catch((error) => {
                                    this.submit=true;
                                    console.error(error)
                                })

                        }

                    })
                    .catch(error => {
                        this.submit=true;
                        alert("error");
                    })


            }
        },
        components:{
            moment,VueTelInput

        }

    }
</script>


<style scoped>

    .activedev{
        display: block;
    }
    .hidedev{
        display: none;
    }
    input{
        margin-left: 2%; padding-left: 8%; width: 80%;
    }
    .dropbtn {

        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
    }
    .changecolor:hover{background-color:white;border-bottom-left-radius: 5px }
    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropdown-content {display:none;
        top:0px;
        right:-70px;
        position: absolute;

        min-width: 50px;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        z-index: 1;
    }
    .icon {
        color: darkgrey;
        text-align: center;

    }
    .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        width: 70px;
    }



    .dropdown:hover .dropdown-content {display: block;}
    .sidebar{
        float: left;
        box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
        text-align: left;
        height: 100%;
        width: 20%;
        padding-bottom: 200px;
        /*margin-top: -10px;*/


    }
    .sidebar a{
        text-decoration: none;
        color:black;
        display: grid;
        text-align: left;
        padding: 10px 10px 10px 10px;
        border-collapse: solid black 1px;
    }
    .sidebar a:hover{
        background-color: #2751A4;
        padding-left: 20px;
        color: white;
        display: grid;

    }
    .sidebar li{list-style: none;}
    #align{
        text-align: left;
        margin-left:-40px; margin-right:10px;
    }
    .onhover a{color:grey; font-size: 13px;}
    .onhover a:hover{background-color: #2751A4; border-radius:20px; color: white;}
    .navpad li a{ padding-left: 70px; }
    .quantity::-webkit-inner-spin-button,
    .quantity::-webkit-outer-spin-button {
        -webkit-appearance: none;
        margin: 0;
    }
</style>
<style>
    input.changesize{
        width:50px;
        height:50px;
    }
</style>
