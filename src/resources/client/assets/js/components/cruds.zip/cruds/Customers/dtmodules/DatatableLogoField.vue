<template>
    <div v-html="row.logo_link"></div>
</template>


<script>
    export default {
        props: ['row'],
    }
</script>
