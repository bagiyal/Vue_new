<template>
    <section class="content-wrapper" style="margin-left: 5% !important;min-height: 960px;">
        <section class="content-header">
            <h1>Guide</h1>
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-body">
                            I'm custom component.
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </section>
</template>

<script>
export default {
    data() {
        return {
            // Code...
        }
    },
    computed: {
        // Code...
    },
    created() {
        // Code...
    },
    destroyed() {
        // Code...
    },
    methods: {
        // Code...
    }
}
</script>


<style scoped>

</style>
