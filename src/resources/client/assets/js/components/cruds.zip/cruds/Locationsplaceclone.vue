<template>
    <li style=" list-style-type: none;">


        <div  class="row ml-0 mr-0 pb-3" style="width: 120%;border-radius:5px" :id="location.id">

            <div  class="col-lg-3">
                <div  class="row pt-1">
                    <div  class="col-12">
                        <label  style="margin-left: -26%;margin-top:5%;font-size: 18px; font-weight: normal;color:grey">Location {{Number(index)+Number(1)}}
                            <img  src="./dashboard_resources/loction.png" height="25px" style="margin-top: -5%;">
                        </label>
                    </div>
                    <div  class="col-12" style="margin-left: -14.5%;">
                        <label  style="font-size: 18px; font-weight: normal; color:grey"> {{location.name}}</label>


                    </div>
                </div>
            </div>

            <div  class="col-lg-4 pl-5">
                <div  class="row">
                    <div  class="col-12">
                        <label  style="margin-left: 11%;font-size: 18px;font-weight: normal;margin-top: 5%;color:grey">Hotel
                            <img  src="./dashboard_resources/hotel.png" height="25px" style="padding-left: 3px;">
                        </label>
                    </div>
                    <div  class="col-12" style="">

                        <v-select  :clearable="false" :taggable="true" v-model="hotelselect[location.id]"
                                   :name="index"
                                   label="title"
                                   @input="addtohotel(index,location.id,location.name)"
                                   :value="non"
                                   :options=hoteloptions[location.id]
                                   :create-option="hotel => ({ title: hotel,id:'',check_in_time:'', check_out_time:'', featured_image_link:'',new:'yes' })"
                                   style="border: 0px; font-size: 14px; font-weight: normal;"  />

                        <v-select v-if="!$route.path.includes('booking')" :clearable="false" :taggable="true" v-model="hotelselect2[location.id]"
                                  :name="location.id"
                                  label="title"
                                  @input="addtohotel2(index,location.id,location.name)"
                                  :value="non2"
                                  :options=hoteloptions[location.id]
                                  :create-option="hotel => ({ title: hotel,id:'',check_in_time:'', check_out_time:'', featured_image_link:'',new:'yes' })"
                                  style="border: 0px; font-size: 14px; font-weight: normal;margin-top: 10px;"   />

                    </div>
                </div>
            </div>

            <div  class="col-lg-4" style="">
                <div  class="row">
                    <div  class="col-lg-12">
                        <label  style=" font-size: 18px; font-weight: normal;width: 32%;margin-top: 5%;color:grey">Nights
                            <img  src="./dashboard_resources/night.png" height="25px" style="position: absolute;">
                        </label>
                    </div>
                    <div  class="col-lg-12" style="margin-left: 76%">
                        <div  class="row">


                            <div class="col-lg-10 mr-4">
                                <input type="number" min="1" id="myNumber" v-model="location.days" style="width: 28%; height: 100%; margin-left: -54%; border: 1px solid gainsboro; float: left;border-radius: 5px;text-align: center;">
                                <img src="./dashboard_resources/minus.png" @click="location.days>1?location.days-- :''" style="margin-left: -62%; height: 95%; width: 18%;">
                                <img src="./dashboard_resources/plus.png" @click="location.days++" style="height: 95%;width: 18%;">
                                <img @click="remove" src="./dashboard_resources/minus.png" style="margin-left: 25%; height: 95%; width: 18%;">
                            </div>


                        </div>
                    </div>
                </div>
            </div>



        </div>


    </li>

    <!--@click="remove"-->
</template>


<script>
    import DaysPlaceComponent from '../cruds/daysplaces'

    export default{

        data(){
            return{
                // redeleteflag:false,
                tour:[],
                days:[],
                objj:{},
                temp:{},
                defaultt:[],
                localplace:{},
                hotelselect:{},
                hotelselect2:{},
                hoteloptions:{},
                non:[],
                non2:[],
                local_tour:{},
                // tt:[{"id":1,"title":"ffhjhj"}]
            }

        },


        mounted(){

            if(this.redeleteflag){
                this.local_tour=this.tour_location;

                for (var key in this.local_tour) {

                    this.local_tour[key]['hotel'] ={'hotel_data':'','checkin':'','checkout':'','roomtype':''};
                    this.local_tour[key]['hotel2'] = {'hotel_data':'','checkin':'','checkout':'','roomtype':''};
                    this.local_tour[key]['specinst'] ='';
                    this.local_tour[key]['mealplan'] ='';



                }
            }
            else {

                this.local_tour=this.tour_location;

                for (var key in this.local_tour) {


                    this.hotelselect[this.local_tour[key]['id']]={};
                    Object.assign(this.hotelselect[this.local_tour[key]['id']], this.local_tour[key]['hotel']['hotel_data']);



                    this.hotelselect2[this.local_tour[key]['id']]={};
                    Object.assign(this.hotelselect2[this.local_tour[key]['id']], this.local_tour[key]['hotel2']['hotel_data']);





                }
            }






            this.defaultt.push({"id":1,
                "title":"Day at Leisure",
                "to_time":"",
                "from_time":"",
                "remark":""

            });




        },
        watch: {
            'hotels': function(newVal, oldVal) {
                console.log("watch");
                console.log('value changed from ' + oldVal + ' to ' + newVal);
                this.hotelset(this.location.id,this.hotels);
            },
            'tour_location': function(newVal, oldVal) {


                if(this.redeleteflag){
                    this.local_tour=this.tour_location;

                    for (var key in this.local_tour) {

                        this.local_tour[key]['hotel'] ={'hotel_data':'','checkin':'','checkout':'','roomtype':''};
                        this.local_tour[key]['hotel2'] = {'hotel_data':'','checkin':'','checkout':'','roomtype':''};
                        this.local_tour[key]['specinst'] ='';
                        this.local_tour[key]['mealplan'] ='';



                    }
                }else {
                    this.local_tour=newVal;
                    for (var key in this.local_tour) {


                        Object.assign(this.hotelselect[this.local_tour[key]['id']], this.local_tour[key]['hotel']['hotel_data']);




                        Object.assign(this.hotelselect2[this.local_tour[key]['id']],this.local_tour[key]['hotel2']['hotel_data']);







                    }

                }


            },
            'location.days': function(newVal, oldVal) {
                console.log("watch");
                console.log('value changed from ' + oldVal + ' to ' + newVal);
                this.location.daynights=parseInt(this.location.days) +1
            },

        },
        created(){


        },

        methods: {
            run(){

                // console.log(this.objj)
            },
            hotelset(locationid,hotels){

                // alert("hotel set");
                console.log(locationid);
                console.log(hotels);
                if(this.hotelselect.hasOwnProperty(locationid)){

                }
                else{
                    // this.hotelselect[locationid]={};
                    Object.assign( this.hotelselect, {[locationid]: {}})

                }
                if(this.hotelselect2.hasOwnProperty(locationid)){

                }
                else{

                    Object.assign( this.hotelselect2, {[locationid]: {}})

                }



                if (!_.isEmpty(hotels) && typeof hotels !== 'undefined') {

                    console.log(hotels);
                    console.log("jjjj2");
                    var hot = _.cloneDeep(hotels);
                    //  this.hoteloptions={[locationid]:hot};
                    console.log(hot);

                    if(this.hoteloptions.hasOwnProperty(locationid)){

                        this.hoteloptions[locationid]=hot
                    }
                    else {
                        // this.hoteloptions[locationid]=hotels;
                        Object.assign( this.hoteloptions, {[locationid]: hot})
                    }



                }


            },

            remove(){
                // alert('hello');

                this.$emit('delete', this.location.id)


            },
            // setday(day)
            // {
            //     this.days=day
            //     console.log(this.days)
            // },
            addtohotel(index,location,locname){

                if(this.hotelselect[location].new=='yes'){
                    var googleurl='';

                    axios.get('/api/webservices/fetch_image/?title='+ this.hotelselect[location].title+','+locname)
                        .then(response => {
                            googleurl=response.data;

                            let params = new FormData();
//
                            if(googleurl.length>20){
                                params.set('featured_image_url', googleurl)
                            }

                    params.set('city_id', location.split('-')[0])
                    params.set('title', this.hotelselect[location].title)
                    params.set('new', 'yes')
                    axios.post('/api/v1/accommodations', params)
                        .then(response => {
                            // alert("yo")
                            // console.log(JSON.stringify(response.data.data));
                            this.hotelselect[location].id=response.data.data.id
                        })
                        });
                    this.local_tour[index]["hotel"]['hotel_data']=this.hotelselect[location];
                }
                else {
                    this.local_tour[index]["hotel"]['hotel_data']=this.hotelselect[location];
                }

                Object.assign(this.tour_location[index],this.local_tour[index]);


            },
            addtohotel2(index,location,locname){

                if(this.hotelselect2[location].new=='yes'){

                    var googleurl='';

                    axios.get('/api/webservices/fetch_image/?title='+ this.hotelselect2[location].title+','+locname)
                        .then(response => {
                            googleurl=response.data;

                            let params = new FormData();
//
                            if(googleurl.length>20){
                                params.set('featured_image_url', googleurl)
                            }

                    params.set('city_id', location.split('-')[0])
                    params.set('title', this.hotelselect2[location].title)
                    params.set('new', 'yes')
                    axios.post('/api/v1/accommodations', params)
                        .then(response => {
                            // alert("yo")
                            // console.log(JSON.stringify(response.data.data));
                            this.hotelselect2[location].id=response.data.data.id
                        })
                        });
                    this.local_tour[index]["hotel2"]['hotel_data']=this.hotelselect2[location];
                }
                else {
                    this.local_tour[index]["hotel2"]['hotel_data'] = this.hotelselect2[location];
                }
                Object.assign(this.tour_location[index], this.local_tour[index]);


            },
            addtoplaces(day,locationid){

                if( this.objj.hasOwnProperty(locationid)){
                    // alert("up");
                    console.log(this.objj);
                    if(this.objj[locationid].hasOwnProperty('day-'+day)){

                        this.objj[locationid]['day-'+day].place=_.clone(this.days[day])

                        console.log(this.objj);
                    }
                    else{


                        Object.assign( this.objj[locationid], {['day-'+day]: {'place':_.clone(this.days[day])}})

                    }


                    // this.objj[locationid].push(obj)

                }
                else {

                    this.temp[locationid]={};

                    //  this.objj[locationid].push([day]);
                    this.temp[locationid]['day-'+day]={'place':_.clone(this.days[day])};


                    this.objj = Object.assign(this.objj, this.temp);
                    //this.objj[locationid][day]=[];
                    //   this.objj[locationid][day].place.push(this.days[day])
                    console.log(this.objj)


                }

                //      console.log(this.objj)
                this.$emit('addplace',this.objj)
            }

        },
        // components: {DaysPlaceComponent},

        props: ['location','place','hotels','index','tour_location','redeleteflag']

    }


</script>

<style>
    input[type=number] {
        -moz-appearance:textfield;
    }
</style>
