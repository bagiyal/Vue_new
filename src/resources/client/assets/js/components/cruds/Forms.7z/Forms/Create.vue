<template>
    <section class="content-wrapper" style="margin-left: 5% !important;min-height: 960px;">
        <section class="content-header">
            <h1>Forms</h1>
        </section>

<!--        MODEL-->
        <div v-if="show_modal===true">
            <transition name="modal">
                <div class="modal-mask">
                    <div class="modal-wrapper">
                        <div class="modal-dialog add_width">
                            <div class="modal-content">
                                <div class="modal-header border-0 border-dotted">
                                    <div class="container-fluid pr-0 border-bottom" style="border-bottom-style:dotted !important">
                                        <div class="row">
                                            <div class="col-10">
                                                <b>Add Custom Field</b>
                                            </div>
                                            <div class="col-2 text-right">
                                                <button type="button" class="close" @click="show_modal=false">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                        </div>
                                    </div>



                                </div>
                                <div class="modal-body" style="">
                                    <div class="container-fluid c-grey">
                                        <div class="row no-gutters">

                                            <div class="col-md-12">
                                                <div class="input-group row" >
                                                    <div class="col-md-4">
                                                        <label for="field" style="color: black">Select Field Type</label><br>
                                                        <div class="form-group">
                                                            <v-select
                                                                name="select_field"
                                                                label="name"
                                                                :options="custom_fields"
                                                                @input="custom_field"

                                                            />
                                                        </div>
                                                    </div>

                                                    <div class="col-md-4" v-if="type_of_field===true">
                                                        <label for="field" style="color: black">Select Field Type</label><br>
                                                        <div class="form-group">
                                                            <v-select
                                                                name="Select Type"
                                                                label="name"
                                                                :options="type_of_field_data"
                                                                @input="field_add"

                                                            />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" v-if="type_of_radio===true">
                                                        <label for="field" style="color: black">How Many Choices Do You Want</label><br>
                                                        <div class="form-group">
                                                            <v-select
                                                                name="Select Choice"
                                                                label="choice"
                                                                :options="radio_choices"
                                                                @input="add_choice_options"

                                                            />
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4" v-if="type_of_dropdown===true">
                                                        <label for="field" style="color: black">How Many Choices Do You Want</label><br>
                                                        <div class="form-group">
                                                            <v-select
                                                                name="Select Choice"
                                                                label="choice"
                                                                :options="dropdown_choices"
                                                                @input="add_choice_options_dropdown"

                                                            />
                                                        </div>
                                                    </div>
<!--Question Field-->
                                                    <div class="col-md-4" v-if="ques_section===true">
                                                        <label for="field" style="color: black">Question</label><br>
                                                        <input
                                                            type="text"
                                                            class="form-control"
                                                            name="Question"
                                                            placeholder="Question"
                                                            id="question_label"


                                                        >

                                                    </div>


                                                </div >

                                            </div>
                                            <div class="col-md-12" v-if="type_of_radio_choices===true" v-html="show_radio_choices">

                                            </div>

                                        </div>

                                        <div class="row mt-3">
                                            <div class="col text-right" >
                                                <input type="button" class="button-css" style="color: white;" value="Save"  @click="save_field">
                                            </div>
                                        </div>
                                    </div>



                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </transition>
        </div>
        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <form @submit.prevent="submitForm" novalidate>
                        <div class="box">
                            <div class="box-header with-border">
                                <h3 class="box-title">Create</h3>
                            </div>

                            <div class="box-body">
                                <back-buttton></back-buttton>
                            </div>

                            <bootstrap-alert />

                            <div class="box-body">
                                <div class="form-group col-md-12">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <label for="form_name">Form name</label>
                                            <input
                                                type="text"
                                                class="form-control"
                                                name="form_name"
                                                placeholder="Enter Form name"
                                                :value="item.form_name"
                                                @input="updateForm_name"
                                            >
                                        </div>
                                        <div class="col-md-4">
                                            <label for="message">Add Fields From Dropdown</label><br>
                                            <div class="form-group">
                                                <v-select v-model="section_type"
                                                    name="html_sections"
                                                    label="type"
                                                    :options="Sections"
                                                    @input="inmodal"
                                                          multiple
                                                          class="hidetag"
                                                />
                                            </div>
                                        </div>
                                        <div class="col-md-2">
                                            <label for="message">Or Add Custom Field</label><br>
                                            <a  class="button-css" style="color: white;"  @click="show_modal=true">Custom Field</a>

                                        </div>
                                        <div class="col-md-2">
                                            <label for="message">Add Form Banner</label><br>
                                            <input type="file" size="20"  @change="updatemeta_banner($event,'form_banner',index)" />

                                        </div>

                                        </div>

                                    </div>
                                <div class="form-group col-md-12">
                                    <div class="row">

                                        <div class="col-md-12" v-if="delete_fields_arr.length>0" >
                                            <label for="all_fields" style="color: black">All Fields</label><br>

                                            <div class="row">
                                                <div class="" v-for="fields in this.delete_fields_arr" style="border-radius: 20px;padding-bottom:3px;  padding-right: 7px;background: #bfbfbfa6;">
                                                    <b style="font-size: 15px;padding: 10px;">{{fields.slug}}</b>
                                                    <i class="fa fa-times" style="color: black;cursor: pointer;" @click="delete_fields_fun(fields.slug,fields.type,fields.loc)"></i>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="col-md-12" >
                                    <h1 style="width: 100%;text-align: center;">Form Section</h1>
                                    <div class="row" style="border: 2px solid black;pointer-events: none;">
                                        <div class="col-md-12" v-html="final_html" >

                                        </div>

                                    </div>
                                </div>

                            </div>

                            <div class="box-footer">
                                <vue-button-spinner
                                        class="btn btn-primary btn-sm"
                                        :isLoading="loading"
                                        :disabled="loading"
                                        >
                                    Save
                                </vue-button-spinner>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    </section>
</template>


<script>
import { mapGetters, mapActions } from 'vuex'
import uploadfile from '../../../mixins/uploadfile'

export default {
    data() {
        return {
            show_modal:false,
            section_type:[],
            Sections:[{type:'DOB',code:' <div class="col-md-6" style="margin-top: 20px;"><label for="schedule_date">Date Of Birth</label><br><input type="date" class="form-control input_field_design" id="dob" name="DOB" placeholder="Enter DOB" ></div>'},
                {type:'Food Prefrence',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="Food Prefrence">Food Prefrence</label><br><input type="text" class="form-control input_field_design" id="food_pref" name="food_pref" placeholder="Enter Your Food Prefrence" ></div>'},
                {type:'Marrige Anniversary',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="marrige_anniversary">Marrige Anniversary</label><br><input type="date" class="form-control input_field_design" id="anniversary" name="anniversary" placeholder="Enter Your Anniversary Date" ></div>'},
                {type:'Passport Size Image',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="passport_image">Passport Size Image</label><br><input type="file" class="form-control input_field_design" id="passport_img" name="passport_img"></div>'},
                {type:'Visa',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="visa_image">Visa Doc</label><br><input type="file" class="form-control input_field_design" id="visa_img" name="visa_img"></div>'},
                {type:'Voucher',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="voucher_image">Voucher Doc</label><br><input type="file" class="form-control input_field_design" id="voucher_img" name="voucher_img"></div>'},
                {type:'Insurance',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="insurance_image">Insurance Doc</label><br><input type="file" class="form-control input_field_design" id="insurance_img" name="insurance_img"></div>'},
                {type:'Other',code:'<div class="col-md-6" style="margin-top: 20px;"><label for="other_image">Other Doc</label><br><input type="file" class="form-control input_field_design" id="other_img" name="other_img"></div>'},
                {type: 'Allergies',code:'<div class="col-md-12" style="margin-top: 20px;"><label for="food_allergies">Food Allergies</label><br><input type="text" class="form-control input_field_design" id="food_allergies" name="food_allergies" placeholder="Your Food Allergies" ></div>'}],

            html_syntax_open:'<!DOCTYPE html><html><head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"><style>input[type="file"]{display: block !important;}.input_field_design{border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;}label{font-size: 15px;}.loader{width: 100px;height: 100px;border-radius: 100%;position: relative;margin: 0 auto;}#loader-2 span{display: inline-block;width: 20px;height: 20px;border-radius: 100%;background-color: #3498db;margin: 35px 5px;}#loader-2 span:nth-child(1){animation: bounce 1s ease-in-out infinite;}#loader-2 span:nth-child(2){animation: bounce 1s ease-in-out 0.33s infinite;}#loader-2 span:nth-child(3){animation: bounce 1s ease-in-out 0.66s infinite;}@keyframes bounce{0%, 75%, 100%{-webkit-transform: translateY(0);-ms-transform: translateY(0);-o-transform: translateY(0);transform: translateY(0);}25%{-webkit-transform:translateY(-20px);-ms-transform: translateY(-20px);-o-transform: translateY(-20px);transform:translateY(-20px);}}</style></head><body><div class="col-md-12 form-group" style=""><div class="row"> ',
            html_syntax_close:'</div></div></body><script src="https://unpkg.com/axios/dist/axios.min.js"><\/script><script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"><\/script><script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"><\/script><script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"><\/script><script>function send_data(){source_url=window.location.href;var data_arr2=[];let params2 = new FormData();var url="";var count=0;var passport_img="";var visa_img="";var insurance_img="";var voucher_img="";var other_img="";agency_id= document.getElementById("agency_id").value;var name= document.getElementById("name").value;var email= document.getElementById("email").value;if(name=="" || name==null){alert("Please Fill Name Field");return false;}if(email=="" || email==null){alert("Please Fill Email Field");return false;}  document.getElementById("main-wrap").style.display = "block"; document.body.style.pointerEvents = "none";fiels_selected= document.getElementById("fiels_selected_default").value;separatedArray =fiels_selected.split(","); for(let k=0;k<separatedArray.length;k++){if(separatedArray[k]=="DOB") {count++; dob= document.getElementById("dob").value; data_arr2.push({question:"DOB",ans:dob})}if(separatedArray[k]=="Food Prefrence"){count++; food_pref= document.getElementById("food_pref").value; data_arr2.push({question:"Food Prefrence",ans:food_pref})}if(separatedArray[k]=="Marrige Anniversary"){count++; anniversary= document.getElementById("anniversary").value; data_arr2.push({question:"Marrige Anniversary",ans:anniversary})}if(separatedArray[k]=="Passport Size Image"){count++; passport_img= document.getElementById("passport_img").value;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let passport = document.querySelector("#passport_img");params.set("upload_img",passport.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) { data_arr2.push({question:"Passport Size Image",ans:php_script_response})}});}if(separatedArray[k]=="Visa"){count++; visa_img= document.getElementById("visa_img").value;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let visa = document.querySelector("#visa_img");params.set("upload_img",visa.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) { data_arr2.push({question:"Visa",ans:php_script_response})}});}if(separatedArray[k]=="Voucher"){ count++; voucher_img= document.getElementById("voucher_img").value;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let voucher = document.querySelector("#voucher_img");params.set("upload_img",voucher.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) { data_arr2.push({question:"Voucher",ans:php_script_response})}});}if(separatedArray[k]=="Insurance"){count++; insurance_img= document.getElementById("insurance_img").value;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let insurance= document.querySelector("#insurance_img");params.set("upload_img",insurance.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) { data_arr2.push({question:"Insurance",ans:php_script_response})}});}if(separatedArray[k]=="Other"){count++; other_img= document.getElementById("other_img").value;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let other = document.querySelector("#other_img");params.set("upload_img",other.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) { data_arr2.push({question:"Other",ans:php_script_response})}});}if(separatedArray[k]=="Allergies"){count++; food_allergies= document.getElementById("food_allergies").value; data_arr2.push({question:"Allergies",ans:food_allergies})}}fiels_selected_custom= document.getElementById("fiels_selected_custom").value;for(var k=0;k<fiels_selected_custom;k++){var custom_field_val="";custom_field= document.getElementById("input_"+k).type;custom_field_label= document.getElementById("label_"+k).innerHTML;if(custom_field==="textarea"){count++; custom_field_val= document.getElementById("input_"+k).value;}else if(custom_field==="checkbox"){count++; checkbox_field=document.getElementById("input_"+k).checked;if(checkbox_field===true){custom_field_val="Yes";}else{custom_field_val="No";}}else if(custom_field==="radio"){count++; buttons= document.getElementsByName(custom_field_label);let radioButtonsArray = Array.from(buttons);let isAnyRadioButtonChecked = radioButtonsArray.some(element => element.checked);if(isAnyRadioButtonChecked===true){var ele=document.getElementsByName(custom_field_label);for(i = 0; i < ele.length; i++) { if(ele[i].checked) custom_field_val=ele[i].value;} }else{custom_field_val="No Answer Selected";}}else if(custom_field==="text"){count++; custom_field_val= document.getElementById("input_"+k).value;}else if(custom_field==="number"){count++; custom_field_val= document.getElementById("input_"+k).value;}else if(custom_field==="date"){custom_field_val= document.getElementById("input_"+k).value;}else if(custom_field==="select-one"){count++; custom_field_val= document.getElementById("input_"+k).value;}else if(custom_field==="file"){filepath = document.getElementById("input_"+k).value;id="#input_"+k;let params = new FormData();params.set("source_url", source_url);params.set("email", email);params.set("agency_id", agency_id);let image = document.querySelector(id);params.set("upload_img",image.files[0]);$.ajax({url: "https://trvl.fluede.online/api/webservices/upload",dataType: "text",async:false,cache: false,contentType: false,processData: false,data: params,type: "post",success: function (php_script_response) {custom_field_val=php_script_response; }});}else{console.log(custom_field);}data_arr2.push({question:custom_field_label,ans:custom_field_val});}params2.set("source_url", source_url);params2.set("agency_id", agency_id);params2.set("name", name);params2.set("email", email);params2.set("questions",JSON.stringify(data_arr2));$.ajax({url: "https://trvl.fluede.online/api/webservices/update_form",dataType:"text",async:false,cache: false,contentType: false,processData: false,data: params2,type: "post",success: function (php_script_response) {document.getElementById("main-wrap").style.display = "none"; document.body.style.pointerEvents = "auto";window.open("https://trvl.fluede.online/api/acknowledgement");}})}<\/script><\/html>',
            body_element_data:[],
            final_html:'',
            show_radio_choices:'',
            selectes_type:[],
            custom_fields:[{type:'text',name:'Text Field'},{type:'checkbox',name:'Check Box'},{type:'options',name:'Multiple Options(Dropdown)'},{type:'radio',name:'Radio Button'},{type:'textarea',name:'Textarea'},{type:'file',name:'File Upload'}],
            label_name:'',
            add_custom_field:[],
            ques_section:'false',
            field_type:null,
            type_of_field:false,
            type_of_radio:false,
            type_of_radio_choices:false,
            type_of_field_data:[{type:'date',name:'Date Field'},{type:'number',name:'Number Field'},{type:'text',name:'Text Field'}],
            radio_choices:[{choice:'2'},{choice:'3'},{choice:'4'},{choice:'5'},],
            dropdown_choices:[{choice:'2'},{choice:'3'},{choice:'4'},{choice:'5'},{choice:'6'},{choice:'7'},{choice:'8'},{choice:'9'},{choice:'10'},],
            type_of_dropdown:false,
            choice_count:'',
            text_field_type:'',
            banner_link:'',
            background_url:'',
            delete_fields_section:'',
            delete_fields_arr:[],




        }
    },
    computed: {
        ...mapGetters('FormsSingle', ['item', 'loading','fields_arr'])
    },
    created() {
        // agency_id
        var base_url = window.location.origin;
        this.background_url=base_url+'/dashboard_resources/background_doc.png';
        var user_id=document.querySelector("meta[name='user-id']").getAttribute('content');

        var role=document.querySelector("meta[name='user-role']").getAttribute('content');
        // alert(role);
        if(role=='agency'){
            this.item.agency_id=user_id;
            this.item.agent_id='';
        }
        else if(role=='lms_agent'){
            this.item.agent_id=user_id;
            var agency_id=JSON.parse(document.querySelector("meta[name='agency-id']").getAttribute('content'));
            this.item.agency_id=agency_id['id']

        }

        this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
        this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');

      // this.final_html='<!DOCTYPE html><html><head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"><style>input[type="file"]{display: block !important;}</style></head><body><div class="col-md-12 form-group" style=""> ';
      this.final_html='<!DOCTYPE html><html><head><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"><link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css"><style>input[type="file"]{display: block !important;}.input_field_design{border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;}label{font-size: 15px;}</style></head><body><div class="col-md-12 form-group" style=""> ';
       this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%;padding: 20px;">';
       for(var j=0;j<this.body_element_data.length;j++){
         this.final_html+=this.body_element_data[j];
            // console.log(this.body_element_data[j]);
        }

       this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
        this.final_html+='</div>';
       this.final_html+=this.html_syntax_close;


    },
    destroyed() {
        this.resetState()
    },
    methods: {
        ...mapActions('FormsSingle', ['storeData', 'resetState', 'setForm_name', 'setAgency_id', 'setForm_html','uploadFile','setfields_arr','setAgent_id']),
        updateForm_name(e) {
            this.setForm_name(e.target.value)
        },
        updateAgency_id(e) {
            this.setAgency_id(e.target.value)
        },
        updateAgent_id(e) {
            this.setAgent_id(e.target.value)
        },
        updateForm_html(e) {
            this.setForm_html(e.target.value)
        },

        submitForm() {
            if(this.item.form_name.length>0){
                if(this.delete_fields_arr.length>0){
                    this.storeData()
                        .then(() => {
                            this.$router.push({ name: 'forms.index' })
                            this.$eventHub.$emit('create-success')
                        })
                        .catch((error) => {
                            console.error(error)
                        })
                    // let params = new FormData();
                    // params.set('form_questions',JSON.stringify(this.delete_fields_arr));
                    // axios.post('/api/webservices/save_template' , params);
                }
                else{
                    alert('Please add fields');
                }
            }
            else{
                alert('Please fill form name');
            }

        },
        inmodal(value){
            this.body_element_data=[];
            this.delete_fields_arr=[];
            this.selectes_type=[];
            this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
            this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');

            var data_arr=[];

                for(var k=0;k<value.length;k++){
                    // console.log(value[k]['code']);

                    this.body_element_data.push(value[k]['code']);
                    this.selectes_type.push(value[k]['type']);
                    data_arr.push(value[k]['type']);
                    this.delete_fields_arr.push({
                        slug:value[k]['type'],
                        type:'default',
                        loc:k

                    });

                }


            this.final_html=this.html_syntax_open;
            this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%;padding: 20px;">';
            for(var j=0;j<this.body_element_data.length;j++){
                this.final_html+=this.body_element_data[j];
                // console.log(this.body_element_data[j]);
            }
            if(this.add_custom_field.length>0){
                for(let j=0;j<this.add_custom_field.length;j++){
                    // console.log(this.add_custom_field[j]['question']);
                    // console.log(this.add_custom_field[j]['code']);
                    this.final_html+=this.add_custom_field[j]['code'];
                    this.delete_fields_arr.push({
                        slug:this.add_custom_field[j]['question'],
                        html:this.add_custom_field[j]['code'],
                        type:'custom',
                        loc:j

                    });

                }
            }

            this.body_element_data.push('</div>');
            this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
            this.final_html+='</div>';
            this.final_html+='<input id="fiels_selected_default" type="hidden" value="'+data_arr+'">';
            this.final_html+='<input id="fiels_selected_custom" type="hidden" value="'+this.add_custom_field.length+'">';
            this.final_html+=this.html_syntax_close;
            this.item.form_html=JSON.stringify({type:this.delete_fields_arr,code:this.final_html,banner:this.banner_link});
            this.setfields_arr(this.delete_fields_arr);






        },
        custom_field(value){
            if(value=='' || value==null){
                this.ques_section=false;
                this.field_type=null;
                this.type_of_radio_choices=false;
                this.type_of_field=false;
                this.type_of_dropdown=false;

            }
            else{
                var type=Object.entries(value);
                var field=type[0][1];
                this.field_type=field;
                if(field=='text'){
                 this.ques_section=true;
                 this.type_of_field=true;
                 this.type_of_radio=false;
                    this.type_of_radio_choices=false;
                    this.type_of_dropdown=false;

                }
                else if(field=='checkbox'){
                this.ques_section=true;
                this.type_of_field=false;
                    this.type_of_radio=false;
                    this.type_of_radio_choices=false;
                    this.type_of_dropdown=false;
                }
                else if(field=='options'){
                this.ques_section=false;
                this.type_of_field=false;
                this.type_of_radio=false;
                this.type_of_radio_choices=false;
                this.type_of_dropdown=true;


                }
                else if(field=='radio'){
                    this.ques_section=false;
                    this.type_of_field=false;
                    this.type_of_radio=true;
                    this.type_of_radio_choices=false;
                    this.type_of_dropdown=false;
                }
                else if(field=='textarea'){
                    this.ques_section=true;
                    this.type_of_field=false;
                    this.type_of_radio=false;
                    this.type_of_radio_choices=false;
                    this.type_of_dropdown=false;
                }
                else if(field=='file'){
                    this.ques_section=true;
                    this.type_of_field=false;
                    this.type_of_radio=false;
                    this.type_of_radio_choices=false;
                    this.type_of_dropdown=false;
                }

                //type_of_radio

            }

        },
        save_field(){
            var data_arr=[];
                if(this.field_type!=null){


                var question=document.getElementById('question_label').value;


                if(question=='' || question==null){
                    alert('Please Fill Question Field');
                    return  false;
                }
                else{
                    // console.log(question);

                    var add=0;
                    for(var m=0;m<this.delete_fields_arr.length;m++){
                        var slug=this.delete_fields_arr[m]['slug'];
                        if(slug.toLowerCase()===question.toLowerCase()){
                            alert(question+' fields already exist.');
                            add=1;
                        }
                    }
                    if(add===0){
                        for(var u=0;u<this.Sections.length;u++){
                            if(this.Sections[u]['type'].toLowerCase()===question.toLowerCase()){
                                this.section_type.push(this.Sections[u]);
                            }
                        }
                        this.body_element_data=[];

                        this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
                        this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');

                        this.show_modal=false;
                        this.ques_section=false;
                        this.type_of_radio_choices=false;
                        this.type_of_dropdown=false;


                        var type1='';
                        var type2='';

                        if(this.field_type=='text'){
                            // alert('textarea');
                            if(this.text_field_type=='text'){
                                this.add_custom_field.push({question:question ,code:'<div class="col-md-6" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><input type="text" class="form-control input_field_design" id="input_'+this.add_custom_field.length+'" name="'+this.add_custom_field.length+'" placeholder="Enter Text"></div>'});
                            }
                            else if(this.text_field_type=='date'){
                                this.add_custom_field.push({question:question ,code:'<div class="col-md-6" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><input type="date" class="form-control input_field_design" id="input_'+this.add_custom_field.length+'" name="'+this.add_custom_field.length+'" placeholder="Select Date"></div>'});
                            }
                            else if(this.text_field_type=='number'){
                                this.add_custom_field.push({question:question ,code:'<div class="col-md-6" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><input type="number" class="form-control input_field_design" id="input_'+this.add_custom_field.length+'" name="'+this.add_custom_field.length+'" placeholder="Enter Number"></div>'});
                            }


                        }
                        else if(this.field_type=='checkbox'){
                            // alert('checkbox');
                            this.add_custom_field.push({question:question ,code:'<div class="col-md-6" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><input type="checkbox" class="" id="input_'+this.add_custom_field.length+'" name="custom_field_checkbox" ></div>'});
                        }
                        else if(this.field_type=='options'){
                            // alert('options');
                            if(this.choice_count!=''){
                                // alert(this.choice_count);
                                var options='<div class="col-md-6" style="margin-top: 20px;"><label for="options" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><select class="form-control" id="input_'+this.add_custom_field.length+'" name="custom_dropdown">';
                                var option_val='';
                                var j=0;
                                for (var r=0;r<this.choice_count;r++){
                                    j=r+1;
                                    option_val=document.getElementById("dropdown"+r).value;
                                    if(option_val.length>0){
                                        // console.log(option_val);
                                        options+='<option>'+option_val+'</option>';
                                    }
                                    else{
                                        alert ('Fill '+j+'nd Choice');
                                        return false;
                                    }
                                }
                                options+='</select></div>';
                                console.log(options);
                                this.add_custom_field.push({question:question ,code:options});
                            }
                            else{
                                alert('Select Choices');
                            }
                        }
                        else if(this.field_type=='textarea'){
                            // alert('textarea');
                            this.add_custom_field.push({question:question ,code:'<div class="col-md-12" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><textarea  rows="6" cols="30" class="form-control" name="custom_textarea" id="input_'+this.add_custom_field.length+'"></textarea></div>'});
                        }
                        else if(this.field_type=='radio'){
                            if(this.choice_count!=''){
                                // alert(this.choice_count);
                                var radio_button='<div class="col-md-6" style="margin-top: 20px;"><label for="radio" id="label_'+this.add_custom_field.length+'">'+question+'</label><br>';
                                var radio_val='';
                                var j=0;
                                for (var r=0;r<this.choice_count;r++){
                                    j=r+1;
                                    radio_val=document.getElementById("radio"+r).value;
                                    if(radio_val.length>0){
                                        // console.log(radio_val);
                                        radio_button+='<input style="margin-left: 20px;margin-right: 20px;" id="input_'+this.add_custom_field.length+'" type="radio" name="'+question+'" value="'+radio_val+'">&nbsp;&nbsp;'+radio_val+'&nbsp;&nbsp;';
                                    }
                                    else{
                                        alert ('Fill '+j+'nd Choice');
                                        return false;
                                    }
                                }
                                radio_button+='</div>';
                                console.log(radio_button);
                                this.add_custom_field.push({question:question ,code:radio_button});
                            }
                            else{
                                alert('Select Choices');
                            }
                        }
                        else if(this.field_type=='file'){
                            this.add_custom_field.push({question:question ,code:'<div class="col-md-6" style="margin-top: 20px;"><label for="custom_filed" id="label_'+this.add_custom_field.length+'">'+question+'</label><br><input type="file" class="form-control input_field_design" id="input_'+this.add_custom_field.length+'" name="'+question+'"></div>'});
                        }



                        this.final_html=this.html_syntax_open;
                        this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%;padding: 20px;">';
                        for(var j=0;j<this.body_element_data.length;j++){
                            this.final_html+=this.body_element_data[j];
                            // console.log(this.body_element_data[j]);
                        }
                        if(this.selectes_type.length>0){
                            for(var m=0;m<this.selectes_type.length;m++){

                                type1=this.selectes_type[m];
                                // console.log(type1);
                                for (var l=0;l<this.Sections.length;l++){
                                    // console.log(this.Sections[l]['type']);
                                    type2=this.Sections[l]['type'];
                                    // console.log(type2);
                                    if(type1==type2){
                                        data_arr.push(this.Sections[l]['type']);
                                        // this.body_element_data.push(this.Sections[l]['code']);
                                        this.final_html+=this.Sections[l]['code'];
                                    }
                                }

                            }

                        }
                        if(this.add_custom_field.length>0){
                            for(let j=0;j<this.add_custom_field.length;j++){
                                // console.log(this.add_custom_field[j]['question']);
                                // console.log(this.add_custom_field[j]['code']);
                                this.final_html+=this.add_custom_field[j]['code'];
                               if(this.add_custom_field[j]['question']===question){
                                   this.delete_fields_arr.push({
                                       slug:question,
                                       html:this.add_custom_field[j]['code'],
                                       type:'custom',
                                       loc:this.add_custom_field.length

                                   });
                               }


                            }
                        }
                        // this.final_html+=this.body_element_data;
                        this.final_html+='</div>';
                        this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
                        this.final_html+='</div>';
                        this.final_html+='<input id="fiels_selected_default" type="hidden" value="'+data_arr+'">';
                        this.final_html+='<input id="fiels_selected_custom" type="hidden" value="'+this.add_custom_field.length+'">';
                        this.final_html+=this.html_syntax_close;
                        this.item.form_html=JSON.stringify({type:this.delete_fields_arr,code:this.final_html,banner:this.banner_link});
                        // console.log(this.final_html);
                        this.setfields_arr(this.delete_fields_arr);
                    }

                }



            }
            else {
                alert('Please Select Field Type');
            }
        },
        field_add(value){
            if(value=='' || value==null){
                this.ques_section=false;
                this.type_of_radio_choices=false;
                this.type_of_radio=false;
            }
            else{
                var type=Object.entries(value);
                var field=type[0][1];

                this.text_field_type=field;
                this.ques_section=true;
            }
        },
        add_choice_options(value){
            if(value=='' || value==null){
                this.ques_section=false;
                this.type_of_radio_choices=false;
                this.type_of_radio=true;
                  }
            else{
                var type=Object.entries(value);
                var field=type[0][1];
                this.ques_section=true;
                // console.log(field);
                this.choice_count=field;
                var d=0;
                this.show_radio_choices='<div class="form-group">';
                for (var c=0;c<field;c++){
                    this.type_of_radio_choices=true;
                    this.type_of_radio=false;
                    d=c+1;
                    this.show_radio_choices+='<div class="col-md-4" style="margin-top: 20px;"><input type="text" class="form-control " id="radio'+c+'" placeholder="Enter Your Choice'+d+'" ></div>';

                }
                this.show_radio_choices+='</div>';
                // console.log(this.show_radio_choices);
            }
        },
        add_choice_options_dropdown(value){
            if(value=='' || value==null){
                this.ques_section=false;

                this.type_of_dropdown=true;
            }
            else{
                var type=Object.entries(value);
                var field=type[0][1];
                this.ques_section=true;
                console.log(field);
                this.choice_count=field;
                var d=0;
                this.show_radio_choices='<div class="form-group">';
                for (var c=0;c<field;c++){
                    this.type_of_radio_choices=true;
                    this.type_of_dropdown=false;
                    d=c+1;
                    this.show_radio_choices+='<div class="col-md-4" style="margin-top: 20px;"><input type="text" class="form-control " id="dropdown'+c+'" placeholder="Enter Your Choice'+d+'" ></div>';

                }
                this.show_radio_choices+='</div>';
                console.log(this.show_radio_choices);
            }
        },
        updatemeta_banner(value, type, index){
            uploadfile("insurance", type, value.target.files[0], this.item.booking_id).then(response => {
                var base_url = window.location.origin;
                this.banner_link=base_url+response.data;
                // console.log(this.banner_link);
                this.body_element_data=[];

                this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
                this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');
                var data_arr=[];
                for(var k=0;k<value.length;k++){
                    this.body_element_data.push(value[k]['code']);

                }
                this.final_html=this.html_syntax_open;
                this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%; padding: 20px;">';
                for(var j=0;j<this.body_element_data.length;j++){
                    this.final_html+=this.body_element_data[j];
                    // console.log(this.body_element_data[j]);
                }
                if(this.selectes_type.length>0){
                    for(var m=0;m<this.selectes_type.length;m++){

                        // type1=this.selectes_type[m];
                        // console.log(type1);
                        for (var l=0;l<this.Sections.length;l++){
                            // console.log(this.Sections[l]['type']);
                            // type2=this.Sections[l]['type'];
                            // console.log(type2);
                            if(this.selectes_type[m]==this.Sections[l]['type']){
                                // this.body_element_data.push(this.Sections[l]['code']);
                                data_arr.push(this.Sections[l]['type']);

                                this.final_html+=this.Sections[l]['code'];
                            }
                        }

                    }

                }
                if(this.add_custom_field.length>0){
                    for(let j=0;j<this.add_custom_field.length;j++){
                        // console.log(this.add_custom_field[j]['question']);
                        // console.log(this.add_custom_field[j]['code']);
                        this.final_html+=this.add_custom_field[j]['code'];

                    }
                }

                this.body_element_data.push('</div>');
                this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
                this.final_html+='</div>';
                this.final_html+='<input id="fiels_selected_default" type="hidden" value="'+data_arr+'">';
                this.final_html+='<input id="fiels_selected_custom" type="hidden" value="'+this.add_custom_field.length+'">';
                this.final_html+=this.html_syntax_close;
                this.item.form_html=JSON.stringify({type:this.delete_fields_arr,code:this.final_html,banner:this.banner_link});
                // console.log(this.selectes_type);
            })
        },
        delete_fields_fun (value,type,index){

            // alert(index+"-"+type+"-"+value);
        if(this.delete_fields_arr.length>0){
            if(type==='default'){
                this.body_element_data=[];
                this.delete_fields_arr=[];
                this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
                this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');
                this.final_html=this.html_syntax_open;
                this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%;padding: 20px;">';
                for(var j=0;j<this.body_element_data.length;j++){
                    this.final_html+=this.body_element_data[j];
                    // console.log(this.body_element_data[j]);
                }
                var data_arr=[];

                this.section_type=[];
                // console.log(this.selectes_type);
                if(this.selectes_type.length>0){
                    for(var m=0;m<this.selectes_type.length;m++){
                        if(this.selectes_type[m]!==value){
                            this.delete_fields_arr.push({
                                slug:this.selectes_type[m],
                                type:'default',
                                loc:m

                            });

                            for (var l=0;l<this.Sections.length;l++){

                                if(this.selectes_type[m]==this.Sections[l]['type']){
                                    console.log(this.selectes_type[m]);
                                    // this.body_element_data.push(this.Sections[l]['code']);
                                    this.final_html+=this.Sections[l]['code'];

                                    this.section_type.push({type:this.Sections[l]['type'],code:this.Sections[l]['code']});
                                    data_arr.push(this.Sections[l]['type']);
                                }
                            }

                        }


                    }
                    this.selectes_type=[];
                    this.selectes_type=data_arr;
                }
                if(this.add_custom_field.length>0){
                    for(let j=0;j<this.add_custom_field.length;j++){
                        // console.log(this.add_custom_field[j]['question']);
                        // console.log(this.add_custom_field[j]['code']);
                        this.delete_fields_arr.push({
                            slug:this.add_custom_field[j]['question'],
                            html:this.add_custom_field[j]['code'],
                            type:'custom',
                            loc:j

                        });
                        this.final_html+=this.add_custom_field[j]['code'];

                    }
                }
                this.final_html+='</div>';
                this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
                this.final_html+='</div>';
                this.final_html+='<input id="fiels_selected_default" type="hidden" value="'+data_arr+'">';
                this.final_html+='<input id="fiels_selected_custom" type="hidden" value="'+this.add_custom_field.length+'">';
                this.final_html+=this.html_syntax_close;
                this.setfields_arr(this.delete_fields_arr);

            }
            else if(type==='custom'){
                // alert(index+"-"+type+"-"+value);
                // console.log(this.add_custom_field);
                this.body_element_data=[];
                this.delete_fields_arr=[];
                this.body_element_data.push('<input id="agency_id" name="agency_id" type="hidden" value="'+this.item.agency_id+'" /><img src="'+this.banner_link+'"  title="banner" style="width: 100%;height: 200px;"><div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Name *</label><br><input type="text" required class="form-control " id="name" name="name" placeholder="Enter Name" style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;"></div>');
                this.body_element_data.push('<div class="col-md-10" style="margin-top: 20px;"><label for="Name" style="font-size: 15px">Enter Your Email *</label><br><input type="text" required class="form-control " id="email" name="email" placeholder="Enter Email"  style="border: none;border-bottom: 1px solid black;background: transparent;border-radius: 0px;" ><p style="font-size:10px;color:red;">Note -: Email should be as same as you given to your agent.</p></div><div class="container main-wrap" id="main-wrap" style="position: absolute;z-index: 100;text-align: center;display:none;"><div class="row"><div class="col-md-12 bg"><div class="loader" id="loader-2"><span></span><span></span><span></span></div></div></div></div>');
                this.final_html=this.html_syntax_open;
                this.final_html+='<div class="container" style="background-image: url('+this.background_url+');background-repeat: no-repeat;background-size: 100% 100%;padding: 20px;">';
                for(var j=0;j<this.body_element_data.length;j++){
                    this.final_html+=this.body_element_data[j];
                    // console.log(this.body_element_data[j]);
                }
                var data_arr=[];
                this.section_type=[];
                // console.log(this.selectes_type);
                if(this.selectes_type.length>0){
                    for(var m=0;m<this.selectes_type.length;m++){
                        if(this.selectes_type[m]!==value){
                            this.delete_fields_arr.push({
                                slug:this.selectes_type[m],
                                type:'default',
                                loc:m

                            });

                            for (var l=0;l<this.Sections.length;l++){

                                if(this.selectes_type[m]==this.Sections[l]['type']){
                                    // console.log(this.selectes_type[m]);
                                    // this.body_element_data.push(this.Sections[l]['code']);
                                    this.final_html+=this.Sections[l]['code'];
                                    this.section_type.push({type:this.Sections[l]['type'],code:this.Sections[l]['code']});
                                    data_arr.push(this.Sections[l]['type']);
                                }
                            }

                        }


                    }
                    this.selectes_type=[];
                    this.selectes_type=data_arr;
                }

                // console.log(this.add_custom_field);
                var data_arr2=[];
                if(this.add_custom_field.length>0){
                    for(var n=0;n<this.add_custom_field.length;n++){

                        if(this.add_custom_field[n]['question']!==value){
                                this.delete_fields_arr.push({
                                    slug:this.add_custom_field[n]['question'],
                                    html:this.add_custom_field[n]['code'],
                                    type:'custom',
                                    loc:n
                                });

                            data_arr2.push({code:this.add_custom_field[n]['code'],
                                question:this.add_custom_field[n]['question']
                            });
                            this.final_html+=this.add_custom_field[n]['code'];
                        }
                    }


                }
                this.add_custom_field=[];
                this.add_custom_field=data_arr2;
                // console.log(this.add_custom_field);
                this.final_html+='</div>';
                this.final_html+='<div class="col-md-12" style="text-align: center;margin-top: 20px;"><button onclick="send_data()" style="text-align: center;padding-left: 30px;border-radius: 20px;padding-right:30px;" class="btn-lg btn-success">Submit</button></div>';
                this.final_html+='</div>';
                this.final_html+='<input id="fiels_selected_default" type="hidden" value="'+data_arr+'">';
                this.final_html+='<input id="fiels_selected_custom" type="hidden" value="'+this.add_custom_field.length+'">';
                this.final_html+=this.html_syntax_close;
                this.setfields_arr(this.delete_fields_arr);


            }
        }
        },
    }
}
</script>


<style scoped>
.button-css{
    position: unset !important;
}
.modal-mask {
    position: fixed;
    z-index: 9998;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, .5);
    display: table;
    transition: opacity .3s ease;
}

.modal-wrapper {
    display: table-cell;
    /*vertical-align: middle;*/
}
.activedev{
    display: block !important;
}
.hidedev{
    display: none;
}
.bg-primary {
    color: white !important;
}
.v-select .selected-tag{
    display: none !important;
}
.hidetag .selected-tag{
    display: none !important
}

</style>
